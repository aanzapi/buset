<div align="center">
  <img src="frontend/public/images/logo.webp" alt="ZxuanTopup Logo" width="200" />
  
  # 🎮 ZxuanTopup Platform — Buyers Edition
  
  > Platform Top-Up Game Otomatis & Terpercaya.  
  > Terintegrasi langsung dengan **Vipayment** dan **Tripay Payment Gateway**.  
  > Versi siap pakai (Production Ready). Tinggal konfigurasi env, jalankan, profit!
</div>

---

## 📋 Daftar Isi

- [Apa Itu ZxuanTopup?](#-apa-itu-zxuantopup)
- [Tech Stack](#-tech-stack)
- [Struktur Folder](#-struktur-folder)
- [Cara Pasang (Step by Step)](#-cara-pasang-step-by-step)
- [Environment Variables](#-environment-variables)
- [Deploy ke VPS](#-deploy-ke-vps)
- [FAQ Troubleshooting](#-faq-troubleshooting)

---

## 🚀 Apa Itu ZxuanTopup?

ZxuanTopup adalah website marketplace top-up game otomatis. Fitur utama yang tersedia:
1. **Top-Up Otomatis:** Terhubung langsung dengan API provider (Vipayment).
2. **Pembayaran Instan:** Dukungan penuh untuk berbagai channel pembayaran otomatis (QRIS, E-Wallet, Virtual Account) via Tripay.
3. **Notifikasi WhatsApp:** Fitur auto-notifikasi ke admin dan pembeli untuk status transaksi.
4. **Dashboard Admin:** Sistem manajemen produk, transaksi, dan user yang komprehensif.

---

## 🛠 Tech Stack

| Bagian | Teknologi |
|--------|-----------|
| **Frontend** | Next.js (App Router), React, Tailwind CSS |
| **Backend** | Express.js, Node.js |
| **Database** | MySQL (menggunakan Sequelize ORM) |
| **Cache & Queue** | Upstash Redis, Bull Queue |
| **Realtime** | Socket.io |
| **Notifikasi WA** | Fonnte API |

---

## 📁 Struktur Folder

```text
ZxuanTopup/
├── frontend/          ← Next.js (Halaman Web UI)
│   ├── public/        ← Asset gambar & logo
│   ├── src/
│   │   ├── app/       ← Routing halaman (Next.js 13+)
│   │   ├── components/← UI Components
│   │   └── lib/       ← Utility functions frontend
│   └── package.json
│
├── middleware/        ← Express Middleware (Auth, Security)
├── models/            ← Database Models (Sequelize)
├── routes/            ← API Routing Backend
├── services/          ← Business logic & 3rd party API (Tripay, Vipayment)
├── utils/             ← Helper Backend
├── index.js           ← Entry point Backend
├── .env.example       ← Template environment variables
└── package.json       ← Dependensi Backend
```

---

## ⚙️ Cara Pasang (Step by Step)

### Step 1: Persiapan Database
Pastikan Anda sudah menginstall MySQL Server (atau menggunakan XAMPP/Laragon).
1. Buka MySQL / phpMyAdmin.
2. Buat database baru bernama `zxuan_topup`.

### Step 2: Konfigurasi Environment (`.env`)
Salin file `.env.example` menjadi `.env` di direktori utama:
```bash
cp .env.example .env
```
Lalu, buka file `.env` dan lengkapi datanya (Lihat bagian [Environment Variables](#-environment-variables)).

### Step 3: Install Dependencies
Buka terminal dan jalankan instalasi untuk backend dan frontend:

**Terminal (Backend):**
```bash
npm install
```

**Terminal (Frontend):**
```bash
cd frontend
npm install
```

### Step 4: Menjalankan Aplikasi di Local
Buka **2 terminal** secara terpisah:

**Terminal 1 — Backend:**
```bash
# Berada di direktori utama (root)
npm run dev
```
Backend akan berjalan di `http://localhost:5000`

**Terminal 2 — Frontend:**
```bash
# Berada di dalam folder frontend
cd frontend
npm run dev
```
Frontend akan berjalan di `http://localhost:3001`

Selesai! Buka browser di `http://localhost:3001` 🎉

---

## 🔑 Environment Variables

File `.env` terletak di direktori utama (root) proyek.

| Variable | Wajib? | Contoh / Penjelasan |
|----------|--------|---------------------|
| `PORT` | ✅ | `5000` (Port untuk backend API) |
| `FRONTEND_URL` | ✅ | `http://localhost:3001` (URL website frontend Anda) |
| `BACKEND_URL` | ✅ | `http://localhost:5000` (URL backend API Anda) |
| `DB_HOST` | ✅ | `localhost` |
| `DB_NAME` | ✅ | `zxuan_topup` |
| `DB_USER` | ✅ | `root` |
| `DB_PASS` | ❌ | Password database (kosongkan jika XAMPP lokal) |
| `UPSTASH_REDIS_REST_URL`| ✅ | URL Redis dari Upstash |
| `VIP_API_KEY` | ✅ | API Key dari Vipayment |
| `VIP_API_ID` | ✅ | API ID dari Vipayment |
| `TRIPAY_API_KEY` | ✅ | API Key Tripay |
| `TRIPAY_PRIVATE_KEY`| ✅ | Private Key Tripay |
| `TRIPAY_MERCHANT_CODE`| ✅ | Merchant Code Tripay |
| `FONNTE_TOKEN` | ❌ | Token API Fonnte (untuk notifikasi WhatsApp) |
| `OWNER_WA` | ❌ | `628xxxxxxxxxx` (Nomor admin) |

---

## ☁️ Deploy ke VPS (Production)

Untuk aplikasi bisa diakses online 24 jam.

### Step 1: Install Kebutuhan VPS (Ubuntu)
```bash
sudo apt update
sudo apt install nodejs npm mysql-server -y
sudo npm install -g pm2
```

### Step 2: Konfigurasi Database VPS
Buat database di MySQL VPS Anda dan sesuaikan kredensialnya di file `.env`. (Jangan lupa import `.sql` lokal Anda jika ada).

### Step 3: Sesuaikan URL di `.env`
Ubah `.env` menjadi domain live Anda:
```env
NODE_ENV=production
FRONTEND_URL=https://domainanda.com
BACKEND_URL=https://api.domainanda.com
```

### Step 4: Build Frontend
```bash
cd frontend
npm run build
cd ..
```

### Step 5: Jalankan Menggunakan PM2

**Menjalankan Backend:**
```bash
pm2 start index.js --name "zxuan-backend"
```

**Menjalankan Frontend:**
```bash
cd frontend
pm2 start npm --name "zxuan-frontend" -- start
```

### Step 6: Simpan Proses PM2
Agar otomatis menyala jika VPS restart:
```bash
pm2 save
pm2 startup
```

---

## 🆘 FAQ Troubleshooting

### ❓ Backend tidak terhubung ke Database
- Pastikan MySQL Service sudah berjalan (jika XAMPP, klik tombol "Start" di module MySQL).
- Pastikan kredensial di `.env` (`DB_NAME`, `DB_USER`, `DB_PASS`) sudah benar sesuai server Anda.

### ❓ Pembayaran Tripay Tidak Terdeteksi Otomatis
- Pastikan Anda mengatur **Callback URL** di dashboard Tripay menuju `https://api.domainanda.com/api/callback/tripay`.
- Pastikan `TRIPAY_MODE` diset ke `production` jika menggunakan uang asli (bukan testing).

### ❓ Fitur Notifikasi WhatsApp Tidak Berjalan
- Pastikan `FONNTE_TOKEN` di `.env` valid.
- Buka dashboard Fonnte, pastikan perangkat / nomor WhatsApp bot Anda sudah berstatus terhubung (Connected).

---

## 📄 Lisensi

**PROPRIETARY AND RESTRICTED LICENSE**  
Proyek ini **TIDAK open source**. Dilarang keras **menjual**, **menyebarluaskan**, atau **mendistribusikan ulang** source code ini dengan alasan apa pun tanpa izin tertulis dari Developer Utama. 
Lihat [LICENSE](./LICENSE) untuk detail.

## 👥 Kontributor

Lihat [CONTRIBUTORS.md](./CONTRIBUTORS.md)

---

<div align="center">

**Dibuat dengan ❤️ oleh Tim ZxuanTopup**

🎮 *Yilzi says: "Mabar lancar, topup gak pake mikir!"*

</div>
