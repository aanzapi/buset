const router = require('express').Router();
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { User, Otp, LoginHistory } = require('../models');
const { authLimiter } = require('../middleware/rateLimiter');
const { verifyRecaptcha } = require('../middleware/recaptcha');
const { sendEmail, welcomeEmail, otpEmail, loginAlertEmail } = require('../services/smtp');
const { sendMessage, otpMessage } = require('../services/fonnte');
const { v4: uuidv4 } = require('uuid');

// ─── Helper: Generate 6-digit OTP ────────────────────
function generateOtp() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// ─── Helper: Generate & Issue JWT Tokens ─────────────
function issueTokens(user, res) {
  const token = jwt.sign(
    { id: user.id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
  const refreshToken = jwt.sign(
    { id: user.id },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '30d' }
  );
  res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', maxAge: 7 * 24 * 60 * 60 * 1000 });
  res.cookie('refreshToken', refreshToken, { httpOnly: true, secure: process.env.NODE_ENV === 'production', maxAge: 30 * 24 * 60 * 60 * 1000 });
  return { token, refreshToken };
}

// ─── Helper: Track IP & send alert if new device ─────
async function trackLogin(user, req) {
  try {
    const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.connection?.remoteAddress || req.ip || 'unknown';
    const userAgent = req.headers['user-agent'] || 'unknown';

    // Check if this IP+UA combo has been seen before
    const existing = await LoginHistory.findOne({
      where: { user_id: user.id, ip_address: ip, user_agent: userAgent },
    });

    // Always log the login
    await LoginHistory.create({ user_id: user.id, ip_address: ip, user_agent: userAgent });

    // If new device/IP combo, send email alert
    if (!existing && user.email) {
      const time = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
      sendEmail(loginAlertEmail(user.email, ip, userAgent, time)).catch(err => {
        console.error('[Auth] Login alert email failed:', err.message);
      });
    }
  } catch (err) {
    console.error('[Auth] Track login failed:', err.message);
  }
}

// ─── Google OAuth Strategy ───────────────────────────
if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: process.env.GOOGLE_CALLBACK_URL,
    passReqToCallback: true,
  }, async (req, accessToken, refreshToken, profile, done) => {
    try {
      let user = await User.findOne({ where: { google_id: profile.id } });

      if (!user) {
        // Check if email already registered (local account)
        const existingByEmail = await User.findOne({ where: { email: profile.emails?.[0]?.value } });
        if (existingByEmail) {
          // Link Google to existing local account
          await existingByEmail.update({
            google_id: profile.id,
            avatar: existingByEmail.avatar || profile.photos?.[0]?.value || '',
          });
          user = existingByEmail;
        } else {
          user = await User.create({
            google_id: profile.id,
            username: profile.displayName,
            email: profile.emails?.[0]?.value || '',
            avatar: profile.photos?.[0]?.value || '',
            referral_code: uuidv4().slice(0, 8).toUpperCase(),
          });

          try {
            await sendEmail(welcomeEmail(user));
          } catch (emailErr) {
            console.error('[Auth] Welcome email failed:', emailErr.message);
          }
        }
      }

      // Track login
      await trackLogin(user, req);

      done(null, user);
    } catch (err) {
      done(err, null);
    }
  }));
}

passport.serializeUser((user, done) => done(null, user.id));
passport.deserializeUser(async (id, done) => {
  const user = await User.findByPk(id);
  done(null, user);
});

router.use(passport.initialize());

// ─── Routes ──────────────────────────────────────────

// Initiate Google OAuth
router.get('/google', authLimiter,
  passport.authenticate('google', { scope: ['profile', 'email'], session: false })
);

// Google OAuth callback
router.get('/google/callback',
  passport.authenticate('google', { failureRedirect: '/login', session: false }),
  (req, res) => {
    const { token } = issueTokens(req.user, res);
    res.redirect(`${process.env.FRONTEND_URL}/auth/callback?token=${token}`);
  }
);

// ─── Register (Local) ────────────────────────────────
router.post('/register', authLimiter, verifyRecaptcha, async (req, res) => {
  try {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
      return res.status(400).json({ success: false, message: 'Username, email, dan password wajib diisi' });
    }
    if (password.length < 6) {
      return res.status(400).json({ success: false, message: 'Password minimal 6 karakter' });
    }

    // Check existing
    const existing = await User.findOne({ where: { email } });
    if (existing) {
      return res.status(409).json({ success: false, message: 'Email sudah terdaftar. Silakan login.' });
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    const user = await User.create({
      username,
      email,
      password: hashedPassword,
      referral_code: uuidv4().slice(0, 8).toUpperCase(),
    });

    // Send welcome email
    try {
      await sendEmail(welcomeEmail(user));
    } catch (emailErr) {
      console.error('[Auth] Welcome email failed:', emailErr.message);
    }

    const { token } = issueTokens(user, res);

    res.status(201).json({
      success: true,
      message: 'Registrasi berhasil!',
      token,
      user: { id: user.id, username: user.username, email: user.email },
    });
  } catch (err) {
    console.error('[Auth] Register error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Login (Local with 2FA & IP tracking) ────────────
router.post('/login', authLimiter, verifyRecaptcha, async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ success: false, message: 'Email dan password wajib diisi' });
    }

    // Allow demo login fallback
    const demoEmail = process.env.DEMO_USER_EMAIL;
    const demoPass = process.env.DEMO_USER_PASSWORD;
    if (demoEmail && demoPass && email === demoEmail && password === demoPass) {
      let user = await User.findOne({ where: { email: demoEmail } });
      if (!user) {
        user = await User.create({
          username: 'Demo User', email: demoEmail, google_id: 'demo_' + Date.now(),
          referral_code: 'DEMO' + Date.now().toString(36).toUpperCase().slice(-4), xcredits: 50000,
        });
      }
      await trackLogin(user, req);
      const { token } = issueTokens(user, res);
      return res.json({ success: true, token, user: { id: user.id, username: user.username, email: user.email } });
    }

    const user = await User.findOne({ where: { email } });
    if (!user || !user.password) {
      return res.status(401).json({ success: false, message: 'Email atau password salah' });
    }

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      return res.status(401).json({ success: false, message: 'Email atau password salah' });
    }

    // ── 2FA Check ──
    if (user.two_factor_enabled) {
      const otpCode = generateOtp();
      await Otp.create({
        user_id: user.id,
        type: '2fa',
        otp_code: otpCode,
        expires_at: new Date(Date.now() + 5 * 60 * 1000), // 5 min
      });

      // Send OTP via preferred method
      if (user.two_factor_type === 'wa' && user.phone && user.wa_linked) {
        sendMessage(user.phone, otpMessage(otpCode, '2fa')).catch(() => {});
      } else {
        sendEmail(otpEmail(user.email, otpCode, '2fa')).catch(() => {});
      }

      // Return partial response indicating 2FA required
      const tempToken = jwt.sign({ id: user.id, purpose: '2fa' }, process.env.JWT_SECRET, { expiresIn: '5m' });
      return res.json({
        success: true,
        require_2fa: true,
        temp_token: tempToken,
        method: user.two_factor_type === 'wa' && user.phone && user.wa_linked ? 'wa' : 'email',
        message: 'Kode OTP telah dikirim',
      });
    }

    // No 2FA — track and issue tokens
    await trackLogin(user, req);
    const { token } = issueTokens(user, res);

    res.json({
      success: true,
      token,
      user: { id: user.id, username: user.username, email: user.email, avatar: user.avatar },
    });
  } catch (err) {
    console.error('[Auth] Login error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Verify 2FA OTP ──────────────────────────────────
router.post('/verify-2fa', authLimiter, verifyRecaptcha, async (req, res) => {
  try {
    const { temp_token, otp_code } = req.body;

    if (!temp_token || !otp_code) {
      return res.status(400).json({ success: false, message: 'Token dan kode OTP wajib diisi' });
    }

    let decoded;
    try {
      decoded = jwt.verify(temp_token, process.env.JWT_SECRET);
    } catch {
      return res.status(401).json({ success: false, message: 'Sesi verifikasi telah kedaluwarsa. Silakan login ulang.' });
    }

    if (decoded.purpose !== '2fa') {
      return res.status(400).json({ success: false, message: 'Token tidak valid' });
    }

    const otp = await Otp.findOne({
      where: { user_id: decoded.id, type: '2fa', otp_code, used: false },
      order: [['created_at', 'DESC']],
    });

    if (!otp || new Date() > otp.expires_at) {
      return res.status(400).json({ success: false, message: 'Kode OTP tidak valid atau sudah kedaluwarsa' });
    }

    await otp.update({ used: true });

    const user = await User.findByPk(decoded.id);
    if (!user) return res.status(404).json({ success: false, message: 'User tidak ditemukan' });

    await trackLogin(user, req);
    const { token } = issueTokens(user, res);

    res.json({
      success: true,
      token,
      user: { id: user.id, username: user.username, email: user.email, avatar: user.avatar },
    });
  } catch (err) {
    console.error('[Auth] Verify 2FA error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Forgot Password (via Email or WA) ──────────────
router.post('/forgot-password', authLimiter, verifyRecaptcha, async (req, res) => {
  try {
    const { email, method } = req.body; // method: 'email' or 'wa'

    if (!email) {
      return res.status(400).json({ success: false, message: 'Email wajib diisi' });
    }

    const user = await User.findOne({ where: { email } });
    if (!user) {
      // Don't reveal if email exists or not
      return res.json({ success: true, message: 'Jika email terdaftar, kode OTP telah dikirim.' });
    }

    const otpCode = generateOtp();
    await Otp.create({
      user_id: user.id,
      identifier: email,
      type: 'forgot_password',
      otp_code: otpCode,
      expires_at: new Date(Date.now() + 10 * 60 * 1000), // 10 min
    });

    if (method === 'wa' && user.phone && user.wa_linked) {
      sendMessage(user.phone, otpMessage(otpCode, 'forgot_password')).catch(() => {});
    } else {
      sendEmail(otpEmail(user.email, otpCode, 'forgot_password')).catch(() => {});
    }

    res.json({ success: true, message: 'Kode OTP telah dikirim.' });
  } catch (err) {
    console.error('[Auth] Forgot password error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Reset Password (verify OTP + set new password) ──
router.post('/reset-password', authLimiter, verifyRecaptcha, async (req, res) => {
  try {
    const { email, otp_code, new_password } = req.body;

    if (!email || !otp_code || !new_password) {
      return res.status(400).json({ success: false, message: 'Semua field wajib diisi' });
    }
    if (new_password.length < 6) {
      return res.status(400).json({ success: false, message: 'Password baru minimal 6 karakter' });
    }

    const user = await User.findOne({ where: { email } });
    if (!user) {
      return res.status(400).json({ success: false, message: 'Email tidak ditemukan' });
    }

    const otp = await Otp.findOne({
      where: { user_id: user.id, type: 'forgot_password', otp_code, used: false },
      order: [['created_at', 'DESC']],
    });

    if (!otp || new Date() > otp.expires_at) {
      return res.status(400).json({ success: false, message: 'Kode OTP tidak valid atau sudah kedaluwarsa' });
    }

    await otp.update({ used: true });

    const hashedPassword = await bcrypt.hash(new_password, 12);
    await user.update({ password: hashedPassword });

    res.json({ success: true, message: 'Password berhasil direset. Silakan login kembali.' });
  } catch (err) {
    console.error('[Auth] Reset password error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

// Refresh token
router.post('/refresh', async (req, res) => {
  const refreshToken = req.cookies?.refreshToken || req.body.refreshToken;
  if (!refreshToken) return res.status(401).json({ success: false, message: 'Refresh token required' });

  try {
    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET);
    const user = await User.findByPk(decoded.id);
    if (!user) return res.status(401).json({ success: false, message: 'User not found' });

    const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.cookie('token', token, { httpOnly: true, secure: process.env.NODE_ENV === 'production', maxAge: 7 * 24 * 60 * 60 * 1000 });
    res.json({ success: true, token });
  } catch {
    res.status(401).json({ success: false, message: 'Invalid refresh token' });
  }
});

// Logout
router.post('/logout', (req, res) => {
  res.clearCookie('token');
  res.clearCookie('refreshToken');
  res.json({ success: true, message: 'Logged out' });
});

module.exports = router;
