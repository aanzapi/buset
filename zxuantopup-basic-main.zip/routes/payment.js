const router = require('express').Router();
const tripay = require('../services/tripay');

// GET /api/payment/channels — Get active payment channels
router.get('/channels', async (req, res) => {
  try {
    const result = await tripay.getPaymentChannels();
    res.json(result);
  } catch (err) {
    res.status(500).json({ success: false, message: 'Gagal mengambil metode pembayaran: ' + err.message });
  }
});

// GET /api/payment/fee — Calculate fee
router.get('/fee', async (req, res) => {
  try {
    const { code, amount } = req.query;
    if (!code || !amount) return res.status(400).json({ success: false, message: 'code dan amount wajib' });
    const result = await tripay.calculateFee(code, parseInt(amount));
    res.json(result);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/payment/status/:reference — Check payment status
router.get('/status/:reference', async (req, res) => {
  try {
    const result = await tripay.getTransactionDetail(req.params.reference);
    res.json(result);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
