const router = require('express').Router();
const { authenticate } = require('../middleware/auth');
const { adminAuth } = require('../middleware/adminAuth');
const { Order, Product, User, Announcement, Voucher } = require('../models');
const { syncProducts, checkStatus: vipCheckStatus } = require('../services/vipayment');
const { Op } = require('sequelize');
const { sequelize } = require('../models');

router.use(authenticate);
router.use(adminAuth);

// ─── Dashboard Stats ──────────────────────────────────
router.get('/dashboard', async (req, res) => {
  try {
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const thisMonth = new Date(); thisMonth.setDate(1); thisMonth.setHours(0, 0, 0, 0);

    const [totalOrders, todayOrders, monthOrders, totalPaid, totalUsers, totalProducts, activeVouchers,
           grossRevenue, monthRevenue, pendingOrders, processingOrders, failedOrders, successOrders, unpaidOrders] = await Promise.all([
      Order.count(),
      Order.count({ where: { created_at: { [Op.gte]: today } } }),
      Order.count({ where: { created_at: { [Op.gte]: thisMonth } } }),
      Order.count({ where: { payment_status: 'PAID' } }),
      User.count(),
      Product.count({ where: { status: 'available' } }),
      Voucher.count({ where: { active: true } }),
      Order.sum('price', { where: { payment_status: 'PAID' } }),
      Order.sum('price', { where: { payment_status: 'PAID', created_at: { [Op.gte]: thisMonth } } }),
      Order.count({ where: { fulfill_status: 'pending', payment_status: 'PAID' } }),
      Order.count({ where: { fulfill_status: 'processing' } }),
      Order.count({ where: { fulfill_status: 'failed' } }),
      Order.count({ where: { fulfill_status: 'success' } }),
      Order.count({ where: { payment_status: 'UNPAID' } }),
    ]);

    const paidRatio = totalOrders > 0 ? Math.round((totalPaid / totalOrders) * 100) : 0;

    // Revenue chart last 7 days
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const [revenueChart] = await sequelize.query(`
      SELECT DATE(created_at) as date, SUM(price) as revenue, COUNT(*) as orders,
             SUM(CASE WHEN payment_status='PAID' THEN 1 ELSE 0 END) as paid
      FROM orders WHERE created_at >= ?
      GROUP BY DATE(created_at) ORDER BY date ASC
    `, { replacements: [sevenDaysAgo] });

    // Best selling products (top 5)
    const [bestSellers] = await sequelize.query(`
      SELECT p.game_name, p.product_name, p.icon_url,
             COUNT(o.id) as total_orders,
             SUM(CASE WHEN o.payment_status='PAID' THEN 1 ELSE 0 END) as paid_orders,
             SUM(CASE WHEN o.payment_status='PAID' THEN o.price ELSE 0 END) as net_revenue
      FROM orders o JOIN products p ON o.product_id = p.id
      GROUP BY p.id ORDER BY total_orders DESC LIMIT 5
    `);

    // Total discount given
    const totalDiscount = await Order.sum('discount_amount', { where: { payment_status: 'PAID' } }) || 0;

    res.json({
      success: true,
      data: {
        totalOrders, todayOrders, monthOrders, totalPaid, totalUsers, totalProducts, activeVouchers,
        grossRevenue: grossRevenue || 0, monthRevenue: monthRevenue || 0,
        pendingOrders, processingOrders, failedOrders, successOrders, unpaidOrders,
        paidRatio, totalDiscount,
        revenueChart, bestSellers,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Orders Management ────────────────────────────────
router.get('/orders', async (req, res) => {
  try {
    const { page = 1, limit = 20, status, payment, search } = req.query;
    const where = {};
    if (status) where.fulfill_status = status;
    if (payment) where.payment_status = payment;
    if (search) {
      where[Op.or] = [
        { invoice_no: { [Op.like]: `%${search}%` } },
        { game_name: { [Op.like]: `%${search}%` } },
        { email: { [Op.like]: `%${search}%` } },
        { user_input: { [Op.like]: `%${search}%` } },
        { nickname: { [Op.like]: `%${search}%` } },
      ];
    }
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { rows, count } = await Order.findAndCountAll({
      where,
      include: [
        { model: Product, as: 'product', attributes: ['product_name', 'vip_code', 'game_name'] },
        { model: User, as: 'user', attributes: ['username', 'email'] },
      ],
      order: [['created_at', 'DESC']],
      limit: parseInt(limit), offset,
    });
    res.json({ success: true, data: rows, pagination: { total: count, page: parseInt(page), totalPages: Math.ceil(count / parseInt(limit)) } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Check VIPayment status for an order
router.post('/orders/:id/check-vip', async (req, res) => {
  try {
    const order = await Order.findByPk(req.params.id);
    if (!order || !order.vip_trxid) return res.status(404).json({ success: false, message: 'Order/TrxID tidak ditemukan' });
    const result = await vipCheckStatus(order.vip_trxid);
    if (result?.result && result.data?.[0]) {
      const d = result.data[0];
      await order.update({
        fulfill_status: d.status === 'success' ? 'success' : (d.status === 'error' ? 'failed' : d.status),
        sn: d.note || order.sn,
        completed_at: d.status === 'success' ? new Date() : null,
      });
    }
    res.json({ success: true, data: result });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Users Management ─────────────────────────────────
router.get('/users', async (req, res) => {
  try {
    const { page = 1, limit = 30, search } = req.query;
    const where = {};
    if (search) {
      where[Op.or] = [
        { username: { [Op.like]: `%${search}%` } },
        { email: { [Op.like]: `%${search}%` } },
        { phone: { [Op.like]: `%${search}%` } },
      ];
    }
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { rows, count } = await User.findAndCountAll({
      where, attributes: { exclude: ['password'] },
      order: [['created_at', 'DESC']],
      limit: parseInt(limit), offset,
    });
    res.json({ success: true, data: rows, pagination: { total: count, page: parseInt(page), totalPages: Math.ceil(count / parseInt(limit)) } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Products Management ──────────────────────────────
router.get('/products', async (req, res) => {
  try {
    const { page = 1, limit = 50, search, status } = req.query;
    const where = {};
    if (status) where.status = status;
    if (search) {
      where[Op.or] = [
        { product_name: { [Op.like]: `%${search}%` } },
        { game_name: { [Op.like]: `%${search}%` } },
        { vip_code: { [Op.like]: `%${search}%` } },
      ];
    }
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { rows, count } = await Product.findAndCountAll({
      where, order: [['game_name', 'ASC'], ['sell_price', 'ASC']],
      limit: parseInt(limit), offset,
    });
    res.json({ success: true, data: rows, pagination: { total: count, page: parseInt(page), totalPages: Math.ceil(count / parseInt(limit)) } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Sync Products
router.post('/sync-products', async (req, res) => {
  try {
    const count = await syncProducts();
    res.json({ success: true, message: `${count} produk berhasil disinkronkan` });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Vouchers CRUD ────────────────────────────────────
router.get('/vouchers', async (req, res) => {
  try {
    const { search } = req.query;
    const where = {};
    if (search) where.code = { [Op.like]: `%${search}%` };
    const data = await Voucher.findAll({ where, order: [['created_at', 'DESC']] });
    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post('/vouchers', async (req, res) => {
  try {
    const { code, discount_type, discount_value, max_discount, min_transaction, max_transaction, max_usage, applicable_games, expires_at } = req.body;
    if (!code || !discount_value) return res.status(400).json({ success: false, message: 'Kode dan nilai diskon wajib diisi' });
    const existing = await Voucher.findOne({ where: { code: code.toUpperCase() } });
    if (existing) return res.status(400).json({ success: false, message: 'Kode voucher sudah ada' });
    const item = await Voucher.create({
      code: code.toUpperCase(),
      discount_type: discount_type || 'percent',
      discount_value, max_discount: max_discount || 0,
      min_transaction: min_transaction || 0, max_transaction: max_transaction || 0,
      max_usage: max_usage || 0,
      applicable_games: applicable_games || null,
      expires_at: expires_at || null,
    });
    res.status(201).json({ success: true, data: item });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.put('/vouchers/:id', async (req, res) => {
  try {
    const item = await Voucher.findByPk(req.params.id);
    if (!item) return res.status(404).json({ success: false, message: 'Not found' });
    const updates = { ...req.body };
    if (updates.code) updates.code = updates.code.toUpperCase();
    await item.update(updates);
    res.json({ success: true, data: item });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.patch('/vouchers/:id/toggle', async (req, res) => {
  try {
    const item = await Voucher.findByPk(req.params.id);
    if (!item) return res.status(404).json({ success: false, message: 'Not found' });
    await item.update({ active: !item.active });
    res.json({ success: true, data: item });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.delete('/vouchers/:id', async (req, res) => {
  try {
    const item = await Voucher.findByPk(req.params.id);
    if (!item) return res.status(404).json({ success: false, message: 'Not found' });
    await item.destroy();
    res.json({ success: true, message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Announcements CRUD ──────────────────────────────
router.get('/announcements', async (req, res) => {
  const data = await Announcement.findAll({ order: [['created_at', 'DESC']] });
  res.json({ success: true, data });
});

router.post('/announcements', async (req, res) => {
  const item = await Announcement.create(req.body);
  res.status(201).json({ success: true, data: item });
});

router.put('/announcements/:id', async (req, res) => {
  const item = await Announcement.findByPk(req.params.id);
  if (!item) return res.status(404).json({ success: false, message: 'Not found' });
  await item.update(req.body);
  res.json({ success: true, data: item });
});

router.delete('/announcements/:id', async (req, res) => {
  const item = await Announcement.findByPk(req.params.id);
  if (!item) return res.status(404).json({ success: false, message: 'Not found' });
  await item.destroy();
  res.json({ success: true, message: 'Deleted' });
});

module.exports = router;
