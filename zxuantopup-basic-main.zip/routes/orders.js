const router = require('express').Router();
const { Order, Product, User, Voucher } = require('../models');
const { generateInvoice } = require('../utils/invoice');
const { safeMultiply } = require('../utils/currency');
const { validate, orderSchema } = require('../middleware/validate');
const { authenticate, optionalAuth } = require('../middleware/auth');
const { orderLimiter } = require('../middleware/rateLimiter');
const tripay = require('../services/tripay');
const { sendEmail, orderConfirmationEmail } = require('../services/smtp');
const { sendMessage, orderPlacedMessage } = require('../services/fonnte');

// POST /api/orders — Create new order
router.post('/', orderLimiter, optionalAuth, validate(orderSchema), async (req, res) => {
  try {
    const { product_id, user_input, user_zone, quantity, payment_method, email, phone, promo_code, nickname } = req.body;

    // Find product (by ID or VIP Code)
    let product;
    if (isNaN(product_id)) {
      product = await Product.findOne({ where: { vip_code: product_id } });
    } else {
      product = await Product.findByPk(product_id);
    }

    if (!product || product.status !== 'available') {
      return res.status(404).json({ success: false, message: 'Produk tidak tersedia' });
    }

    // Calculate price
    let totalPrice = safeMultiply(product.sell_price, quantity || 1);
    const originalPrice = totalPrice;
    const invoiceNo = generateInvoice();

    // Apply voucher if provided
    let voucherId = null;
    let voucherCode = null;
    let discountAmount = 0;
    if (promo_code) {
      const voucher = await Voucher.findOne({ where: { code: promo_code.toUpperCase(), active: true } });
      if (voucher) {
        const now = new Date();
        const notExpired = !voucher.expires_at || new Date(voucher.expires_at) > now;
        const notMaxed = voucher.max_usage === 0 || voucher.used_count < voucher.max_usage;
        const meetsMin = voucher.min_transaction === 0 || totalPrice >= voucher.min_transaction;
        const meetsMax = voucher.max_transaction === 0 || totalPrice <= voucher.max_transaction;

        if (notExpired && notMaxed && meetsMin && meetsMax) {
          if (voucher.discount_type === 'percent') {
            discountAmount = Math.floor(totalPrice * voucher.discount_value / 100);
            if (voucher.max_discount > 0) discountAmount = Math.min(discountAmount, voucher.max_discount);
          } else {
            discountAmount = voucher.discount_value;
          }
          discountAmount = Math.min(discountAmount, totalPrice);
          totalPrice -= discountAmount;
          voucherId = voucher.id;
          voucherCode = voucher.code;
          await voucher.increment('used_count');
        }
      }
    }

    // Create order
    const order = await Order.create({
      invoice_no: invoiceNo,
      user_id: req.user?.id || null,
      product_id: product.id,
      game_name: product.game_name,
      user_input,
      user_zone: user_zone || null,
      nickname: nickname || null,
      quantity: quantity || 1,
      price: totalPrice,
      original_price: originalPrice,
      discount_amount: discountAmount,
      voucher_id: voucherId,
      voucher_code: voucherCode,
      payment_method,
      email,
      phone: phone || null,
      promo_code: promo_code || null,
    });

    // Create Tripay transaction
    let tripayData = null;
    try {
      const tripayResult = await tripay.createTransaction({
        method: payment_method,
        merchantRef: invoiceNo,
        amount: totalPrice,
        customerName: req.user?.username || 'Guest',
        customerEmail: email,
        customerPhone: phone || '',
        orderItems: [{
          sku: product.vip_code,
          name: `${product.game_name} - ${product.product_name}`,
          price: product.sell_price,
          quantity: quantity || 1,
        }],
      });

      if (tripayResult.success) {
        tripayData = tripayResult.data;
        await order.update({ tripay_ref: tripayData.reference });
      }
    } catch (tripayErr) {
      console.error('[Tripay] Create transaction failed:', tripayErr.message);
    }

    // Send notifications (non-blocking)
    const orderWithProduct = { ...order.toJSON(), product_name: product.product_name };
    if (email) sendEmail(orderConfirmationEmail(orderWithProduct)).catch(() => {});
    if (phone) sendMessage(phone, orderPlacedMessage(orderWithProduct)).catch(() => {});

    res.status(201).json({
      success: true,
      data: {
        order: {
          invoice_no: invoiceNo,
          game_name: product.game_name,
          product_name: product.product_name,
          price: totalPrice,
          payment_status: 'UNPAID',
          fulfill_status: 'pending',
        },
        payment: tripayData,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/orders/:invoiceNo — Get order by invoice number
router.get('/:invoiceNo', async (req, res) => {
  try {
    const order = await Order.findOne({
      where: { invoice_no: req.params.invoiceNo },
      include: [{ model: Product, as: 'product', attributes: ['game_name', 'product_name', 'vip_code', 'icon_url'] }],
    });

    if (!order) {
      return res.status(404).json({ success: false, message: 'Invoice tidak ditemukan' });
    }

    res.json({ success: true, data: order });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/orders/:invoiceNo/check-status — Manually poll Tripay or VIPayment for status
router.get('/:invoiceNo/check-status', async (req, res) => {
  try {
    const order = await Order.findOne({ 
      where: { invoice_no: req.params.invoiceNo },
      include: [{ model: Product, as: 'product' }]
    });
    if (!order) return res.status(404).json({ success: false, message: 'Invoice tidak ditemukan' });

    // If already paid, check VIPayment if it's still processing
    if (order.payment_status === 'PAID') {
      if (order.fulfill_status === 'processing' && order.vip_trxid) {
        const vipayment = require('../services/vipayment');
        try {
          const vipStatusRes = await vipayment.checkStatus(order.vip_trxid);
          if (vipStatusRes && vipStatusRes.result && vipStatusRes.data && vipStatusRes.data.length > 0) {
            const vipData = vipStatusRes.data[0];
            if (vipData.status === 'success' || vipData.status === 'error') {
              const fulfillStatus = vipData.status === 'success' ? 'success' : 'failed';
              const sn = vipData.note || '';
              const maskProvider = (text) => {
                if (!text || typeof text !== 'string') return text;
                return text.replace(/vip[-\s]?reseller/gi, '${process.env.APP_NAME}')
                           .replace(/vipresel(?:ler)?/gi, '${process.env.APP_NAME}')
                           .replace(/vip-reseller\.co\.id/gi, '${process.env.APP_DOMAIN}');
              };
              const maskedSn = maskProvider(sn);

              await order.update({
                fulfill_status: fulfillStatus,
                completed_at: fulfillStatus === 'success' ? new Date() : null,
                sn: maskedSn || order.sn,
              });

              // Send notifications
              const { sendMessage, orderSuccessMessage, orderFailedMessage, streamingResultMessage } = require('../services/fonnte');
              const { sendEmail, orderSuccessEmail, orderFailedEmail } = require('../services/smtp');
              
              const category = order.product?.category || 'game';
              const orderData = {
                ...order.toJSON(),
                product_name: order.product?.product_name || 'N/A',
                sn: maskedSn || order.sn,
              };

              if (fulfillStatus === 'success') {
                const successMsg = (category === 'streaming' || category === 'premium_app')
                  ? streamingResultMessage(orderData)
                  : orderSuccessMessage(orderData);
                if (order.email) sendEmail(orderSuccessEmail(orderData)).catch(() => {});
                if (order.phone) sendMessage(order.phone, successMsg).catch(() => {});
              } else {
                if (order.phone) sendMessage(order.phone, orderFailedMessage(orderData)).catch(() => {});
                if (order.email) sendEmail(orderFailedEmail(orderData)).catch(() => {});
              }
            }
          }
        } catch (e) {
          console.error('[Poll VIPayment Error]:', e.message);
        }
      }
      return res.json({ success: true, status: 'PAID', data: order });
    }

    if (!order.tripay_ref) {
      return res.status(400).json({ success: false, message: 'Reference Tripay tidak ditemukan' });
    }

    // Check Tripay API
    const tripayDetail = await tripay.getTransactionDetail(order.tripay_ref);
    if (tripayDetail && tripayDetail.success) {
      const tripayStatus = tripayDetail.data.status;

      if (tripayStatus === 'PAID') {
        const { processPaidOrder } = require('../services/fulfillment');
        await processPaidOrder(order.id);
        
        // Fetch updated order
        const updatedOrder = await Order.findByPk(order.id);
        return res.json({ success: true, status: 'PAID', data: updatedOrder });
      } else {
        return res.json({ success: true, status: tripayStatus, data: order });
      }
    }

    res.json({ success: false, message: 'Gagal mengecek status ke Tripay' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/orders/validate-voucher — Public voucher validation
router.post('/validate-voucher', async (req, res) => {
  try {
    const { code, amount, game_slug } = req.body;
    if (!code) return res.status(400).json({ success: false, message: 'Kode voucher wajib diisi' });

    const voucher = await Voucher.findOne({ where: { code: code.toUpperCase(), active: true } });
    if (!voucher) return res.json({ success: false, message: 'Voucher tidak ditemukan atau tidak aktif' });

    const now = new Date();
    if (voucher.expires_at && new Date(voucher.expires_at) <= now) {
      return res.json({ success: false, message: 'Voucher sudah kadaluarsa' });
    }
    if (voucher.max_usage > 0 && voucher.used_count >= voucher.max_usage) {
      return res.json({ success: false, message: 'Voucher sudah mencapai batas penggunaan' });
    }
    if (amount && voucher.min_transaction > 0 && amount < voucher.min_transaction) {
      return res.json({ success: false, message: `Minimal transaksi Rp ${voucher.min_transaction.toLocaleString()}` });
    }
    if (amount && voucher.max_transaction > 0 && amount > voucher.max_transaction) {
      return res.json({ success: false, message: `Maksimal transaksi Rp ${voucher.max_transaction.toLocaleString()}` });
    }

    // Check game filter
    const applicableGames = voucher.applicable_games;
    if (applicableGames && game_slug && !applicableGames.includes(game_slug)) {
      return res.json({ success: false, message: 'Voucher tidak berlaku untuk game ini' });
    }

    // Calculate discount preview
    let discountAmount = 0;
    if (amount) {
      if (voucher.discount_type === 'percent') {
        discountAmount = Math.floor(amount * voucher.discount_value / 100);
        if (voucher.max_discount > 0) discountAmount = Math.min(discountAmount, voucher.max_discount);
      } else {
        discountAmount = voucher.discount_value;
      }
      discountAmount = Math.min(discountAmount, amount);
    }

    res.json({
      success: true,
      data: {
        code: voucher.code,
        discount_type: voucher.discount_type,
        discount_value: voucher.discount_value,
        max_discount: voucher.max_discount,
        discount_amount: discountAmount,
        final_price: amount ? amount - discountAmount : null,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
