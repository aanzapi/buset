const router = require('express').Router();
const { authenticate } = require('../middleware/auth');
const { User, Order, Mutation, Product, Otp } = require('../models');
const { sendMessage, otpMessage } = require('../services/fonnte');
const { sendEmail, otpEmail } = require('../services/smtp');
const bcrypt = require('bcryptjs');

// ─── Helper: Generate 6-digit OTP ────────────────────
function generateOtp() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

router.use(authenticate);

// ─── Profile ─────────────────────────────────────────
router.get('/profile', async (req, res) => {
  // Auto-promote admin by email
  const adminEmails = (process.env.ADMIN_EMAIL || '').split(',').map(e => e.trim().toLowerCase()).filter(Boolean);
  if (req.user.role !== 'admin' && adminEmails.includes(req.user.email?.toLowerCase())) {
    await req.user.update({ role: 'admin' });
  }
  const { id, username, email, avatar, phone, role, xcredits, referral_code, wa_linked, two_factor_enabled, two_factor_type, created_at } = req.user;
  res.json({ success: true, data: { id, username, email, avatar, phone, role, xcredits, referral_code, wa_linked, two_factor_enabled, two_factor_type, password: !!req.user.password, created_at } });
});

router.put('/profile', async (req, res) => {
  try {
    const { phone, username } = req.body;
    const updates = {};
    if (phone !== undefined) updates.phone = phone;
    if (username) updates.username = username;
    await req.user.update(updates);
    res.json({ success: true, message: 'Profil diperbarui', data: req.user });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Change Password ─────────────────────────────────
router.put('/change-password', async (req, res) => {
  try {
    const { current_password, new_password } = req.body;

    if (!new_password || new_password.length < 6) {
      return res.status(400).json({ success: false, message: 'Password baru minimal 6 karakter' });
    }

    // If user has existing password, verify current
    if (req.user.password) {
      if (!current_password) {
        return res.status(400).json({ success: false, message: 'Password saat ini wajib diisi' });
      }
      const valid = await bcrypt.compare(current_password, req.user.password);
      if (!valid) {
        return res.status(400).json({ success: false, message: 'Password saat ini salah' });
      }
    }

    const hashed = await bcrypt.hash(new_password, 12);
    await req.user.update({ password: hashed });
    res.json({ success: true, message: 'Password berhasil diubah' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Link WhatsApp: Request OTP ──────────────────────
router.post('/link-wa', async (req, res) => {
  try {
    const { phone } = req.body;

    if (!phone) {
      return res.status(400).json({ success: false, message: 'Nomor WhatsApp wajib diisi' });
    }

    // Normalize phone: remove leading 0, add 62
    let normalized = phone.replace(/\D/g, '');
    if (normalized.startsWith('0')) normalized = '62' + normalized.slice(1);
    if (!normalized.startsWith('62')) normalized = '62' + normalized;

    const otpCode = generateOtp();
    await Otp.create({
      user_id: req.user.id,
      identifier: normalized,
      type: 'link_wa',
      otp_code: otpCode,
      expires_at: new Date(Date.now() + 5 * 60 * 1000),
    });

    // Send OTP via Fonnte
    await sendMessage(normalized, otpMessage(otpCode, 'link_wa'));

    res.json({ success: true, message: 'Kode OTP telah dikirim ke WhatsApp', phone: normalized });
  } catch (err) {
    console.error('[User] Link WA error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Link WhatsApp: Verify OTP ───────────────────────
router.post('/verify-wa', async (req, res) => {
  try {
    const { phone, otp_code } = req.body;

    if (!phone || !otp_code) {
      return res.status(400).json({ success: false, message: 'Nomor dan kode OTP wajib diisi' });
    }

    let normalized = phone.replace(/\D/g, '');
    if (normalized.startsWith('0')) normalized = '62' + normalized.slice(1);
    if (!normalized.startsWith('62')) normalized = '62' + normalized;

    const otp = await Otp.findOne({
      where: { user_id: req.user.id, type: 'link_wa', identifier: normalized, otp_code, used: false },
      order: [['created_at', 'DESC']],
    });

    if (!otp || new Date() > otp.expires_at) {
      return res.status(400).json({ success: false, message: 'Kode OTP tidak valid atau kedaluwarsa' });
    }

    await otp.update({ used: true });
    await req.user.update({ phone: normalized, wa_linked: true });

    res.json({ success: true, message: 'WhatsApp berhasil ditautkan!', phone: normalized });
  } catch (err) {
    console.error('[User] Verify WA error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Unlink WhatsApp ─────────────────────────────────
router.post('/unlink-wa', async (req, res) => {
  try {
    await req.user.update({ wa_linked: false });
    // If 2FA was using WA, switch to email
    if (req.user.two_factor_type === 'wa') {
      await req.user.update({ two_factor_type: 'email' });
    }
    res.json({ success: true, message: 'WhatsApp berhasil dilepas' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Toggle 2FA ──────────────────────────────────────
router.post('/toggle-2fa', async (req, res) => {
  try {
    const { enabled, type } = req.body; // type: 'email' or 'wa'

    // If enabling with WA, check if WA is linked
    if (enabled && type === 'wa' && !req.user.wa_linked) {
      return res.status(400).json({ success: false, message: 'Tautkan WhatsApp terlebih dahulu sebelum mengaktifkan 2FA via WA' });
    }

    // If user has no password (Google-only), they need to set one first
    if (enabled && !req.user.password) {
      return res.status(400).json({ success: false, message: 'Buat password terlebih dahulu di pengaturan profil sebelum mengaktifkan 2FA' });
    }

    await req.user.update({
      two_factor_enabled: !!enabled,
      two_factor_type: type === 'wa' ? 'wa' : 'email',
    });

    res.json({
      success: true,
      message: enabled ? 'Verifikasi 2 langkah berhasil diaktifkan' : 'Verifikasi 2 langkah berhasil dinonaktifkan',
      two_factor_enabled: !!enabled,
      two_factor_type: type === 'wa' ? 'wa' : 'email',
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ─── Transactions ────────────────────────────────────
router.get('/transactions', async (req, res) => {
  try {
    const { page = 1, limit = 20, status } = req.query;
    const where = { user_id: req.user.id };
    if (status) where.fulfill_status = status;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { rows, count } = await Order.findAndCountAll({
      where,
      include: [{ model: Product, as: 'product', attributes: ['game_name', 'product_name'] }],
      order: [['created_at', 'DESC']],
      limit: parseInt(limit), offset,
    });
    res.json({ success: true, data: rows, pagination: { total: count, page: parseInt(page), totalPages: Math.ceil(count / parseInt(limit)) } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.get('/mutations', async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { rows, count } = await Mutation.findAndCountAll({
      where: { user_id: req.user.id },
      order: [['created_at', 'DESC']],
      limit: parseInt(limit), offset,
    });
    res.json({ success: true, data: rows, pagination: { total: count, page: parseInt(page), totalPages: Math.ceil(count / parseInt(limit)) } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.get('/dashboard', async (req, res) => {
  try {
    const { Op } = require('sequelize');
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const [total, todayCount, pending, processing, success, failed] = await Promise.all([
      Order.count({ where: { user_id: req.user.id } }),
      Order.count({ where: { user_id: req.user.id, created_at: { [Op.gte]: today } } }),
      Order.count({ where: { user_id: req.user.id, fulfill_status: 'pending' } }),
      Order.count({ where: { user_id: req.user.id, fulfill_status: 'processing' } }),
      Order.count({ where: { user_id: req.user.id, fulfill_status: 'success' } }),
      Order.count({ where: { user_id: req.user.id, fulfill_status: 'failed' } }),
    ]);
    res.json({ success: true, data: { total, todayCount, pending, processing, success, failed, xcredits: req.user.xcredits } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
