const router = require('express').Router();
const { Op } = require('sequelize');
const { Product, sequelize } = require('../models');
const { getNickname } = require('../services/vipayment');
const { validate, nicknameSchema } = require('../middleware/validate');

// GET /api/products — List all products with filters
router.get('/', async (req, res) => {
  try {
    const { category, search, game, page = 1, limit = 50 } = req.query;
    const where = { status: 'available' };

    if (category && category !== 'all') where.category = category;
    if (game) where.game_slug = game;
    if (search) {
      where[Op.or] = [
        { game_name: { [Op.like]: `%${search}%` } },
        { product_name: { [Op.like]: `%${search}%` } },
      ];
    }

    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { rows, count } = await Product.findAndCountAll({
      where,
      order: [['game_name', 'ASC'], ['sell_price', 'ASC']],
      limit: parseInt(limit),
      offset,
    });

    res.json({
      success: true,
      data: rows,
      pagination: {
        total: count,
        page: parseInt(page),
        limit: parseInt(limit),
        totalPages: Math.ceil(count / parseInt(limit)),
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/products/games — List all unique games (for homepage grid)
router.get('/games', async (req, res) => {
  try {
    const { category } = req.query;
    const where = { status: 'available' };
    if (category && category !== 'all') where.category = category;

    const games = await Product.findAll({
      where,
      attributes: [
        'game_name', 'game_slug', 'category',
        [sequelize.fn('MIN', sequelize.col('sell_price')), 'min_price'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'product_count'],
      ],
      group: ['game_name', 'game_slug', 'category'],
      order: [['game_name', 'ASC']],
    });

    res.json({ success: true, data: games });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/products/trending — Get trending games (top by product count)
router.get('/trending', async (req, res) => {
  try {
    const trending = await Product.findAll({
      where: { status: 'available' },
      attributes: [
        'game_name', 'game_slug', 'category',
        [sequelize.fn('COUNT', sequelize.col('id')), 'product_count'],
        [sequelize.fn('MIN', sequelize.col('sell_price')), 'min_price'],
      ],
      group: ['game_name', 'game_slug', 'category'],
      order: [[sequelize.fn('COUNT', sequelize.col('id')), 'DESC']],
      limit: 10,
    });

    res.json({ success: true, data: trending });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/products/:gameSlug — Get all products for a specific game
router.get('/:gameSlug', async (req, res) => {
  try {
    const products = await Product.findAll({
      where: { game_slug: req.params.gameSlug, status: 'available' },
      order: [['sell_price', 'ASC']],
    });

    if (!products.length) {
      return res.status(404).json({ success: false, message: 'Game tidak ditemukan' });
    }

    res.json({
      success: true,
      data: {
        game_name: products[0].game_name,
        game_slug: products[0].game_slug,
        category: products[0].category,
        products,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/products/check-nickname — Verify player nickname
router.post('/check-nickname', validate(nicknameSchema), async (req, res) => {
  try {
    const { game, user_id, zone_id } = req.body;
    const result = await getNickname(game, user_id, zone_id || '');

    if (result && result.result === true) {
      res.json({ success: true, data: { nickname: result.data } });
    } else {
      res.json({ success: false, message: result?.message || 'Nickname tidak ditemukan. Periksa ID kamu.' });
    }
  } catch (err) {
    res.status(500).json({ success: false, message: 'Gagal verifikasi nickname: ' + err.message });
  }
});

module.exports = router;
