const express = require('express');
const router = express.Router();
const { Order, Product } = require('../models');
const tripay = require('../services/tripay');
const vipayment = require('../services/vipayment');
const { sendMessage, orderSuccessMessage, orderFailedMessage, orderPaidMessage, streamingResultMessage } = require('../services/fonnte');
const { sendEmail, orderSuccessEmail, orderPaidEmail, orderFailedEmail } = require('../services/smtp');

// ─── Helper: Mask VIPReseller branding ───────────────
function maskProvider(text) {
  if (!text || typeof text !== 'string') return text;
  return text.replace(/vip[-\s]?reseller/gi, '${process.env.APP_NAME}')
             .replace(/vipresel(?:ler)?/gi, '${process.env.APP_NAME}')
             .replace(/vip-reseller\.co\.id/gi, '${process.env.APP_DOMAIN}');
}

// POST /api/webhook/tripay — Tripay callback
router.post('/tripay', async (req, res) => {
  try {
    const json = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
    const callbackSignature = req.headers['x-callback-signature'];

    // Verify signature
    if (!tripay.verifyCallbackSignature(json, callbackSignature)) {
      return res.status(400).json({ success: false, message: 'Invalid signature' });
    }

    const data = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    const event = req.headers['x-callback-event'];

    if (event !== 'payment_status') {
      return res.json({ success: true });
    }

    const { merchant_ref, status } = data;

    // Find order
    const order = await Order.findOne({ where: { invoice_no: merchant_ref } });
    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    // If status is PAID and not already processed
    if (status === 'PAID' && order.payment_status !== 'PAID') {
      const { processPaidOrder } = require('../services/fulfillment');
      await processPaidOrder(order.id);

      // Emit socket event
      const io = req.app.get('io');
      if (io) io.to(`order:${merchant_ref}`).emit('order-update', { 
        invoice_no: merchant_ref, 
        payment_status: 'PAID', 
        fulfill_status: 'processing' 
      });
    } else {
      // Update other statuses like EXPIRED or FAILED
      await order.update({ payment_status: status });
    }

    res.json({ success: true });
  } catch (err) {
    console.error('[Webhook/Tripay] Error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/webhook/vipayment — VIPayment callback
router.post('/vipayment', async (req, res) => {
  try {
    // Verify signature: md5(API_ID + API_KEY)
    const md5 = require('md5');
    const expectedSignature = md5(process.env.VIP_API_ID + process.env.VIP_API_KEY);
    const receivedSignature = req.headers['x-client-signature'];
    
    if (receivedSignature && receivedSignature !== expectedSignature) {
      console.warn('[Webhook/VIPayment] Invalid signature');
      return res.status(400).json({ success: false, message: 'Invalid signature' });
    }

    // VIPayment sends data wrapped in req.body.data object
    const payload = req.body.data || req.body;
    const { trxid, status, note, service } = payload;
    const sn = payload.note || '';

    console.log('[Webhook/VIPayment] Received:', { trxid, status, note, service });

    const order = await Order.findOne({
      where: { vip_trxid: trxid },
      include: [{ model: Product, as: 'product', attributes: ['game_name', 'product_name', 'category'] }],
    });
    if (!order) {
      console.warn(`[Webhook/VIPayment] Order not found for trxid: ${trxid}`);
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    const fulfillStatus = status === 'success' ? 'success' : (status === 'error' ? 'failed' : 'processing');
    const maskedSn = maskProvider(sn || note || null);

    await order.update({
      fulfill_status: fulfillStatus,
      completed_at: fulfillStatus === 'success' ? new Date() : null,
      sn: maskedSn || order.sn,
    });

    // ── Determine notification type ──
    const category = order.product?.category || 'game';
    const orderData = {
      ...order.toJSON(),
      product_name: order.product?.product_name || 'N/A',
      sn: maskedSn,
    };

    if (fulfillStatus === 'success') {
      const successMsg = (category === 'streaming' || category === 'premium_app')
        ? streamingResultMessage(orderData)
        : orderSuccessMessage(orderData);

      if (order.email) sendEmail(orderSuccessEmail(orderData)).catch(() => {});
      if (order.phone) sendMessage(order.phone, successMsg).catch(() => {});
    } else if (fulfillStatus === 'failed') {
      if (order.phone) sendMessage(order.phone, orderFailedMessage(orderData)).catch(() => {});
      if (order.email) sendEmail(orderFailedEmail(orderData)).catch(() => {});
    }

    // Emit socket event
    const io = req.app.get('io');
    if (io) io.to(`order:${order.invoice_no}`).emit('order-update', { invoice_no: order.invoice_no, fulfill_status: fulfillStatus });

    res.json({ success: true });
  } catch (err) {
    console.error('[Webhook/VIPayment] Error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
