const router = require('express').Router();
const { getServices, getCategory, calculateSellPrice } = require('../services/vipayment');
const { getGameIcon } = require('../services/gameIcons');
const { slugify } = require('../utils/slugify');
const redis = require('../services/redis');

const CACHE_KEY = 'vip:services:all';
const CACHE_TTL = 300; // 5 minutes cache
const GAMES_CACHE_KEY = 'vip:games:grouped';
const GAMES_CACHE_TTL = 300;

// Upstash REST SDK auto-parses JSON, so we need to handle both cases
function safeParse(val) {
  if (!val) return null;
  if (typeof val === 'string') {
    try { return JSON.parse(val); } catch { return val; }
  }
  return val; // already parsed by Upstash
}

/**
 * Enrich a raw VIPayment service item with icon, category, sell price, slug
 */
function enrichService(s) {
  return {
    code: s.code,
    game: s.game,
    game_slug: slugify(s.game),
    name: s.name,
    category: getCategory(s.game),
    icon: getGameIcon(s.game),
    price_basic: s.price?.basic || 0,
    price_special: s.price?.special || 0,
    sell_price: calculateSellPrice(s.price?.special || s.price?.basic || 0),
    description: s.description || '',
    server: s.server || '',
    status: s.status,
  };
}

/**
 * Get all enriched services (from cache or API or fallback)
 */
async function getAllServices() {
  const cached = await redis.get(CACHE_KEY);
  const parsed = safeParse(cached);
  if (parsed && Array.isArray(parsed)) return parsed;

  try {
    const result = await getServices();
    if (!result || !result.data) {
      console.error('[VIPayment] Raw Response:', result);
      throw new Error(result?.message || 'VIPayment API tidak tersedia');
    }

    const raw = Array.isArray(result.data) ? result.data : Object.values(result.data);
    const enriched = raw.map(enrichService);

    await redis.set(CACHE_KEY, JSON.stringify(enriched), CACHE_TTL);
    return enriched;
  } catch (err) {
    console.error('[VIPayment API Failed] Trying local fallback:', err.message);
    const fs = require('fs');
    const path = require('path');

    // Try all_data first (has ALL products including empty/out-of-stock)
    const allDataPath = path.join(__dirname, '..', 'output', 'vip_reseller_all_data.json');
    if (fs.existsSync(allDataPath)) {
      try {
        const rawJson = JSON.parse(fs.readFileSync(allDataPath, 'utf8'));
        // all_data.json is object-keyed by game name, each value is array of products
        let products = [];
        if (Array.isArray(rawJson)) {
          products = rawJson;
        } else {
          // It's an object: { "Game Name": [ {...}, {...} ], ... }
          for (const gameProducts of Object.values(rawJson)) {
            if (Array.isArray(gameProducts)) {
              products.push(...gameProducts);
            }
          }
        }
        if (products.length > 0) {
          const enriched = products.map(enrichService);
          return enriched;
        }
      } catch (parseErr) {
        console.error('[Fallback] Failed to parse all_data.json:', parseErr.message);
      }
    }

    // Fallback 2: available only
    const localPath = path.join(__dirname, '..', 'output', 'vip_reseller_available.json');
    if (fs.existsSync(localPath)) {
      const local = JSON.parse(fs.readFileSync(localPath, 'utf8'));
      const enriched = local.map(enrichService);
      return enriched;
    }
    throw err;
  }
}

/**
 * GET /api/v2/services
 * Fetch ALL services from VIPayment (with Redis cache)
 */
router.get('/services', async (req, res) => {
  try {
    const services = await getAllServices();
    res.json({ success: true, data: services, count: services.length });
  } catch (err) {
    console.error('[V2/Services] Error:', err.message);
    res.status(500).json({ success: false, message: 'Gagal memuat layanan: ' + err.message });
  }
});

/**
 * GET /api/v2/games
 * Get grouped games list (unique games with icon, min price, product count)
 * This is what the homepage uses
 */
router.get('/games', async (req, res) => {
  try {
    const { category } = req.query;

    // Try cache
    const cacheKey = category && category !== 'all' ? `${GAMES_CACHE_KEY}:${category}` : GAMES_CACHE_KEY;
    const cachedGames = safeParse(await redis.get(cacheKey));
    if (cachedGames && Array.isArray(cachedGames)) {
      return res.json({ success: true, data: cachedGames, cached: true, count: cachedGames.length });
    }

    // Get all services
    const services = await getAllServices();

    // Filter available only
    let available = services.filter((s) => s.status === 'available');
    if (category && category !== 'all') {
      available = available.filter((s) => s.category === category);
    }

    // Group by game name
    const gameMap = {};
    for (const s of available) {
      if (!gameMap[s.game]) {
        gameMap[s.game] = {
          name: s.game,
          slug: s.game_slug,
          category: s.category,
          icon: s.icon,
          min_price: s.sell_price,
          product_count: 0,
        };
      }
      gameMap[s.game].product_count++;
      if (s.sell_price < gameMap[s.game].min_price) {
        gameMap[s.game].min_price = s.sell_price;
      }
    }

    const games = Object.values(gameMap).sort((a, b) => a.name.localeCompare(b.name));

    await redis.set(cacheKey, JSON.stringify(games), GAMES_CACHE_TTL);

    res.json({ success: true, data: games, cached: false, count: games.length });
  } catch (err) {
    console.error('[V2/Games] Error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * GET /api/v2/games/:slug
 * Get all products for a specific game (by slug)
 * Includes ALL products (available + out of stock)
 */
router.get('/games/:slug', async (req, res) => {
  try {
    const { slug } = req.params;
    const cacheKey = `vip:game:${slug}:all`;

    const cachedGame = safeParse(await redis.get(cacheKey));
    if (cachedGame && cachedGame.products) {
      return res.json({ success: true, data: cachedGame, cached: true });
    }

    // Get all services
    const services = await getAllServices();

    // Filter by slug — include ALL statuses (available + empty)
    const products = services
      .filter((s) => s.game_slug === slug)
      .sort((a, b) => {
        // Available first, then by price
        if (a.status === 'available' && b.status !== 'available') return -1;
        if (a.status !== 'available' && b.status === 'available') return 1;
        return a.sell_price - b.sell_price;
      });

    if (!products.length) {
      return res.status(404).json({ success: false, message: 'Game tidak ditemukan' });
    }

    const gameData = {
      name: products[0].game,
      slug: products[0].game_slug,
      category: products[0].category,
      icon: products[0].icon,
      products,
    };

    await redis.set(cacheKey, JSON.stringify(gameData), CACHE_TTL);

    res.json({ success: true, data: gameData, cached: false });
  } catch (err) {
    console.error('[V2/Game] Error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * GET /api/v2/payment-channels
 * Fetch payment channels from Tripay (with Redis cache)
 */
router.get('/payment-channels', async (req, res) => {
  try {
    const PAYMENT_CACHE_KEY = 'tripay:channels';
    const PAYMENT_CACHE_TTL = 3600; // 1 hour

    const cached = safeParse(await redis.get(PAYMENT_CACHE_KEY));
    if (cached && Array.isArray(cached)) {
      return res.json({ success: true, data: cached, cached: true });
    }

    const { getPaymentChannels } = require('../services/tripay');
    const result = await getPaymentChannels();

    if (!result.success) {
      throw new Error(result.message || 'Gagal mengambil channel pembayaran');
    }

    // Group by category
    const channels = result.data.filter(ch => ch.active).map(ch => ({
      code: ch.code,
      name: ch.name,
      group: ch.group,
      type: ch.type,
      icon_url: ch.icon_url,
      fee_flat: ch.total_fee?.flat || 0,
      fee_percent: parseFloat(ch.total_fee?.percent || '0'),
      min_amount: ch.minimum_amount || 0,
      max_amount: ch.maximum_amount || 0,
      active: ch.active,
    }));

    await redis.set(PAYMENT_CACHE_KEY, JSON.stringify(channels), PAYMENT_CACHE_TTL);

    res.json({ success: true, data: channels, cached: false });
  } catch (err) {
    console.error('[V2/PaymentChannels] Error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * GET /api/v2/leaderboard
 * Get top spenders from the database
 */
router.get('/leaderboard', async (req, res) => {
  try {
    const { period } = req.query; // 'today', 'yesterday', 'week', 'month', 'all'
    const { Order } = require('../models');
    const { Op } = require('sequelize');

    let dateFilter = {};
    const now = new Date();
    
    if (period === 'today') {
      const start = new Date(now.setHours(0,0,0,0));
      dateFilter = { createdAt: { [Op.gte]: start } };
    } else if (period === 'yesterday') {
      const end = new Date(now.setHours(0,0,0,0));
      const start = new Date(end.getTime() - 24 * 60 * 60 * 1000);
      dateFilter = { createdAt: { [Op.between]: [start, end] } };
    } else if (period === 'week') {
      const start = new Date(now.setDate(now.getDate() - now.getDay()));
      start.setHours(0,0,0,0);
      dateFilter = { createdAt: { [Op.gte]: start } };
    } else if (period === 'month') {
      const start = new Date(now.getFullYear(), now.getMonth(), 1);
      dateFilter = { createdAt: { [Op.gte]: start } };
    }

    // Since we want top spenders, we group by email (or user_id)
    const sequelize = require('../models').sequelize;
    const topOrders = await Order.findAll({
      where: {
        ...dateFilter,
        payment_status: 'PAID' // Only count paid orders
      },
      attributes: [
        'email',
        [sequelize.fn('SUM', sequelize.col('price')), 'total_spent'],
        [sequelize.fn('COUNT', sequelize.col('id')), 'total_orders'],
        [sequelize.fn('MAX', sequelize.col('game_name')), 'top_game'] // approximate top game
      ],
      group: ['email'],
      order: [[sequelize.literal('total_spent'), 'DESC']],
      limit: 10
    });

    const data = topOrders.map(o => ({
      username: o.email ? o.email.split('@')[0] : 'Guest',
      email: o.email || '',
      total: parseInt(o.get('total_spent') || 0),
      orders: parseInt(o.get('total_orders') || 0),
      topGame: o.get('top_game') || 'Unknown'
    }));

    res.json({ success: true, data });
  } catch (err) {
    console.error('[V2/Leaderboard] Error:', err.message);
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * POST /api/v2/chat
 * Chat with ZxuanBot (Groq AI)
 */
router.post('/chat', async (req, res) => {
  try {
    const { messages } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ success: false, message: 'Messages array required' });
    }

    // Limit to last 10 messages for context
    const recent = messages.slice(-10);
    const { chat } = require('../services/groq');
    const reply = await chat(recent);

    res.json({ success: true, reply });
  } catch (err) {
    console.error('[V2/Chat] Error:', err.message);
    res.status(500).json({ success: false, message: 'Gagal menghubungi AI' });
  }
});

module.exports = router;
