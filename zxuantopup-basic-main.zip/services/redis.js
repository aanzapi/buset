const { Redis } = require('@upstash/redis');

let redis = null;

function getRedis() {
  if (!redis) {
    const url = process.env.UPSTASH_REDIS_REST_URL;
    const token = process.env.UPSTASH_REDIS_REST_TOKEN;

    if (!url || !token) {
      console.warn('[Redis] Upstash credentials not set, using in-memory fallback');
      redis = createMemoryFallback();
      return redis;
    }

    redis = new Redis({ url, token });
    console.log('[Redis] Connected to Upstash');
  }
  return redis;
}

// Simple in-memory fallback for development without Redis
function createMemoryFallback() {
  const store = new Map();
  return {
    async get(key) { return store.get(key) || null; },
    async set(key, value, opts) {
      store.set(key, value);
      if (opts?.ex) setTimeout(() => store.delete(key), opts.ex * 1000);
      return 'OK';
    },
    async del(key) { store.delete(key); return 1; },
    async incr(key) {
      const val = (store.get(key) || 0) + 1;
      store.set(key, val);
      return val;
    },
    async keys(pattern) {
      const regex = new RegExp('^' + pattern.replace('*', '.*') + '$');
      return Array.from(store.keys()).filter(k => regex.test(k));
    },
  };
}

// Wrapper that auto-initializes and provides simple get/set with TTL
const redisClient = {
  async get(key) {
    const r = getRedis();
    const val = await r.get(key);
    return val;
  },
  async set(key, value, ttlSeconds) {
    const r = getRedis();
    if (ttlSeconds) {
      return await r.set(key, value, { ex: ttlSeconds });
    }
    return await r.set(key, value);
  },
  async del(key) {
    const r = getRedis();
    return await r.del(key);
  },
};

module.exports = redisClient;
