const axios = require('axios');
const md5 = require('md5');
const { Product } = require('../models');
const { slugify } = require('../utils/slugify');

const BASE_URL = 'https://vip-reseller.co.id/api';

function getSign() {
  return md5(process.env.VIP_API_ID + process.env.VIP_API_KEY);
}

function getAuth() {
  return { key: process.env.VIP_API_KEY, sign: getSign(), type: '' };
}

/**
 * Fetch all available services/products from VIPayment
 */
async function getServices() {
  const params = new URLSearchParams({ ...getAuth(), type: 'services' });
  const res = await axios.post(`${BASE_URL}/game-feature`, params.toString(), {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  });
  return res.data;
}

/**
 * Check stock for a specific service
 */
async function getServiceStock(code) {
  const params = new URLSearchParams({ ...getAuth(), type: 'service-stock', code });
  const res = await axios.post(`${BASE_URL}/game-feature`, params.toString(), {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  });
  return res.data;
}

const NICKNAME_GAME_CODES = {
  // ─── Games ───
  'mobile-legends': 'mobile-legends',
  'mobile-legends-region': 'mobile-legends-region',
  'free-fire': 'free-fire',
  'free-fire-max': 'free-fire',
  'call-of-duty': 'call-of-duty-mobile',
  'pubg-mobile': 'pubgm',
  'pubgm': 'pubgm',
  'genshin-impact': 'genshin-impact',
  'point-blank': 'pointblank',
  'pointblank': 'pointblank',
  'arena-of-valor': 'arena-of-valor',
  'valorant': 'valorant',
  'ace-racer': 'ace-racer',
  'life-after': 'life-after',
  'higgs-domino': 'higgs-domino',
  'honkai-star-rail': 'honkai-star-rail',
  'tower-of-fantasy': 'tower-of-fantasy',
  'honor-of-kings': 'honor-of-kings-global',
  'blood-strike': 'blood-strike',
  'metal-slug-awakening': 'metal-slug-awakening',
  'undawn': 'garena-undawn',
  'eggy-party': 'eggy-party',
  'identity-v': 'identity-v',
  'ragnarok-origin': 'ragnarok-origin',
  'ragnarok-x': 'ragnarok-x-next-generation',
  'sausage-man': 'sausage-man',
  'super-sus': 'super-sus',
  'whiteout-survival': 'whiteout-survival',
  'zenless-zone-zero': 'zenless-zone-zero',
  'marvel-snap': 'marvel-snap',
  'farlight-84': 'farlight-84',
  'arena-breakout': 'arena-breakout',
  'growtopia': 'growtopia',
  
  // ─── Streaming & Apps (Mostly for consistency) ───
  'netflix': 'netflix-premium',
  'disney-hotstar': 'disney-hotstar',
  'spotify': 'spotify-premium',
  'youtube': 'youtube-premium',
  'bstation': 'bstation-premium',
  'iqiyi': 'iqiyi-premium',
  'wetv': 'wetv-premium',
  'vidio': 'vidio-premier',
  'viu': 'viu-premium',
  'vision-plus': 'vision-plus',
  'rcti-plus': 'rcti-plus',
  'canva': 'canva-pro',
  'capcut': 'capcut-pro',
  'alight-motion': 'alight-motion',
  'getcontact': 'getcontact-premium'
};

/**
 * Verify player nickname before ordering
 */
async function getNickname(gameSlug, userId, zoneId = '') {
  let code = NICKNAME_GAME_CODES[gameSlug];
  
  if (!code) {
    const keys = Object.keys(NICKNAME_GAME_CODES).sort((a, b) => b.length - a.length);
    for (const key of keys) {
      if (gameSlug.startsWith(key)) {
        code = NICKNAME_GAME_CODES[key];
        break;
      }
    }
  }

  if (!code) code = gameSlug;

  const params = new URLSearchParams({ 
    ...getAuth(), 
    type: 'get-nickname', 
    code, 
    target: userId, 
    additional_target: zoneId 
  });

  try {
    const res = await axios.post(`${BASE_URL}/game-feature`, params.toString(), {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    });
    console.log(`[VIPayment] Check Nickname (${code}):`, res.data);
    return res.data;
  } catch (err) {
    console.error('[VIPayment] GetNickname Error:', err.response?.data || err.message);
    return { result: false, message: 'Server VIPayment sedang gangguan' };
  }
}

/**
 * Place an order to fulfill game top-up
 */
async function createOrder(code, dataNo, dataZone = '') {
  const params = new URLSearchParams({
    ...getAuth(),
    type: 'order',
    service: code,
    data_no: dataNo,
    data_zone: dataZone,
  });
  const res = await axios.post(`${BASE_URL}/game-feature`, params.toString(), {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  });
  console.log(`[VIPayment] Order (${code}):`, res.data);
  return res.data;
}

/**
 * Check order status
 */
async function checkStatus(trxId) {
  const params = new URLSearchParams({ ...getAuth(), type: 'status', trxid: trxId });
  const res = await axios.post(`${BASE_URL}/game-feature`, params.toString(), {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  });
  return res.data;
}

// ─── Game Category Mapping ────────────────────────────
const CATEGORY_MAP = {
  // Streaming & Apps
  'Amazon Prime Video': 'streaming', 'Bstation Premium': 'streaming', 'Disney Hotstar': 'streaming',
  'Netflix Premium': 'streaming', 'Spotify Premium': 'streaming', 'Youtube Premium': 'streaming',
  'WeTV Premium': 'streaming', 'Viu Premium': 'streaming', 'Vidio Premier': 'streaming',
  'iQIYI Premium': 'streaming', 'RCTI Plus': 'streaming', 'Vision Plus': 'streaming',
  'Resso Premium': 'streaming', 'TikTok Music': 'streaming', 'Telegram Premium': 'streaming',
  // Premium Apps
  'Alight Motion': 'premium_app', 'Canva Pro': 'premium_app', 'CapCut Pro': 'premium_app',
  'ChatGPT': 'premium_app', 'Gemini': 'premium_app', 'Getcontact Premium': 'premium_app',
  'PicsArt Pro': 'premium_app', 'Perplexity AI': 'premium_app', 'Warp Plus': 'premium_app',
  // Vouchers
  'Apple Gift Card': 'voucher', 'Voucher Garena Shell': 'voucher', 'Garena Shell Murah': 'voucher',
  'PO Garena Shell': 'voucher', 'Voucher Megaxus': 'voucher', 'Voucher PB Zepetto': 'voucher',
  'Voucher PSN': 'voucher', 'PlayStation Network (PSN)': 'voucher', 'Voucher Razer Gold': 'voucher',
  'Voucher Roblox': 'voucher', 'Voucher Valorant': 'voucher', 'Voucher Fortnite V Bucks': 'voucher',
  'Steam Wallet Code': 'voucher',
  // Joki
  'Mobile Legends Joki Code': 'joki', 'Mobile Legends Joki Event': 'joki',
  'Mobile Legends Joki Paket Ranked': 'joki', 'Mobile Legends Joki Rank': 'joki',
  'Mobile Legends Joki Ranked': 'joki', 'Mobile Legends Joki Ranked (Paket)': 'joki',
  'Mobile Legends Joki Ranked (Satuan)': 'joki',
};

function getCategory(gameName) {
  return CATEGORY_MAP[gameName] || 'game';
}

// ─── Margin calculation (markup percentage) ───────────
const MARGIN_PERCENT = parseInt(process.env.MARGIN_PERCENT || '8') || 8;

function calculateSellPrice(priceBasic) {
  const base = Number(priceBasic) || 0;
  const markup = Math.ceil(base * (MARGIN_PERCENT / 100));
  return base + markup;
}

/**
 * Sync all products from VIPayment into local database
 */
async function syncProducts() {
  let products = [];

  try {
    const result = await getServices();
    if (result && result.data) {
      products = Object.values(result.data);
    }
  } catch (err) {
    console.warn('[VIPayment] API unavailable, using local data...');
    const fs = require('fs');
    const path = require('path');
    const localPath = path.join(__dirname, '..', 'output', 'vip_reseller_available.json');
    if (fs.existsSync(localPath)) {
      products = JSON.parse(fs.readFileSync(localPath, 'utf8'));
    }
  }

  if (!products.length) {
    console.warn('[VIPayment] No products to sync');
    return 0;
  }

  let synced = 0;
  for (const p of products) {
    try {
      const code = p.code || p.service;
      const gameName = p.game || p.category || 'Unknown Game';
      
      if (!code) continue;

      const gameSlug = slugify(gameName);
      const priceBasic = Number(p.price?.basic || p.price_basic || 0);
      const pricePremium = Number(p.price?.premium || p.price_premium || 0);
      const priceSpecial = Number(p.price?.special || p.price_special || 0);

      await Product.upsert({
        vip_code: code,
        game_name: gameName,
        game_slug: gameSlug,
        product_name: p.name || 'Unnamed Product',
        category: getCategory(gameName),
        price_basic: priceBasic,
        price_premium: pricePremium,
        price_special: priceSpecial,
        sell_price: calculateSellPrice(priceBasic),
        description: p.description || null,
        server: p.server || null,
        status: p.status === 'available' ? 'available' : 'empty',
      });
      synced++;
    } catch (err) {
      console.error(`[Sync] Failed for product:`, err.message);
    }
  }

  console.log(`[VIPayment] Synced ${synced} products`);
  return synced;
}

module.exports = {
  getServices,
  getServiceStock,
  getNickname,
  createOrder,
  checkStatus,
  syncProducts,
  calculateSellPrice,
  getCategory,
};
