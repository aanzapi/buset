const { Order, Product } = require('../models');
const vipayment = require('./vipayment');
const { sendMessage, orderPaidMessage, orderSuccessMessage } = require('./fonnte');
const { sendEmail, orderPaidEmail, orderSuccessEmail } = require('./smtp');

/**
 * Handle successful payment: Update order, notify user, and trigger VIPayment order
 */
async function processPaidOrder(orderId) {
  const order = await Order.findByPk(orderId, {
    include: [{ model: Product, as: 'product' }]
  });

  if (!order || order.payment_status === 'PAID') return;

  // 1. Update order to PAID
  await order.update({
    payment_status: 'PAID',
    paid_at: new Date(),
  });

  const orderData = { ...order.toJSON(), product_name: order.product?.product_name || 'N/A' };

  // 2. Notify: Payment Received
  if (order.email) sendEmail(orderPaidEmail(orderData)).catch(() => {});
  if (order.phone) sendMessage(order.phone, orderPaidMessage(orderData)).catch(() => {});

  // 3. Trigger VIPayment Fulfillment
  try {
    const product = order.product;
    const vipResult = await vipayment.createOrder(
      product.vip_code,
      order.user_input,
      order.user_zone || ''
    );

    if (vipResult && vipResult.data) {
      await order.update({
        vip_trxid: vipResult.data.trxid || vipResult.data.id,
        fulfill_status: 'processing',
        sn: vipResult.data.sn || vipResult.data.note || 'Diproses sistem',
      });
      console.log(`[Fulfillment] VIPayment order created for ${order.invoice_no}: ${order.vip_trxid}`);
    } else {
      console.warn(`[Fulfillment] VIPayment response invalid for ${order.invoice_no}`, vipResult);
      await order.update({ fulfill_status: 'failed' });
    }
  } catch (err) {
    console.error(`[Fulfillment] VIPayment error for ${order.invoice_no}:`, err.message);
    await order.update({ fulfill_status: 'failed' });
  }
}

module.exports = { processPaidOrder };
