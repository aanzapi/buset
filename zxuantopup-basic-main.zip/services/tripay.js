const axios = require('axios');
const crypto = require('crypto');

const MODE = process.env.TRIPAY_MODE || 'sandbox';
const BASE_URL = MODE === 'production'
  ? 'https://tripay.co.id/api'
  : 'https://tripay.co.id/api-sandbox';

function getHeaders() {
  return {
    'Authorization': `Bearer ${process.env.TRIPAY_API_KEY}`,
    'Content-Type': 'application/json',
  };
}

/**
 * Generate HMAC-SHA256 signature for closed payment
 */
function createSignature(merchantRef, amount) {
  const str = process.env.TRIPAY_MERCHANT_CODE + merchantRef + amount;
  return crypto.createHmac('sha256', process.env.TRIPAY_PRIVATE_KEY)
    .update(str)
    .digest('hex');
}

/**
 * Verify callback signature from Tripay webhook
 */
function verifyCallbackSignature(jsonBody, receivedSignature) {
  const signature = crypto.createHmac('sha256', process.env.TRIPAY_PRIVATE_KEY)
    .update(jsonBody)
    .digest('hex');
  return signature === receivedSignature;
}

/**
 * Get active payment channels
 */
async function getPaymentChannels() {
  const res = await axios.get(`${BASE_URL}/merchant/payment-channel`, {
    headers: getHeaders(),
  });
  return res.data;
}

/**
 * Calculate fee for a specific channel and amount
 */
async function calculateFee(code, amount) {
  const res = await axios.get(`${BASE_URL}/merchant/fee-calculator`, {
    params: { code, amount },
    headers: getHeaders(),
  });
  return res.data;
}

/**
 * Create a closed payment transaction
 * @param {Object} params - { method, merchantRef, amount, customerName, customerEmail, customerPhone, orderItems, returnUrl }
 */
async function createTransaction(params) {
  const {
    method, merchantRef, amount, customerName,
    customerEmail, customerPhone, orderItems, returnUrl,
  } = params;

  const expiry = Math.floor(Date.now() / 1000) + (24 * 60 * 60); // 24 hours
  const signature = createSignature(merchantRef, amount);

  const payload = {
    method,
    merchant_ref: merchantRef,
    amount,
    customer_name: customerName,
    customer_email: customerEmail,
    customer_phone: customerPhone || '',
    order_items: orderItems,
    return_url: returnUrl || `${process.env.FRONTEND_URL}/invoice?ref=${merchantRef}`,
    expired_time: expiry,
    signature,
  };

  const res = await axios.post(`${BASE_URL}/transaction/create`, payload, {
    headers: getHeaders(),
  });
  return res.data;
}

/**
 * Get transaction detail
 */
async function getTransactionDetail(reference) {
  const res = await axios.get(`${BASE_URL}/transaction/detail`, {
    params: { reference },
    headers: getHeaders(),
  });
  return res.data;
}

/**
 * Check & update transaction status
 */
async function checkTransactionStatus(reference) {
  const res = await axios.get(`${BASE_URL}/transaction/check-status`, {
    params: { reference },
    headers: getHeaders(),
  });
  return res.data;
}

module.exports = {
  createSignature,
  verifyCallbackSignature,
  getPaymentChannels,
  calculateFee,
  createTransaction,
  getTransactionDetail,
  checkTransactionStatus,
};
