const axios = require('axios');

const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';

const SYSTEM_PROMPT = `Kamu adalah ZxuanBot, asisten AI dari ZxuanTopup.com — platform top-up game terpercaya di Indonesia.

Kamu membantu menjawab pertanyaan tentang:
- Cara top-up game (Mobile Legends, Free Fire, PUBG, Genshin Impact, dll)
- Metode pembayaran (QRIS, Dana, GoPay, OVO, ShopeePay, Bank Transfer, dll)
- Status pesanan dan invoice
- Harga dan promo
- Cara menemukan Player ID dan Server ID
- Masalah teknis dan troubleshooting

Panduan:
- Jawab dalam Bahasa Indonesia yang ramah dan santai
- Gunakan emoji untuk membuat percakapan lebih menyenangkan
- Jika tidak yakin, arahkan ke admin via WhatsApp: 6281359123789
- Jangan pernah meminta data sensitif (password, PIN, dll)
- Maksimal 150 kata per jawaban
- Selalu akhiri dengan menawarkan bantuan tambahan`;

/**
 * Chat with Groq AI
 * @param {Array} messages - Array of { role, content }
 * @returns {string} AI response
 */
async function chat(messages) {
  try {
    const res = await axios.post(GROQ_URL, {
      model: 'llama-3.1-70b-versatile',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        ...messages,
      ],
      max_tokens: 300,
      temperature: 0.7,
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.GROQ_API_KEY}`,
        'Content-Type': 'application/json',
      },
    });
    return res.data.choices[0]?.message?.content || 'Maaf, saya tidak bisa menjawab saat ini.';
  } catch (err) {
    console.error('[Groq] Error:', err.message);
    return 'Maaf, layanan AI sedang gangguan. Silakan hubungi admin via WhatsApp.';
  }
}

module.exports = { chat };
