const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_EMAIL,
    pass: process.env.SMTP_PASSWORD,
  },
});

async function sendEmail({ to, subject, html }) {
  try {
    const info = await transporter.sendMail({
      from: `"${process.env.SMTP_FROM_NAME || 'ZxuanTopup'}" <${process.env.SMTP_EMAIL}>`,
      to,
      subject,
      html,
    });
    console.log(`[SMTP] Email sent to ${to}: ${info.messageId}`);
    return info;
  } catch (err) {
    console.error(`[SMTP] Failed to send to ${to}:`, err.message);
    throw err;
  }
}

// ─── Shared Styles ────────────────────────────────────
const BRAND_ORANGE = '#FF6B00';
const BRAND_GOLD = '#FFD700';
const BG_DARK = '#0A0A0A';
const BG_CARD = '#111111';
const BG_SECTION = '#1A1A1A';
const TEXT_WHITE = '#FFFFFF';
const TEXT_MUTED = '#888888';
const TEXT_DIM = '#555555';
const BORDER = '#222222';
const LOGO_URL = 'https://upload.yilzicode.com/d/5zp8kf34rb8gvfu6'; // fallback, text logo used instead

function emailWrapper(content) {
  return `
<!DOCTYPE html>
<html lang="id">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"></head>
<body style="margin:0;padding:0;background:${BG_DARK};font-family:'Segoe UI','Helvetica Neue',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:${BG_DARK};padding:20px 0;">
    <tr><td align="center">
      <table width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:${BG_CARD};border-radius:16px;overflow:hidden;border:1px solid ${BORDER};">
        
        <!-- Header -->
        <tr>
          <td style="background:linear-gradient(135deg,${BRAND_ORANGE},#FF8C00);padding:28px 32px;text-align:center;">
            <h1 style="margin:0;font-size:24px;font-weight:900;letter-spacing:1px;">
              <span style="color:${TEXT_WHITE};">ZXUAN</span><span style="color:${BRAND_GOLD};">TOPUP</span>
            </h1>
            <p style="margin:6px 0 0;font-size:11px;color:rgba(255,255,255,0.7);letter-spacing:2px;text-transform:uppercase;">Top Up Cepat · Aman · Terpercaya</p>
          </td>
        </tr>

        <!-- Content -->
        <tr>
          <td style="padding:32px;">
            ${content}
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style="padding:20px 32px;border-top:1px solid ${BORDER};text-align:center;">
            <p style="margin:0 0 4px;font-size:10px;color:${TEXT_DIM};">© 2026 ZxuanTopup. All Rights Reserved.</p>
            <p style="margin:0;font-size:10px;color:${TEXT_DIM};">
              <a href="${process.env.FRONTEND_URL || 'https://zxuantopup.com'}" style="color:${BRAND_ORANGE};text-decoration:none;">zxuantopup.com</a>
            </p>
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

function infoRow(label, value, valueColor) {
  return `
    <tr>
      <td style="padding:8px 0;font-size:13px;color:${TEXT_MUTED};border-bottom:1px solid ${BORDER};width:40%;">${label}</td>
      <td style="padding:8px 0;font-size:13px;color:${valueColor || TEXT_WHITE};font-weight:600;border-bottom:1px solid ${BORDER};text-align:right;">${value}</td>
    </tr>`;
}

function statusBadge(text, bgColor, textColor) {
  return `<span style="display:inline-block;padding:4px 14px;border-radius:20px;background:${bgColor};color:${textColor};font-size:11px;font-weight:700;letter-spacing:0.5px;">${text}</span>`;
}

function ctaButton(text, url) {
  return `
    <table width="100%" cellpadding="0" cellspacing="0" style="margin:24px 0 0;">
      <tr><td align="center">
        <a href="${url}" style="display:inline-block;padding:14px 40px;background:${BRAND_ORANGE};color:${TEXT_WHITE};font-size:14px;font-weight:700;text-decoration:none;border-radius:10px;letter-spacing:0.5px;">
          ${text}
        </a>
      </td></tr>
    </table>`;
}

function formatRp(n) {
  return `Rp ${Number(n).toLocaleString('id-ID')}`;
}

function formatDate() {
  return new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

// ─── Email Templates ──────────────────────────────────

function welcomeEmail(user) {
  return {
    to: user.email,
    subject: '🎮 Selamat Datang di ZxuanTopup!',
    html: emailWrapper(`
      <div style="text-align:center;margin-bottom:24px;">
        <div style="width:64px;height:64px;border-radius:50%;background:${BRAND_ORANGE}20;display:inline-flex;align-items:center;justify-content:center;margin-bottom:12px;">
          <span style="font-size:28px;">🎮</span>
        </div>
        <h2 style="color:${TEXT_WHITE};font-size:20px;margin:0 0 4px;">Selamat Datang!</h2>
        <p style="color:${TEXT_MUTED};font-size:13px;margin:0;">Halo <strong style="color:${BRAND_ORANGE};">${user.username}</strong>, akun kamu berhasil dibuat.</p>
      </div>

      <div style="background:${BG_SECTION};border-radius:12px;padding:20px;margin-bottom:20px;">
        <p style="color:${TEXT_MUTED};font-size:12px;margin:0 0 12px;text-transform:uppercase;letter-spacing:1px;font-weight:700;">Keuntungan Member</p>
        <table width="100%" cellpadding="0" cellspacing="0">
          <tr><td style="padding:6px 0;font-size:13px;color:${TEXT_WHITE};">✅ Proses Top Up Instan & Otomatis</td></tr>
          <tr><td style="padding:6px 0;font-size:13px;color:${TEXT_WHITE};">✅ Harga Termurah di Indonesia</td></tr>
          <tr><td style="padding:6px 0;font-size:13px;color:${TEXT_WHITE};">✅ Notifikasi Real-time via WA & Email</td></tr>
          <tr><td style="padding:6px 0;font-size:13px;color:${TEXT_WHITE};">✅ Keamanan 2FA & Enkripsi Data</td></tr>
          <tr><td style="padding:6px 0;font-size:13px;color:${TEXT_WHITE};">✅ Support 24/7</td></tr>
        </table>
      </div>

      ${ctaButton('Mulai Top Up Sekarang →', process.env.FRONTEND_URL || 'https://zxuantopup.com')}
    `),
  };
}

function orderConfirmationEmail(order) {
  return {
    to: order.email,
    subject: `📋 Invoice ${order.invoice_no} — Menunggu Pembayaran`,
    html: emailWrapper(`
      <div style="text-align:center;margin-bottom:24px;">
        <div style="width:56px;height:56px;border-radius:50%;background:#3B82F620;display:inline-flex;align-items:center;justify-content:center;margin-bottom:12px;">
          <span style="font-size:24px;">📋</span>
        </div>
        <h2 style="color:${TEXT_WHITE};font-size:18px;margin:0 0 6px;">Invoice Baru</h2>
        ${statusBadge('MENUNGGU PEMBAYARAN', '#F59E0B20', '#F59E0B')}
      </div>

      <div style="background:${BG_SECTION};border-radius:12px;padding:20px;margin-bottom:20px;">
        <table width="100%" cellpadding="0" cellspacing="0">
          ${infoRow('No. Invoice', order.invoice_no, BRAND_ORANGE)}
          ${infoRow('Tanggal', formatDate())}
          ${infoRow('Game', order.game_name)}
          ${infoRow('Item', order.product_name || 'N/A')}
          ${infoRow('Player ID', `${order.user_input || '-'}${order.user_zone ? ` (${order.user_zone})` : ''}`)}
          ${infoRow('Metode', order.payment_method || '-')}
          ${infoRow('Total', formatRp(order.price), BRAND_ORANGE)}
        </table>
      </div>

      <div style="background:#F59E0B10;border:1px solid #F59E0B30;border-radius:10px;padding:14px;text-align:center;margin-bottom:8px;">
        <p style="margin:0;font-size:12px;color:#F59E0B;font-weight:600;">⏳ Segera selesaikan pembayaran sebelum expired</p>
      </div>

      ${ctaButton('Bayar Sekarang →', `${process.env.FRONTEND_URL}/invoice?ref=${order.invoice_no}`)}
    `),
  };
}

function orderPaidEmail(order) {
  return {
    to: order.email,
    subject: `💸 Pembayaran Diterima — ${order.invoice_no}`,
    html: emailWrapper(`
      <div style="text-align:center;margin-bottom:24px;">
        <div style="width:56px;height:56px;border-radius:50%;background:#3B82F620;display:inline-flex;align-items:center;justify-content:center;margin-bottom:12px;">
          <span style="font-size:24px;">💸</span>
        </div>
        <h2 style="color:${TEXT_WHITE};font-size:18px;margin:0 0 6px;">Pembayaran Diterima</h2>
        ${statusBadge('DIBAYAR · SEDANG DIPROSES', '#3B82F620', '#3B82F6')}
      </div>

      <div style="background:${BG_SECTION};border-radius:12px;padding:20px;margin-bottom:20px;">
        <table width="100%" cellpadding="0" cellspacing="0">
          ${infoRow('No. Invoice', order.invoice_no, BRAND_ORANGE)}
          ${infoRow('Game', order.game_name)}
          ${infoRow('Item', order.product_name || 'N/A')}
          ${infoRow('Dibayar', formatRp(order.price), '#3B82F6')}
        </table>
      </div>

      <div style="background:#3B82F610;border:1px solid #3B82F630;border-radius:10px;padding:14px;text-align:center;">
        <p style="margin:0;font-size:12px;color:#3B82F6;font-weight:600;">⏳ Pesanan sedang diproses otomatis. Estimasi 1-5 menit.</p>
      </div>
    `),
  };
}

function orderSuccessEmail(order) {
  return {
    to: order.email,
    subject: `✅ Top Up Berhasil — ${order.invoice_no}`,
    html: emailWrapper(`
      <div style="text-align:center;margin-bottom:24px;">
        <div style="width:56px;height:56px;border-radius:50%;background:#22C55E20;display:inline-flex;align-items:center;justify-content:center;margin-bottom:12px;">
          <span style="font-size:24px;">🎉</span>
        </div>
        <h2 style="color:${TEXT_WHITE};font-size:18px;margin:0 0 6px;">Top Up Berhasil!</h2>
        ${statusBadge('SUKSES', '#22C55E20', '#22C55E')}
      </div>

      <div style="background:${BG_SECTION};border-radius:12px;padding:20px;margin-bottom:20px;">
        <table width="100%" cellpadding="0" cellspacing="0">
          ${infoRow('No. Invoice', order.invoice_no, BRAND_ORANGE)}
          ${infoRow('Game', order.game_name)}
          ${infoRow('Item', order.product_name || 'N/A')}
          ${infoRow('Player ID', order.user_input || '-')}
          ${order.sn ? infoRow('SN / Keterangan', order.sn, BRAND_GOLD) : ''}
        </table>
      </div>

      <div style="background:#22C55E10;border:1px solid #22C55E30;border-radius:10px;padding:14px;text-align:center;">
        <p style="margin:0;font-size:12px;color:#22C55E;font-weight:600;">✅ Item telah berhasil dikirim ke akun kamu!</p>
      </div>

      ${ctaButton('Lihat Riwayat Transaksi →', `${process.env.FRONTEND_URL}/dashboard/transactions`)}
    `),
  };
}

function otpEmail(email, otpCode, type) {
  let title = 'Kode Keamanan OTP';
  let desc = '';
  let icon = '🔐';
  if (type === 'link_wa') { desc = 'menautkan nomor WhatsApp ke akun Anda'; icon = '📱'; }
  else if (type === '2fa') { desc = 'verifikasi login akun Anda'; icon = '🛡️'; }
  else if (type === 'forgot_password') { desc = 'mereset password akun Anda'; icon = '🔑'; title = 'Reset Password'; }

  return {
    to: email,
    subject: `${icon} ${title} — ZxuanTopup`,
    html: emailWrapper(`
      <div style="text-align:center;margin-bottom:24px;">
        <div style="width:56px;height:56px;border-radius:50%;background:${BRAND_ORANGE}20;display:inline-flex;align-items:center;justify-content:center;margin-bottom:12px;">
          <span style="font-size:24px;">${icon}</span>
        </div>
        <h2 style="color:${TEXT_WHITE};font-size:18px;margin:0 0 6px;">${title}</h2>
        <p style="color:${TEXT_MUTED};font-size:13px;margin:0;">Gunakan kode berikut untuk ${desc}</p>
      </div>

      <div style="background:${BG_SECTION};border-radius:12px;padding:24px;text-align:center;margin-bottom:20px;">
        <p style="margin:0 0 8px;font-size:11px;color:${TEXT_MUTED};text-transform:uppercase;letter-spacing:2px;">Kode OTP</p>
        <p style="margin:0;font-size:36px;font-weight:900;letter-spacing:12px;color:${BRAND_ORANGE};font-family:'Courier New',monospace;">${otpCode}</p>
        <p style="margin:10px 0 0;font-size:11px;color:${TEXT_DIM};">Berlaku selama 5 menit</p>
      </div>

      <div style="background:#EF444410;border:1px solid #EF444430;border-radius:10px;padding:14px;text-align:center;">
        <p style="margin:0;font-size:11px;color:#EF4444;font-weight:600;">⚠️ JANGAN berikan kode ini kepada siapapun, termasuk pihak ZxuanTopup.</p>
      </div>
    `),
  };
}

function loginAlertEmail(email, ip, userAgent, time) {
  return {
    to: email,
    subject: '⚠️ Login Baru Terdeteksi — ZxuanTopup',
    html: emailWrapper(`
      <div style="text-align:center;margin-bottom:24px;">
        <div style="width:56px;height:56px;border-radius:50%;background:#EF444420;display:inline-flex;align-items:center;justify-content:center;margin-bottom:12px;">
          <span style="font-size:24px;">🚨</span>
        </div>
        <h2 style="color:${TEXT_WHITE};font-size:18px;margin:0 0 6px;">Login Baru Terdeteksi</h2>
        <p style="color:${TEXT_MUTED};font-size:13px;margin:0;">Kami mendeteksi login dari perangkat yang belum pernah digunakan.</p>
      </div>

      <div style="background:${BG_SECTION};border-radius:12px;padding:20px;margin-bottom:20px;">
        <table width="100%" cellpadding="0" cellspacing="0">
          ${infoRow('Waktu', time)}
          ${infoRow('Alamat IP', ip)}
          ${infoRow('Perangkat', userAgent.length > 60 ? userAgent.substring(0, 60) + '...' : userAgent)}
        </table>
      </div>

      <div style="background:#EF444410;border:1px solid #EF444430;border-radius:10px;padding:14px;text-align:center;margin-bottom:8px;">
        <p style="margin:0;font-size:12px;color:#EF4444;font-weight:600;">⚠️ Jika ini bukan Anda, segera ubah password akun Anda!</p>
      </div>

      ${ctaButton('Amankan Akun Saya →', `${process.env.FRONTEND_URL}/dashboard/settings`)}
    `),
  };
}

function orderFailedEmail(order) {
  return {
    to: order.email,
    subject: `❌ Pesanan Gagal — ${order.invoice_no}`,
    html: emailWrapper(`
      <div style="text-align:center;margin-bottom:24px;">
        <div style="width:56px;height:56px;border-radius:50%;background:#EF444420;display:inline-flex;align-items:center;justify-content:center;margin-bottom:12px;">
          <span style="font-size:24px;">❌</span>
        </div>
        <h2 style="color:${TEXT_WHITE};font-size:18px;margin:0 0 6px;">Pesanan Gagal</h2>
        ${statusBadge('GAGAL', '#EF444420', '#EF4444')}
      </div>

      <div style="background:${BG_SECTION};border-radius:12px;padding:20px;margin-bottom:20px;">
        <table width="100%" cellpadding="0" cellspacing="0">
          ${infoRow('No. Invoice', order.invoice_no, BRAND_ORANGE)}
          ${infoRow('Game', order.game_name)}
          ${infoRow('Item', order.product_name || 'N/A')}
        </table>
      </div>

      <div style="background:#EF444410;border:1px solid #EF444430;border-radius:10px;padding:14px;text-align:center;">
        <p style="margin:0;font-size:12px;color:#EF4444;font-weight:600;">Maaf, pesanan gagal diproses. Refund dalam 1x24 jam.</p>
      </div>
    `),
  };
}

module.exports = {
  sendEmail,
  welcomeEmail,
  orderConfirmationEmail,
  orderSuccessEmail,
  otpEmail,
  loginAlertEmail,
  orderPaidEmail,
  orderFailedEmail,
};
