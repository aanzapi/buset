const axios = require('axios');

const FONNTE_URL = 'https://api.fonnte.com/send';

/**
 * Send WhatsApp message via Fonnte API
 */
async function sendMessage(target, message) {
  try {
    const res = await axios.post(FONNTE_URL, {
      target,
      message,
    }, {
      headers: {
        'Authorization': process.env.FONNTE_TOKEN,
        'Content-Type': 'application/json',
      },
    });
    console.log(`[Fonnte] Message sent to ${target}`);
    return res.data;
  } catch (err) {
    console.error(`[Fonnte] Failed to send to ${target}:`, err.message);
    throw err;
  }
}

// ─── Format Helpers ────────────────────────────────────

function formatRp(n) {
  return `Rp ${Number(n).toLocaleString('id-ID')}`;
}

function formatDate() {
  return new Date().toLocaleString('id-ID', { 
    timeZone: 'Asia/Jakarta', 
    weekday: 'long', 
    day: 'numeric', 
    month: 'long', 
    year: 'numeric', 
    hour: '2-digit', 
    minute: '2-digit',
    second: '2-digit'
  }).replace(/\./g, ':');
}

const LINE = `─────────────────────────────────`;
const FOOTER = `⚡ Diproses otomatis oleh ZxuanTopup\n🌐 zxuantopup.com | https://zxuantopup.com`;

// ─── Message Templates ────────────────────────────────

function orderPlacedMessage(order) {
  return `📋 INVOICE BARU!
${LINE}
┌ 💼 DETAIL TRANSAKSI
│
├ 📱 INFORMASI ORDER
├─ 🏷️ Game: ${order.game_name}
├─ 📦 Item: ${order.product_name || 'N/A'}
├─ 🆔 Invoice: ${order.invoice_no}
└─ ⏳ Status: Menunggu Pembayaran
│
├ 💰 RINCIAN PEMBAYARAN
├─ 💵 Total: ${formatRp(order.price)}
└─ 💳 Metode: ${order.payment_method || '-'}
│
├ 👤 DATA CUSTOMER
├─ 🆔 Target: ${order.user_input || '-'}${order.user_zone ? ` (${order.user_zone})` : ''}
${order.nickname ? `├─ 👤 Nickname: ${order.nickname}\n` : ''}└─ 📧 Kontak: ${order.phone || order.email || '-'}
│
├ ⏰ TIMESTAMP
└─ 📅 ${formatDate()}
${LINE}
⚠️ Segera selesaikan pembayaran sebelum expired.
${FOOTER}`;
}

function orderPaidMessage(order) {
  return `💸 PEMBAYARAN DITERIMA!
${LINE}
┌ 💼 DETAIL TRANSAKSI
│
├ 📱 INFORMASI ORDER
├─ 🏷️ Game: ${order.game_name}
├─ 📦 Item: ${order.product_name || 'N/A'}
├─ 🆔 Invoice: ${order.invoice_no}
└─ ⏳ Status: Sedang Diproses
│
├ 💰 RINCIAN PEMBAYARAN
├─ 💵 Dibayar: ${formatRp(order.price)}
└─ 💳 Metode: ${order.payment_method || '-'}
│
├ 👤 DATA CUSTOMER
├─ 🆔 Target: ${order.user_input || '-'}${order.user_zone ? ` (${order.user_zone})` : ''}
${order.nickname ? `└─ 👤 Nickname: ${order.nickname}` : ''}
│
├ ⏰ TIMESTAMP
└─ 📅 ${formatDate()}
${LINE}
✅ Pembayaran berhasil! Pesanan diproses (1-5 menit).
${FOOTER}`;
}

function orderSuccessMessage(order) {
  return `🎉 TOP UP BERHASIL!
${LINE}
┌ 💼 DETAIL TRANSAKSI
│
├ 📱 INFORMASI ORDER
├─ 🏷️ Game: ${order.game_name}
├─ 📦 Item: ${order.product_name || 'N/A'}
├─ 🆔 Invoice: ${order.invoice_no}
└─ ✅ Status: Berhasil Diproses
│
├ 👤 DATA CUSTOMER
├─ 🆔 Target: ${order.user_input || '-'}${order.user_zone ? ` (${order.user_zone})` : ''}
${order.nickname ? `├─ 👤 Nickname: ${order.nickname}\n` : ''}
${order.sn ? `└─ 🔑 SN/Ket: ${order.sn}` : `└─ 🔑 SN/Ket: Sukses`}
│
├ ⏰ TIMESTAMP
└─ 📅 ${formatDate()}
${LINE}
⭐ Puas dengan layanan kami? Kasih rating dong!
${FOOTER}`;
}

function streamingResultMessage(order) {
  return `🎬 PESANAN BERHASIL!
${LINE}
┌ 💼 DETAIL TRANSAKSI
│
├ 📱 INFORMASI ORDER
├─ 📺 Layanan: ${order.game_name}
├─ 📦 Paket: ${order.product_name || 'N/A'}
├─ 🆔 Invoice: ${order.invoice_no}
└─ ✅ Status: Berhasil Diproses
│
├ 📩 DETAIL AKUN / VOUCHER
${order.sn ? `└─ 🔑 Data: \n${order.sn}` : `└─ 🔑 Data: Silakan cek aplikasi/web`}
│
├ ⏰ TIMESTAMP
└─ 📅 ${formatDate()}
${LINE}
⭐ Selamat menikmati tayangan premium Anda!
${FOOTER}`;
}

function orderFailedMessage(order) {
  return `❌ PESANAN GAGAL!
${LINE}
┌ 💼 DETAIL TRANSAKSI
│
├ 📱 INFORMASI ORDER
├─ 🏷️ Game: ${order.game_name}
├─ 📦 Item: ${order.product_name || 'N/A'}
├─ 🆔 Invoice: ${order.invoice_no}
└─ ❌ Status: Gagal Diproses
│
├ 💰 RINCIAN PENGEMBALIAN
└─ 💵 Refund: ${formatRp(order.price)} (1x24 jam)
│
├ ⏰ TIMESTAMP
└─ 📅 ${formatDate()}
${LINE}
⚠️ Maaf, ada kendala dari provider. Hubungi admin.
${FOOTER}`;
}

function otpMessage(otpCode, type) {
  let context = '';
  let icon = '🔐';
  if (type === 'link_wa') { context = 'Tautkan WhatsApp'; icon = '📱'; }
  else if (type === '2fa') { context = 'Verifikasi Login'; icon = '🛡️'; }
  else if (type === 'forgot_password') { context = 'Reset Password'; icon = '🔑'; }

  return `${icon} KODE KEAMANAN OTP
${LINE}
┌ 🛡️ SISTEM KEAMANAN
│
├ 📱 INFORMASI PERMINTAAN
├─ 🎯 Layanan: ${context}
└─ ⏳ Berlaku: 5 Menit
│
├ 🔑 KODE OTP ANDA
└─ 🔢 *${otpCode}*
│
├ ⏰ TIMESTAMP
└─ 📅 ${formatDate()}
${LINE}
⛔ JANGAN berikan kode ini kepada siapapun!
${FOOTER}`;
}

module.exports = {
  sendMessage,
  orderPlacedMessage,
  orderSuccessMessage,
  orderFailedMessage,
  otpMessage,
  orderPaidMessage,
  streamingResultMessage,
};
