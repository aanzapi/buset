/**
 * Mask username for leaderboard: "Yilziii" → "Yil****"
 */
function maskName(name) {
  if (!name || name.length <= 3) return name + '***';
  return name.slice(0, 3) + '*'.repeat(Math.min(name.length - 3, 7));
}

module.exports = { maskName };
