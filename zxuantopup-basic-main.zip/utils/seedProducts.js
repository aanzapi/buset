/**
 * Seed products from local VIPayment JSON data into MySQL database
 * Usage: node utils/seedProducts.js
 */
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { sequelize, Product } = require('../models');
const { slugify } = require('./slugify');
const { getCategory, calculateSellPrice } = require('../services/vipayment');

async function seed() {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connected');
    await sequelize.sync({ alter: true });

    const filePath = path.join(__dirname, '..', 'output', 'vip_reseller_available.json');
    if (!fs.existsSync(filePath)) {
      console.error('❌ File not found:', filePath);
      process.exit(1);
    }

    const products = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    console.log(`📦 Found ${products.length} products to seed...`);

    let count = 0;
    for (const p of products) {
      try {
        await Product.upsert({
          vip_code: p.code,
          game_name: p.game,
          game_slug: slugify(p.game),
          product_name: p.name,
          category: getCategory(p.game),
          price_basic: p.price?.basic || 0,
          price_premium: p.price?.premium || 0,
          price_special: p.price?.special || 0,
          sell_price: calculateSellPrice(p.price?.basic || 0),
          description: p.description || null,
          server: p.server || null,
          status: p.status === 'available' ? 'available' : 'empty',
        });
        count++;
      } catch (err) {
        console.error(`Failed: ${p.code} — ${err.message}`);
      }
    }

    console.log(`✅ Seeded ${count} products successfully!`);
    process.exit(0);
  } catch (err) {
    console.error('❌ Seed failed:', err.message);
    process.exit(1);
  }
}

seed();
