/**
 * Format integer to Rupiah string: 14000 → "Rp 14.000"
 */
function formatRupiah(amount) {
  return `Rp ${Number(amount).toLocaleString('id-ID')}`;
}

/**
 * Safe integer multiplication (avoid floating point errors)
 */
function safeMultiply(price, quantity) {
  return Math.round(price * quantity);
}

module.exports = { formatRupiah, safeMultiply };
