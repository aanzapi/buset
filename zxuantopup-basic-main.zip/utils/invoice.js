const { v4: uuidv4 } = require('uuid');

/**
 * Generate invoice number: INV-YYYYMMDD-XXXXXX
 */
function generateInvoice() {
  const now = new Date();
  const date = now.toISOString().slice(0, 10).replace(/-/g, '');
  const random = uuidv4().replace(/-/g, '').slice(0, 6).toUpperCase();
  return `INV-${date}-${random}`;
}

module.exports = { generateInvoice };
