# 🛡️ Konfigurasi CORS (Cross-Origin Resource Sharing)

> **CORS** adalah mekanisme keamanan browser yang membatasi dari domain mana saja server API Anda (Backend) mau menerima request.  
> Jika CORS tidak disetting dengan benar, frontend Anda tidak akan bisa mengambil data dari backend.

---

## ⚙️ Bagaimana ZxuanTopup Menangani CORS?

Di ZxuanTopup, konfigurasi CORS sudah ditangani otomatis oleh middleware di dalam Express.js.  
Aplikasi membaca daftar domain yang diizinkan langsung dari file `.env`.

### 1. Mode Development (Lokal)
Saat berada di komputer lokal, frontend biasanya berjalan di `http://localhost:3001`. 
Oleh karena itu, di file `.env` pastikan Anda memasukkan:

```env
FRONTEND_URL=http://localhost:3001
```

Backend akan membaca nilai variabel `FRONTEND_URL` dan hanya menerima request dari `localhost:3001`.

### 2. Mode Production (VPS / Live Server)
Saat aplikasi di-deploy online, URL Anda akan berubah (misalnya: `https://zxuantopup.com`). Anda **WAJIB** mengubah `FRONTEND_URL` di server VPS agar backend tidak memblokir situs Anda sendiri.

```env
FRONTEND_URL=https://zxuantopup.com
```

---

## 🛠 File Terkait

Konfigurasi CORS dapat dilihat atau diedit pada file backend (misal di `index.js` atau folder konfigurasi terkait):

```javascript
// Contoh logika implementasi di backend ZxuanTopup
const cors = require('cors');

app.use(cors({
  origin: process.env.FRONTEND_URL, // Mengambil nilai dari .env
  credentials: true, // Wajib true agar session/cookies bisa dikirim
}));
```

---

## 🆘 Troubleshooting Error CORS

Jika Anda melihat error berwarna merah di **Console Browser** seperti ini:
> *`Access to fetch at '...' from origin '...' has been blocked by CORS policy`*

**Solusi:**
1. Buka file `.env` di folder utama backend Anda.
2. Pastikan `FRONTEND_URL` sama persis dengan URL yang Anda buka di browser (Hati-hati dengan penggunaan `http://` vs `https://` atau tanda `/` di akhir URL).
3. Setelah mengubah file `.env`, **restart backend Anda** (jika pakai PM2 di VPS, ketik `pm2 restart zxuan-backend`).
