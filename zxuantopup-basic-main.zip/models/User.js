const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const User = sequelize.define('User', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    google_id: {
      type: DataTypes.STRING,
      unique: { name: 'google_id', msg: 'Google ID already exists' },
      allowNull: true,
    },
    username: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
    email: {
      type: DataTypes.STRING(255),
      unique: { name: 'email', msg: 'Email already exists' },
      allowNull: false,
      validate: { isEmail: true },
    },
    avatar: {
      type: DataTypes.STRING(500),
      allowNull: true,
    },
    phone: {
      type: DataTypes.STRING(20),
      allowNull: true,
    },
    password: {
      type: DataTypes.STRING,
      allowNull: true, // true for users who logged in via Google before this update
    },
    wa_linked: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    two_factor_enabled: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    two_factor_type: {
      type: DataTypes.ENUM('email', 'wa'),
      defaultValue: 'email',
    },
    role: {
      type: DataTypes.ENUM('user', 'admin'),
      defaultValue: 'user',
    },
    xcredits: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      comment: 'Internal balance in smallest unit (Rupiah)',
    },
    referral_code: {
      type: DataTypes.STRING(20),
      unique: { name: 'referral_code', msg: 'Referral code already exists' },
      allowNull: true,
    },
    referred_by: {
      type: DataTypes.STRING(20),
      allowNull: true,
    },
  }, {
    tableName: 'users',
  });

  return User;
};
