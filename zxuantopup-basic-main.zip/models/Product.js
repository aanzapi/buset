const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Product = sequelize.define('Product', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    vip_code: {
      type: DataTypes.STRING(100),
      unique: { name: 'vip_code', msg: 'VIP code already exists' },
      allowNull: false,
      comment: 'VIPayment product code e.g. MLA3-S13',
    },
    game_name: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    game_slug: {
      type: DataTypes.STRING(255),
      allowNull: false,
      comment: 'URL-friendly slug e.g. mobile-legends-a',
    },
    product_name: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    category: {
      type: DataTypes.ENUM('game', 'premium_app', 'voucher', 'joki', 'streaming'),
      defaultValue: 'game',
    },
    price_basic: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: 'VIPayment basic price in Rupiah',
    },
    price_premium: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    price_special: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    sell_price: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: 'Our selling price to customer',
    },
    description: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    server: {
      type: DataTypes.STRING(50),
      allowNull: true,
      comment: 'VIPayment server identifier',
    },
    server_required: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    icon_url: {
      type: DataTypes.STRING(500),
      allowNull: true,
    },
    status: {
      type: DataTypes.ENUM('available', 'empty', 'disabled'),
      defaultValue: 'available',
    },
  }, {
    tableName: 'products',
    indexes: [
      { fields: ['game_slug'] },
      { fields: ['game_name'] },
      { fields: ['status'] },
      { fields: ['category'] },
    ],
  });

  return Product;
};
