const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const LeaderboardCache = sequelize.define('LeaderboardCache', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    period: {
      type: DataTypes.ENUM('daily', 'weekly', 'monthly'),
      allowNull: false,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    masked_name: {
      type: DataTypes.STRING(100),
      allowNull: false,
      comment: 'e.g. Yil*******',
    },
    total_amount: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
    rank: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
  }, {
    tableName: 'leaderboard_cache',
    indexes: [
      { fields: ['period', 'rank'] },
    ],
  });

  return LeaderboardCache;
};
