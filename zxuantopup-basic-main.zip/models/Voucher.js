const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Voucher = sequelize.define('Voucher', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    code: {
      type: DataTypes.STRING(50),
      unique: { name: 'voucher_code', msg: 'Kode voucher sudah ada' },
      allowNull: false,
    },
    discount_type: {
      type: DataTypes.ENUM('percent', 'flat'),
      defaultValue: 'percent',
      comment: 'percent = %, flat = Rp',
    },
    discount_value: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
      comment: 'Nilai diskon (% atau Rp)',
    },
    max_discount: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      comment: 'Maks diskon (Rp). 0 = unlimited',
    },
    min_transaction: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      comment: 'Min transaksi (Rp)',
    },
    max_transaction: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      comment: 'Max transaksi (Rp). 0 = unlimited',
    },
    max_usage: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      comment: '0 = unlimited',
    },
    used_count: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
    },
    applicable_games: {
      type: DataTypes.TEXT,
      allowNull: true,
      comment: 'JSON array of game slugs. null = all games',
      get() {
        const val = this.getDataValue('applicable_games');
        return val ? JSON.parse(val) : null;
      },
      set(val) {
        this.setDataValue('applicable_games', val ? JSON.stringify(val) : null);
      },
    },
    expires_at: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    active: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
  }, {
    tableName: 'vouchers',
  });

  return Voucher;
};
