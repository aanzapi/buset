const { DataTypes } = require('sequelize');

module.exports = (sequelize) => {
  const Order = sequelize.define('Order', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    invoice_no: {
      type: DataTypes.STRING(30),
      unique: { name: 'invoice_no', msg: 'Invoice number already exists' },
      allowNull: false,
      comment: 'Format: INV-YYYYMMDD-XXXXXX',
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      comment: 'Nullable for guest checkout',
    },
    product_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    game_name: {
      type: DataTypes.STRING(255),
      allowNull: false,
    },
    user_input: {
      type: DataTypes.STRING(100),
      allowNull: false,
      comment: 'Player ID',
    },
    user_zone: {
      type: DataTypes.STRING(50),
      allowNull: true,
      comment: 'Server/Zone ID',
    },
    nickname: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'Verified player nickname',
    },
    quantity: {
      type: DataTypes.INTEGER,
      defaultValue: 1,
    },
    price: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: 'Total price in Rupiah (integer)',
    },
    payment_method: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    payment_status: {
      type: DataTypes.ENUM('UNPAID', 'PAID', 'EXPIRED', 'FAILED', 'REFUND'),
      defaultValue: 'UNPAID',
    },
    tripay_ref: {
      type: DataTypes.STRING(100),
      allowNull: true,
      comment: 'Tripay transaction reference',
    },
    vip_trxid: {
      type: DataTypes.STRING(100),
      allowNull: true,
      comment: 'VIPayment transaction ID',
    },
    fulfill_status: {
      type: DataTypes.ENUM('pending', 'processing', 'success', 'failed'),
      defaultValue: 'pending',
    },
    sn: {
      type: DataTypes.STRING(255),
      allowNull: true,
      comment: 'Serial Number or Note from VIPayment',
    },
    email: {
      type: DataTypes.STRING(255),
      allowNull: true,
    },
    phone: {
      type: DataTypes.STRING(20),
      allowNull: true,
    },
    promo_code: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    voucher_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      comment: 'FK to vouchers table',
    },
    voucher_code: {
      type: DataTypes.STRING(50),
      allowNull: true,
    },
    discount_amount: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
      comment: 'Discount applied in Rp',
    },
    original_price: {
      type: DataTypes.INTEGER,
      allowNull: true,
      comment: 'Price before discount',
    },
    paid_at: {
      type: DataTypes.DATE,
      allowNull: true,
    },
    completed_at: {
      type: DataTypes.DATE,
      allowNull: true,
    },
  }, {
    tableName: 'orders',
    indexes: [
      { fields: ['invoice_no'] },
      { fields: ['user_id'] },
      { fields: ['payment_status'] },
      { fields: ['fulfill_status'] },
      { fields: ['created_at'] },
    ],
  });

  return Order;
};
