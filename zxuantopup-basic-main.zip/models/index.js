const { Sequelize } = require('sequelize');
require('dotenv').config();

const sequelize = new Sequelize(
  process.env.DB_NAME,
  process.env.DB_USER,
  process.env.DB_PASS,
  {
    host: process.env.DB_HOST,
    port: process.env.DB_PORT || 3306,
    dialect: 'mysql',
    logging: process.env.NODE_ENV === 'development' ? console.log : false,
    pool: {
      max: 10,
      min: 0,
      acquire: 30000,
      idle: 10000,
    },
    define: {
      timestamps: true,
      underscored: true,
    },
  }
);

// Import models
const User = require('./User')(sequelize);
const Product = require('./Product')(sequelize);
const Order = require('./Order')(sequelize);
const Mutation = require('./Mutation')(sequelize);
const Announcement = require('./Announcement')(sequelize);
const LeaderboardCache = require('./LeaderboardCache')(sequelize);
const Otp = require('./Otp')(sequelize);
const LoginHistory = require('./LoginHistory')(sequelize);
const Voucher = require('./Voucher')(sequelize);

// ─── Associations ─────────────────────────────────────
User.hasMany(Order, { foreignKey: 'user_id', as: 'orders' });
Order.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

Product.hasMany(Order, { foreignKey: 'product_id', as: 'orders' });
Order.belongsTo(Product, { foreignKey: 'product_id', as: 'product' });

User.hasMany(Mutation, { foreignKey: 'user_id', as: 'mutations' });
Mutation.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

User.hasMany(Otp, { foreignKey: 'user_id', as: 'otps' });
Otp.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

User.hasMany(LoginHistory, { foreignKey: 'user_id', as: 'login_histories' });
LoginHistory.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

Voucher.hasMany(Order, { foreignKey: 'voucher_id', as: 'orders' });
Order.belongsTo(Voucher, { foreignKey: 'voucher_id', as: 'voucher' });

module.exports = {
  sequelize,
  User,
  Product,
  Order,
  Mutation,
  Announcement,
  LeaderboardCache,
  Otp,
  LoginHistory,
  Voucher,
};
