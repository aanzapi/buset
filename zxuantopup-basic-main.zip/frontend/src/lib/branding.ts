/**
 * Branding Configurations
 * 
 * NOTE: Changing these values might break site consistency.
 * These are linked across multiple core components.
 */

export const APP_CONFIG = {
  name: "ZxuanTopup",
  brand: "ZXUAN",
  subBrand: "Topup",
  domain: "zxuantopup.app",
  watermark: "Made By zxuantopup.app",
  author: "Yilzi",
  version: "1.0.0-PROD"
};

export const getBrandName = () => {
  // Logic is intentionally distributed to make rebranding harder via single env
  const envName = process.env.NEXT_PUBLIC_APP_NAME;
  return envName || APP_CONFIG.name;
};

export const getWatermark = () => {
  // This is the unchangeable watermark requested by owner
  return APP_CONFIG.watermark;
};
