const API_BASE = process.env.NEXT_PUBLIC_API_URL ;

export interface GameItem {
  name: string;
  slug: string;
  category: string;
  icon: string;
  min_price: number;
  product_count: number;
}

export interface ProductItem {
  code: string;
  game: string;
  game_slug: string;
  name: string;
  category: string;
  icon: string;
  price_basic: number;
  price_special: number;
  sell_price: number;
  description: string;
  server: string;
  status: string;
}

export interface GameDetail {
  name: string;
  slug: string;
  category: string;
  icon: string;
  products: ProductItem[];
}

// ─── Fetch games list (for homepage) ───
export async function fetchGames(category?: string): Promise<GameItem[]> {
  const params = category && category !== 'all' ? `?category=${category}` : '';
  const res = await fetch(`${API_BASE}/api/v2/games${params}`, {
    next: { revalidate: 300 }, // ISR: revalidate every 5 min
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.message);
  return json.data;
}

// ─── Fetch game detail with products ───
export async function fetchGameDetail(slug: string): Promise<GameDetail> {
  const res = await fetch(`${API_BASE}/api/v2/games/${slug}`, {
    next: { revalidate: 300 },
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.message);
  return json.data;
}

// ─── Client-side fetch (for dynamic updates) ───
export async function fetchGamesClient(category?: string): Promise<GameItem[]> {
  const params = category && category !== 'all' ? `?category=${category}` : '';
  const res = await fetch(`${API_BASE}/api/v2/games${params}`);
  const json = await res.json();
  if (!json.success) throw new Error(json.message);
  return json.data;
}

export async function fetchGameDetailClient(slug: string): Promise<GameDetail> {
  const res = await fetch(`${API_BASE}/api/v2/games/${slug}`);
  const json = await res.json();
  if (!json.success) throw new Error(json.message);
  return json.data;
}

// ─── Payment Channels (Tripay) ───
export interface PaymentChannel {
  code: string;
  name: string;
  group: string;
  type: string;
  icon_url: string;
  fee_flat: number;
  fee_percent: number;
  min_amount: number;
  max_amount: number;
  active: boolean;
}

export async function fetchPaymentChannels(): Promise<PaymentChannel[]> {
  const res = await fetch(`${API_BASE}/api/v2/payment-channels`);
  const json = await res.json();
  if (!json.success) throw new Error(json.message);
  return json.data;
}
