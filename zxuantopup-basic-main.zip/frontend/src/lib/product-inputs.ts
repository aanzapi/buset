/**
 * Dynamic input field configuration per product/game type.
 * Maps game slugs to their required input fields.
 * Researched from each game's official top-up requirements.
 */

export interface InputField {
  key: string;
  label: string;
  placeholder: string;
  type: 'text' | 'email' | 'tel' | 'password';
  required: boolean;
  info?: string;
  selectOptions?: { label: string; value: string }[];
}

export interface ProductInputConfig {
  type: 'game' | 'streaming' | 'premium_app' | 'voucher';
  fields: InputField[];
  notice?: string;
  noticeTitle?: string;
}

// ─── Default Configs ──────────────────────────────────
const GAME_ID_ZONE: ProductInputConfig = {
  type: 'game',
  fields: [
    { key: 'userId', label: 'User ID', placeholder: 'Masukkan User ID', type: 'text', required: true },
    { key: 'zoneId', label: 'Zone ID / Server', placeholder: 'Masukkan Zone ID', type: 'text', required: true },
  ],
};

const GAME_ID_ONLY: ProductInputConfig = {
  type: 'game',
  fields: [
    { key: 'userId', label: 'User ID', placeholder: 'Masukkan User ID', type: 'text', required: true },
  ],
};

const EMAIL_DEFAULT: ProductInputConfig = {
  type: 'premium_app',
  fields: [
    { key: 'email', label: 'Masukan Email', placeholder: 'contoh@email.com', type: 'email', required: true, info: 'Masukan alamat email aktif Anda. Akun atau link invite akan di kirim melalui riwayat pesanan atau email Anda.' },
  ],
};

const PHONE_DEFAULT: ProductInputConfig = {
  type: 'streaming',
  fields: [
    { key: 'phone', label: 'Masukan Nomor', placeholder: '08xxxxxxxxxx', type: 'tel', required: true, info: 'Masukan nomor Anda. Akun akan di kirim melalui Riwayat Pesanan.' },
  ],
};

const VOUCHER_DEFAULT: ProductInputConfig = {
  type: 'voucher',
  fields: [
    { key: 'email', label: 'Email Penerima', placeholder: 'contoh@email.com', type: 'email', required: true, info: 'Kode voucher akan dikirim ke email dan riwayat pesanan Anda.' },
  ],
};

// ─── Per-Game Configurations ──────────────────────────
const PRODUCT_INPUT_MAP: Record<string, ProductInputConfig> = {
  // ════════════════════════════════════════════════════
  // GAMES: User ID + Zone ID
  // ════════════════════════════════════════════════════
  'mobile-legends': GAME_ID_ZONE,
  'mobile-legends-a': { ...GAME_ID_ZONE, notice: 'Masukkan User ID dan Zone ID yang bisa dilihat di pojok kiri atas profil game.' },
  'mobile-legends-b': GAME_ID_ZONE,
  'mobile-legends-promo': GAME_ID_ZONE,
  'mobile-legends-slow': GAME_ID_ZONE,
  'mobile-legends-vilog': GAME_ID_ZONE,
  'mobile-legends-membership': GAME_ID_ZONE,
  'mobile-legends-global': GAME_ID_ZONE,
  'mobile-legends-brazil': GAME_ID_ZONE,
  'mobile-legends-malaysia': GAME_ID_ZONE,
  'mobile-legends-philippines': GAME_ID_ZONE,
  'mobile-legends-russia': GAME_ID_ZONE,
  'mobile-legends-singapore': GAME_ID_ZONE,
  'mobile-legends-turkey': GAME_ID_ZONE,
  'mobile-legends-gift': {
    type: 'game',
    fields: [
      { key: 'userId', label: 'User ID', placeholder: 'Masukkan User ID', type: 'text', required: true },
      { key: 'zoneId', label: 'Zone ID', placeholder: 'Masukkan Zone ID', type: 'text', required: true },
    ],
    noticeTitle: 'KETENTUAN GIFT SKIN',
    notice: '⚠️ Wajib berteman dengan akun gift setelah order (cek riwayat pesanan). Estimasi terkirim 7-10 hari sesuai antrian. Dilarang ganti nickname & unfollow selama belum sukses. Khusus PO SKIN hanya bisa diorder sebelum skin rilis (max H-2).',
  },
  'mobile-legends-joki-code': {
    type: 'game',
    fields: [
      { key: 'userId', label: 'User ID', placeholder: 'User ID akun ML', type: 'text', required: true },
      { key: 'zoneId', label: 'Zone ID', placeholder: 'Zone ID akun ML', type: 'text', required: true },
    ],
    notice: '⚠️ Joki: Pastikan data login yang diberikan benar. Proses joki memakan waktu sesuai paket yang dipilih.',
  },
  'mobile-legends-joki-event': { type: 'game', fields: [{ key: 'userId', label: 'User ID', placeholder: 'User ID', type: 'text', required: true }, { key: 'zoneId', label: 'Zone ID', placeholder: 'Zone ID', type: 'text', required: true }] },
  'mobile-legends-joki-paket-ranked': { type: 'game', fields: [{ key: 'userId', label: 'User ID', placeholder: 'User ID', type: 'text', required: true }, { key: 'zoneId', label: 'Zone ID', placeholder: 'Zone ID', type: 'text', required: true }] },
  'mobile-legends-joki-rank': { type: 'game', fields: [{ key: 'userId', label: 'User ID', placeholder: 'User ID', type: 'text', required: true }, { key: 'zoneId', label: 'Zone ID', placeholder: 'Zone ID', type: 'text', required: true }] },
  'mobile-legends-joki-ranked': { type: 'game', fields: [{ key: 'userId', label: 'User ID', placeholder: 'User ID', type: 'text', required: true }, { key: 'zoneId', label: 'Zone ID', placeholder: 'Zone ID', type: 'text', required: true }] },
  'mobile-legends-joki-ranked-paket': { type: 'game', fields: [{ key: 'userId', label: 'User ID', placeholder: 'User ID', type: 'text', required: true }, { key: 'zoneId', label: 'Zone ID', placeholder: 'Zone ID', type: 'text', required: true }] },
  'mobile-legends-joki-ranked-satuan': { type: 'game', fields: [{ key: 'userId', label: 'User ID', placeholder: 'User ID', type: 'text', required: true }, { key: 'zoneId', label: 'Zone ID', placeholder: 'Zone ID', type: 'text', required: true }] },
  'magic-chess-go-go': GAME_ID_ZONE,
  'magic-chess-go-go-global': GAME_ID_ZONE,

  // Genshin/Honkai/ZZZ — miHoYo games: UID + Server
  'genshin-impact': {
    type: 'game',
    fields: [
      { key: 'userId', label: 'UID', placeholder: 'Masukkan UID (angka 9 digit)', type: 'text', required: true, info: 'UID bisa dilihat di pojok kanan bawah layar utama game.' },
      { key: 'zoneId', label: 'Server', placeholder: 'Contoh: os_asia, os_euro', type: 'text', required: true, info: 'Server: os_asia, os_euro, os_usa, os_cht' },
    ],
  },
  'genshin-impact-vilog': {
    type: 'game',
    fields: [
      { key: 'userId', label: 'UID', placeholder: 'UID (9 digit)', type: 'text', required: true },
      { key: 'zoneId', label: 'Server', placeholder: 'os_asia / os_euro / os_usa / os_cht', type: 'text', required: true },
    ],
  },
  'honkai-star-rail': {
    type: 'game',
    fields: [
      { key: 'userId', label: 'UID', placeholder: 'Masukkan UID', type: 'text', required: true, info: 'UID bisa dilihat di menu Profile dalam game.' },
      { key: 'zoneId', label: 'Server', placeholder: 'Contoh: os_asia, os_euro', type: 'text', required: true, info: 'Server: os_asia, os_euro, os_usa, os_cht' },
    ],
  },
  'honkai-impact-3': {
    type: 'game',
    fields: [
      { key: 'userId', label: 'UID', placeholder: 'Masukkan UID', type: 'text', required: true },
      { key: 'zoneId', label: 'Server ID', placeholder: 'Masukkan Server ID', type: 'text', required: true },
    ],
  },
  'zenless-zone-zero': {
    type: 'game',
    fields: [
      { key: 'userId', label: 'UID', placeholder: 'UID (9 digit)', type: 'text', required: true },
      { key: 'zoneId', label: 'Server', placeholder: 'os_asia / os_euro / os_usa / os_cht', type: 'text', required: true },
    ],
  },
  'zenless-zone-zero-zzz': {
    type: 'game',
    fields: [
      { key: 'userId', label: 'UID', placeholder: 'UID (9 digit)', type: 'text', required: true },
      { key: 'zoneId', label: 'Server', placeholder: 'os_asia / os_euro / os_usa / os_cht', type: 'text', required: true },
    ],
  },

  // Other ID + Zone games
  'arena-of-valor': {
    type: 'game',
    fields: [
      { key: 'userId', label: 'Player ID', placeholder: 'Masukkan Player ID (Open ID)', type: 'text', required: true },
      { key: 'zoneId', label: 'Server', placeholder: 'Masukkan Server', type: 'text', required: true },
    ],
  },
  'ace-racer': GAME_ID_ZONE,
  'dragon-nest-2-evolution': GAME_ID_ZONE,
  'ragnarok-x-next-generation': GAME_ID_ZONE,
  'ragnarok-x-razer-link': GAME_ID_ZONE,
  'ragnarok-origin': GAME_ID_ZONE,
  'ragnarok-m-eternal-love-sea': GAME_ID_ZONE,
  'tower-of-fantasy': GAME_ID_ZONE,
  'revelation-infinite-journey': GAME_ID_ZONE,
  'chimeraland': GAME_ID_ZONE,
  'dragon-raja': GAME_ID_ZONE,
  'light-of-thel': GAME_ID_ZONE,
  'light-of-thel-new-era': GAME_ID_ZONE,
  'tarisland-asia': GAME_ID_ZONE,
  'tarisland-na-eu': GAME_ID_ZONE,
  'love-and-deepspace': GAME_ID_ZONE,
  'infinite-borders': GAME_ID_ZONE,

  // ════════════════════════════════════════════════════
  // GAMES: User ID Only
  // ════════════════════════════════════════════════════
  'free-fire': { type: 'game', fields: [{ key: 'userId', label: 'Player ID', placeholder: 'Masukkan Player ID Free Fire', type: 'text', required: true, info: 'Player ID bisa dilihat di pojok kiri atas profil game.' }] },
  'free-fire-global': GAME_ID_ONLY,
  'free-fire-max': GAME_ID_ONLY,
  'free-fire-max-global': GAME_ID_ONLY,
  'free-fire-promo': GAME_ID_ONLY,
  'free-fire-vilog': GAME_ID_ONLY,

  'pubg-mobile-id': { type: 'game', fields: [{ key: 'userId', label: 'Player ID', placeholder: 'Masukkan Player ID PUBG Mobile', type: 'text', required: true, info: 'Player ID bisa dilihat di pojok kanan atas profil game.' }] },
  'pubgm-indo-a': GAME_ID_ONLY,
  'pubgm-indo-b': GAME_ID_ONLY,
  'pubgm-global': GAME_ID_ONLY,
  'pubg-mobile-global': GAME_ID_ONLY,
  'pubg-new-state-mobile': GAME_ID_ONLY,

  'call-of-duty-mobile': { type: 'game', fields: [{ key: 'userId', label: 'Player UID', placeholder: 'Masukkan UID (bukan username)', type: 'text', required: true, info: 'UID bisa dilihat di profil game.' }] },
  'call-of-duty-mobile-indonesia': GAME_ID_ONLY,

  'valorant': { type: 'game', fields: [{ key: 'userId', label: 'Riot ID', placeholder: 'Contoh: Nama#TAG', type: 'text', required: true, info: 'Riot ID format: NamaPlayer#Tagline. Bisa dilihat di menu Profile game.' }] },
  'point-blank-id': { type: 'game', fields: [{ key: 'userId', label: 'Zepetto ID', placeholder: 'Masukkan Zepetto ID / Player ID', type: 'text', required: true }] },
  'growtopia': { type: 'game', fields: [{ key: 'userId', label: 'GrowID', placeholder: 'Masukkan GrowID', type: 'text', required: true }] },

  'arena-breakout': GAME_ID_ONLY,
  'arena-breakout-infinite-pc': GAME_ID_ONLY,
  'blood-strike': GAME_ID_ONLY,
  'farlight-84': GAME_ID_ONLY,
  'identity-v': GAME_ID_ONLY,
  'sausage-man': GAME_ID_ONLY,
  'super-sus': GAME_ID_ONLY,
  'whiteout-survival': GAME_ID_ONLY,
  'marvel-snap': GAME_ID_ONLY,
  'marvel-rivals': GAME_ID_ONLY,
  'marvel-super-war': GAME_ID_ONLY,
  'marvel-duel': GAME_ID_ONLY,
  'honor-of-kings-global': GAME_ID_ONLY,
  'ea-sports-fc-mobile': GAME_ID_ONLY,
  'eggy-party': GAME_ID_ONLY,
  'blockman-go': GAME_ID_ONLY,
  'garena-undawn': GAME_ID_ONLY,
  'metal-slug-awakening': GAME_ID_ONLY,
  'omega-legends': GAME_ID_ONLY,
  'one-punch-man': GAME_ID_ONLY,
  'tom-and-jerry-chase': GAME_ID_ONLY,
  'lords-mobile': GAME_ID_ONLY,
  'state-of-survival-zombie-war': GAME_ID_ONLY,
  'king-of-avalon': GAME_ID_ONLY,
  'watcher-of-realms': GAME_ID_ONLY,
  'castle-duels': GAME_ID_ONLY,
  'be-the-king': GAME_ID_ONLY,
  'dynasty-warriors-overlords': GAME_ID_ONLY,
  'afk-journey': GAME_ID_ONLY,
  'age-of-empires-mobile': GAME_ID_ONLY,
  'astral-guardians-cyber-fantasy': GAME_ID_ONLY,
  'dragonheir-silent-gods': GAME_ID_ONLY,
  'delta-force': GAME_ID_ONLY,
  'football-master-2': GAME_ID_ONLY,
  'nba-infinite-europe': GAME_ID_ONLY,
  'tank-company': GAME_ID_ONLY,
  'lita': GAME_ID_ONLY,
  'likee': GAME_ID_ONLY,
  'zepeto': GAME_ID_ONLY,
  'apex-legends-mobile': GAME_ID_ONLY,
  'lifeafter': GAME_ID_ONLY,
  'conquer-online-point-card': GAME_ID_ONLY,
  'league-of-legends': GAME_ID_ONLY,
  'efootball-2023-vilog': GAME_ID_ONLY,
  'roblox-via-login': {
    type: 'game',
    fields: [
      { key: 'userId', label: 'Username Roblox', placeholder: 'Masukkan Username Roblox', type: 'text', required: true },
      { key: 'email', label: 'Email/Password (jika diminta)', placeholder: 'Kosongkan jika tidak diminta', type: 'text', required: false },
    ],
    notice: '⚠️ Pastikan akun Roblox tidak menggunakan 2FA. Robux akan diproses via login akun.',
  },

  // ════════════════════════════════════════════════════
  // VOUCHER / CODE (email delivery)
  // ════════════════════════════════════════════════════
  'steam-wallet-code': VOUCHER_DEFAULT,
  'playstation-network-psn': VOUCHER_DEFAULT,
  'apple-gift-card': VOUCHER_DEFAULT,
  'voucher-garena-shell': VOUCHER_DEFAULT,
  'garena-shell-murah': VOUCHER_DEFAULT,
  'po-garena-shell': VOUCHER_DEFAULT,
  'voucher-megaxus': VOUCHER_DEFAULT,
  'voucher-pb-zepetto': VOUCHER_DEFAULT,
  'voucher-psn': VOUCHER_DEFAULT,
  'voucher-razer-gold': VOUCHER_DEFAULT,
  'voucher-roblox': VOUCHER_DEFAULT,
  'voucher-valorant': VOUCHER_DEFAULT,
  'voucher-fortnite-v-bucks': VOUCHER_DEFAULT,

  // ════════════════════════════════════════════════════
  // STREAMING & PREMIUM APPS
  // ════════════════════════════════════════════════════
  'netflix-premium': {
    type: 'streaming',
    fields: [
      { key: 'devices', label: 'Nama Devices Customer', placeholder: 'iPhone, Android, Smart TV LG, dll', type: 'text', required: true },
      { key: 'profile_pin', label: 'Request Profile + PIN', placeholder: 'Nama Profile + PIN 4 Digit', type: 'text', required: false, info: 'Khusus Profile Shared 2 User (tidak bisa request profile dan pin random!)' },
    ],
    noticeTitle: 'KETENTUAN NETFLIX',
    notice: `‼️ BACA SEBELUM LOGIN ‼️\n— Dilarang mengubah EMAIL, PASSWORD, PROFIL, dan PIN!\n— Hanya login di 1 perangkat!\n— Dilarang meminjamkan password!\n— Jangan pencet cancel membership!\n— Jika screen limit, tunggu dan coba lagi nanti.\n— Apabila password salah lapor ke admin, jangan klik reset!`,
  },
  'spotify-premium': {
    type: 'streaming',
    fields: [
      { key: 'email', label: 'Email', placeholder: 'contoh@email.com', type: 'email', required: true },
      { key: 'profile', label: 'Profile Spotify', placeholder: 'Nama profile Spotify', type: 'text', required: true, info: 'Klik ⚙️ (pojok kanan atas) lalu tertera Nama Profile (bukan username).' },
      { key: 'password', label: 'Password (khusus perpanjang)', placeholder: 'Kosongkan jika baru', type: 'password', required: false },
    ],
    notice: 'REG INDO dan REG RANDOM sama saja tidak ada perbedaan.',
  },
  'youtube-premium': {
    type: 'streaming',
    fields: [
      { key: 'email', label: 'Email Gmail', placeholder: 'contoh@gmail.com', type: 'email', required: true },
    ],
    notice: 'Khusus Gmail. Pastikan gmail baru (fresh) agar mempermudah proses!',
  },
  'disney-hotstar': {
    type: 'streaming',
    fields: [
      { key: 'phone', label: 'Nomor WhatsApp', placeholder: '08xxxxxxxxxx', type: 'tel', required: true, info: 'OTP Disney akan dikirim via WhatsApp Admin.' },
    ],
  },
  'amazon-prime-video': {
    type: 'streaming',
    fields: [
      { key: 'email', label: 'Email', placeholder: 'contoh@email.com', type: 'email', required: true },
      { key: 'profile', label: 'Request Profile', placeholder: 'Nama profile', type: 'text', required: false },
    ],
  },
  'bstation-premium': EMAIL_DEFAULT,
  'iqiyi-premium': EMAIL_DEFAULT,
  'wetv-premium': EMAIL_DEFAULT,
  'vidio-premier': EMAIL_DEFAULT,
  'resso-premium': EMAIL_DEFAULT,
  'tiktok-music': EMAIL_DEFAULT,
  'telegram-premium': {
    type: 'premium_app',
    fields: [
      { key: 'phone', label: 'Nomor Telegram', placeholder: '08xxxxxxxxxx atau @username', type: 'text', required: true, info: 'Masukkan nomor HP atau @username Telegram Anda.' },
    ],
  },
  'rcti-plus': PHONE_DEFAULT,
  'vision-plus': PHONE_DEFAULT,
  'viu-premium': PHONE_DEFAULT,

  // Premium Apps
  'canva-pro': EMAIL_DEFAULT,
  'capcut-pro': PHONE_DEFAULT,
  'chatgpt': EMAIL_DEFAULT,
  'gemini': EMAIL_DEFAULT,
  'perplexity-ai': EMAIL_DEFAULT,
  'picsart-pro': EMAIL_DEFAULT,
  'warp-plus': {
    type: 'premium_app',
    fields: [
      { key: 'userId', label: 'Warp+ Key / ID', placeholder: 'Masukkan Key WARP+', type: 'text', required: true },
    ],
  },
  'alight-motion': {
    type: 'premium_app',
    fields: [
      { key: 'phone', label: 'Nomor HP', placeholder: '08xxxxxxxxxx', type: 'tel', required: true },
    ],
  },
  'getcontact-premium': {
    type: 'premium_app',
    fields: [
      { key: 'phone', label: 'Nomor Getcontact', placeholder: 'Nomor telepon Getcontact', type: 'tel', required: true, info: 'Klik Lainnya → Pengaturan → Pengaturan Akun → Nomor Telepon.' },
      { key: 'name_email', label: 'Nama dan Email', placeholder: 'Nama — email@example.com', type: 'text', required: true },
    ],
  },
};

/**
 * Get input configuration for a specific game/product.
 * Falls back to category-based defaults.
 */
export function getProductInputConfig(slug: string, category?: string): ProductInputConfig {
  // Check specific slug mapping first
  if (PRODUCT_INPUT_MAP[slug]) {
    return PRODUCT_INPUT_MAP[slug];
  }

  // Check if slug starts with a known prefix (handles variants like mobile-legends-a)
  const keys = Object.keys(PRODUCT_INPUT_MAP).sort((a, b) => b.length - a.length);
  for (const key of keys) {
    if (slug.startsWith(key) && PRODUCT_INPUT_MAP[key]) {
      return PRODUCT_INPUT_MAP[key];
    }
  }

  // Fall back by category
  if (category === 'voucher') return VOUCHER_DEFAULT;
  if (category === 'streaming') return EMAIL_DEFAULT;
  if (category === 'premium_app') return EMAIL_DEFAULT;
  if (category === 'joki') return GAME_ID_ZONE;

  return GAME_ID_ONLY;
}

/**
 * FAQ items for the detail page
 */
export const FAQ_ITEMS = [
  {
    q: 'Berapa lama proses pengiriman?',
    a: 'Pengiriman setiap akun/item hanya berlangsung maksimal 30 menit. Untuk game top-up (Diamond, UC, dll), proses biasanya instan (1-5 menit). Jika lebih dari 30 menit, silakan hubungi admin via WhatsApp.',
  },
  {
    q: 'Bagaimana jika akun bermasalah setelah pembelian?',
    a: 'Silakan hubungi admin melalui WhatsApp dengan menyertakan bukti pembelian (nomor invoice). Kami akan membantu menyelesaikan masalah Anda sesegera mungkin.',
  },
  {
    q: 'Metode pembayaran apa saja yang tersedia?',
    a: 'Kami menyediakan berbagai metode pembayaran termasuk QRIS (semua e-wallet), Dana, OVO, ShopeePay, Virtual Account (BRI, BCA, Mandiri, BNI, dll), dan gerai retail (Alfamart, Indomaret, Alfamidi).',
  },
  {
    q: 'Apakah aman membeli di {process.env.NEXT_PUBLIC_APP_NAME}?',
    a: 'Ya! Semua transaksi diproses melalui payment gateway resmi (Tripay) dan terenkripsi. Kami juga memberikan garansi untuk setiap pembelian sesuai ketentuan produk.',
  },
  {
    q: 'Apakah bisa request refund?',
    a: 'Refund hanya bisa dilakukan jika item/akun belum dikirim atau terjadi kesalahan dari pihak kami. Silakan hubungi admin untuk proses refund.',
  },
];
