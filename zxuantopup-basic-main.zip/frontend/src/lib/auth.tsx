"use client";

import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react";

const API = process.env.NEXT_PUBLIC_API_URL ;

export interface UserProfile {
  id: number;
  username: string;
  email: string;
  avatar: string;
  phone: string;
  role: string;
  xcredits: number;
  referral_code: string;
  wa_linked: boolean;
  two_factor_enabled: boolean;
  two_factor_type: 'email' | 'wa';
  password?: boolean; // truthy if user has a local password set
  created_at: string;
}

interface AuthContextType {
  user: UserProfile | null;
  token: string | null;
  loading: boolean;
  login: (token: string) => void;
  logout: () => void;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  token: null,
  loading: true,
  login: () => {},
  logout: () => {},
  refreshProfile: async () => {},
});

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = useCallback(async (t: string) => {
    try {
      const res = await fetch(`${API}/api/user/profile`, {
        headers: { Authorization: `Bearer ${t}` },
      });
      if (!res.ok) throw new Error("Unauthorized");
      const data = await res.json();
      if (data.success) {
        setUser(data.data);
      } else {
        throw new Error(data.message);
      }
    } catch {
      // Token invalid — clear
      localStorage.removeItem("zx_token");
      setToken(null);
      setUser(null);
    }
  }, []);

  useEffect(() => {
    const stored = localStorage.getItem("zx_token");
    if (stored) {
      setToken(stored);
      fetchProfile(stored).finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [fetchProfile]);

  const login = useCallback((t: string) => {
    localStorage.setItem("zx_token", t);
    setToken(t);
    fetchProfile(t);
  }, [fetchProfile]);

  const logout = useCallback(async () => {
    try {
      if (token) {
        await fetch(`${API}/api/auth/logout`, {
          method: "POST",
          headers: { Authorization: `Bearer ${token}` },
        });
      }
    } catch { /* ignore */ }
    localStorage.removeItem("zx_token");
    setToken(null);
    setUser(null);
  }, [token]);

  const refreshProfile = useCallback(async () => {
    if (token) await fetchProfile(token);
  }, [token, fetchProfile]);

  return (
    <AuthContext.Provider value={{ user, token, loading, login, logout, refreshProfile }}>
      {children}
    </AuthContext.Provider>
  );
}
