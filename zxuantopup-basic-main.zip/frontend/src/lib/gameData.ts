// Game data with local icon paths (generated assets in /public/images/games/)

export interface GameData {
  name: string;
  slug: string;
  category: "game" | "streaming" | "voucher" | "premium_app" | "joki";
  icon: string;
  developer: string;
  minPrice: number;
  badge?: string;
  popular?: boolean;
}

export const GAME_LIST: GameData[] = [
  { name: "Mobile Legends", slug: "mobile-legends-a", category: "game", icon: "/images/games/ml.png", developer: "Moonton", minPrice: 1500, badge: "⚡ Instan", popular: true },
  { name: "Free Fire", slug: "free-fire", category: "game", icon: "/images/games/ff.png", developer: "Garena", minPrice: 1200, badge: "🔥 Best Seller", popular: true },
  { name: "PUBG Mobile", slug: "pubg-mobile-id", category: "game", icon: "/images/games/pubg.png", developer: "Tencent Games", minPrice: 8000, popular: true },
  { name: "Genshin Impact", slug: "genshin-impact", category: "game", icon: "/images/games/genshin.png", developer: "HoYoverse", minPrice: 15000, badge: "⭐ Popular", popular: true },
  { name: "Valorant", slug: "valorant", category: "game", icon: "/images/games/valorant.png", developer: "Riot Games", minPrice: 10000, popular: true },
  { name: "Honkai Star Rail", slug: "honkai-star-rail", category: "game", icon: "/images/games/hsr.png", developer: "HoYoverse", minPrice: 14000, popular: true },
  { name: "Call of Duty Mobile", slug: "call-of-duty-mobile", category: "game", icon: "/images/games/codm.png", developer: "Activision", minPrice: 9000 },
  { name: "Honor of Kings", slug: "honor-of-kings", category: "game", icon: "/images/games/hok.png", developer: "TiMi Studio", minPrice: 5000, badge: "🆕 Baru" },
  { name: "Zenless Zone Zero", slug: "zenless-zone-zero", category: "game", icon: "/images/games/zzz.png", developer: "HoYoverse", minPrice: 12000 },
  { name: "Clash of Clans", slug: "clash-of-clans", category: "game", icon: "/images/games/coc.png", developer: "Supercell", minPrice: 14000 },
  { name: "Arena of Valor", slug: "arena-of-valor", category: "game", icon: "/images/games/hok.png", developer: "Garena", minPrice: 5000 },
  { name: "Free Fire MAX", slug: "free-fire-max", category: "game", icon: "/images/games/ff.png", developer: "Garena", minPrice: 1200 },
  { name: "Wuthering Waves", slug: "wuthering-waves", category: "game", icon: "/images/games/hsr.png", developer: "Kuro Games", minPrice: 15000 },
  { name: "Ragnarok Origin", slug: "ragnarok-origin", category: "game", icon: "/images/games/coc.png", developer: "Gravity", minPrice: 10000 },
  { name: "Tower of Fantasy", slug: "tower-of-fantasy", category: "game", icon: "/images/games/genshin.png", developer: "Level Infinite", minPrice: 15000 },
  { name: "Stumble Guys", slug: "stumble-guys", category: "game", icon: "/images/games/roblox.png", developer: "Scopely", minPrice: 8000 },

  // Streaming
  { name: "Netflix Premium", slug: "netflix-premium", category: "streaming", icon: "/images/games/netflix.png", developer: "Netflix Inc.", minPrice: 25000 },
  { name: "Spotify Premium", slug: "spotify-premium", category: "streaming", icon: "/images/games/netflix.png", developer: "Spotify AB", minPrice: 10000 },
  { name: "Youtube Premium", slug: "youtube-premium", category: "streaming", icon: "/images/games/netflix.png", developer: "Google LLC", minPrice: 15000 },
  { name: "Disney+ Hotstar", slug: "disney-hotstar", category: "streaming", icon: "/images/games/netflix.png", developer: "Disney", minPrice: 20000 },

  // Voucher
  { name: "Steam Wallet", slug: "steam-wallet", category: "voucher", icon: "/images/games/valorant.png", developer: "Valve", minPrice: 12000 },
  { name: "Garena Shell", slug: "garena-shell", category: "voucher", icon: "/images/games/ff.png", developer: "Garena", minPrice: 5000 },
  { name: "Roblox", slug: "roblox", category: "voucher", icon: "/images/games/roblox.png", developer: "Roblox Corp", minPrice: 10000, popular: true },
  { name: "PlayStation Network", slug: "psn", category: "voucher", icon: "/images/games/codm.png", developer: "Sony", minPrice: 50000 },

  // Premium Apps
  { name: "ChatGPT Plus", slug: "chatgpt", category: "premium_app", icon: "/images/games/zzz.png", developer: "OpenAI", minPrice: 50000 },
  { name: "Canva Pro", slug: "canva-pro", category: "premium_app", icon: "/images/games/roblox.png", developer: "Canva", minPrice: 6000 },
];

export const GAME_MAP = Object.fromEntries(GAME_LIST.map((g) => [g.slug, g]));
export const TRENDING_GAMES = GAME_LIST.filter((g) => g.popular);

export const CATEGORIES = [
  { key: "all", label: "Semua", icon: "🎮" },
  { key: "game", label: "Game", icon: "🎯" },
  { key: "streaming", label: "Streaming", icon: "📺" },
  { key: "voucher", label: "Voucher", icon: "🎟️" },
  { key: "premium_app", label: "Premium Apps", icon: "📱" },
] as const;
