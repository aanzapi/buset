export const dynamic = "force-dynamic";

import dynamic_import from "next/dynamic";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import MobileNav from "@/components/layout/MobileNav";
import HeroBanner from "@/components/home/HeroBanner";
import TrendingSection from "@/components/home/TrendingSection";
import GameGrid from "@/components/home/GameGrid";
import StatsBar from "@/components/home/StatsBar";
import WhyChooseUs from "@/components/home/WhyChooseUs";

// Lazy-load heavy animation components
const WelcomePopup = dynamic_import(() => import("@/components/home/WelcomePopup"), { ssr: false });
const TestimonialSection = dynamic_import(() => import("@/components/home/TestimonialSection"), { ssr: false });
const ArticleSection = dynamic_import(() => import("@/components/home/ArticleSection"), { ssr: false });
const ChatWidget = dynamic_import(() => import("@/components/layout/ChatWidget"), { ssr: false });

export default function HomePage() {
  return (
    <>
      <Navbar />
      <WelcomePopup />

      <main className="max-w-7xl mx-auto px-4 pt-24 pb-24 lg:pb-12">
        {/* Hero */}
        <HeroBanner />

        {/* Trending */}
        <TrendingSection />

        {/* Stats */}
        <StatsBar />

        {/* Game Grid */}
        <GameGrid />

        {/* Why Choose Us */}
        <WhyChooseUs />

        {/* Testimonials */}
        <section id="testimonials">
          <TestimonialSection />
        </section>

        {/* Articles */}
        <ArticleSection />
      </main>

      <Footer />
      <MobileNav />
      <ChatWidget />
    </>
  );
}
