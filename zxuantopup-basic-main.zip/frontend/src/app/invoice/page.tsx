"use client";

import { useState, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import MobileNav from "@/components/layout/MobileNav";
import { Search, FileText, AlertCircle, CheckCircle2, Clock, XCircle, RefreshCw } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

import { Suspense } from "react";

function InvoiceContent() {
  const searchParams = useSearchParams();
  const ref = searchParams.get("ref") || searchParams.get("no") || "";
  
  const [invoiceNo, setInvoiceNo] = useState(ref);
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(false);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [order, setOrder] = useState<any>(null);
  const [error, setError] = useState("");

  const fetchOrder = async (no: string, silent = false) => {
    if (!no.trim()) return;
    if (!silent) {
      setLoading(true);
      setError("");
      // Don't set order to null so UI doesn't flash
    }
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL }/api/orders/${no}`);
      const json = await res.json();
      if (json.success) {
        setOrder(json.data);
      } else {
        if (!silent) {
          setOrder(null);
          setError(json.message || "Invoice tidak ditemukan");
        }
      }
    } catch (err) {
      if (!silent) setError("Gagal mengambil data invoice");
    } finally {
      if (!silent) setLoading(false);
    }
  };

  const checkStatus = async (silent = false) => {
    if (!order) return;
    if (!silent) setChecking(true);
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL }/api/orders/${order.invoice_no}/check-status`);
      const json = await res.json();
      if (json.success) {
        // Re-fetch full order data with product info silently
        await fetchOrder(order.invoice_no, true);
        if (!silent) {
          if (json.status === 'PAID') {
            alert("✅ Pembayaran berhasil dikonfirmasi! Pesanan sedang diproses.");
          } else if (json.status === 'UNPAID') {
            alert("⏳ Pembayaran belum diterima. Silakan selesaikan pembayaran.");
          } else {
            alert(`Status saat ini: ${json.status}`);
          }
        }
      } else {
        if (!silent) alert(json.message || "Gagal mengecek status");
      }
    } catch (err) {
      if (!silent) alert("Gagal mengecek status");
    } finally {
      if (!silent) setChecking(false);
    }
  };

  useEffect(() => {
    if (ref) fetchOrder(ref);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ref]);

  // Realtime Polling
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    // Poll every 5 seconds if order is UNPAID or PROCESSING
    if (order && (order.payment_status === 'UNPAID' || order.fulfill_status === 'processing')) {
      interval = setInterval(() => {
        checkStatus(true);
      }, 5000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [order?.payment_status, order?.fulfill_status, order?.invoice_no]);

  const handleSearch = () => {
    fetchOrder(invoiceNo);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PAID': return 'text-green-500';
      case 'UNPAID': return 'text-yellow-500';
      case 'EXPIRED': return 'text-red-500';
      default: return 'text-muted';
    }
  };

  const getFulfillIcon = (status: string) => {
    switch (status) {
      case 'success': return <CheckCircle2 className="text-green-500" />;
      case 'processing': return <RefreshCw className="text-blue-500 animate-spin" />;
      case 'failed': return <XCircle className="text-red-500" />;
      default: return <Clock className="text-yellow-500" />;
    }
  };

  return (
    <>
      <Navbar />
      <main className="max-w-3xl mx-auto px-4 pt-24 pb-24 lg:pb-12">
        <div className="text-center mb-10">
          <FileText size={48} className="mx-auto text-primary mb-4" />
          <h1 className="font-heading text-3xl font-bold text-white">Cek Transaksi</h1>
          <p className="text-muted mt-2 text-sm">Masukkan invoice number untuk melihat status pesanan kamu</p>
        </div>

        {/* Search Input */}
        <div className="glass rounded-[20px] p-6 mb-8 border border-white/5">
          <div className="flex gap-3">
            <div className="relative flex-1">
              <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
              <input
                type="text"
                value={invoiceNo}
                onChange={(e) => setInvoiceNo(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                placeholder="Contoh: INV-20260425-XXXXX"
                className="input-field pl-11"
              />
            </div>
            <button 
              onClick={handleSearch} 
              disabled={loading}
              className="btn-primary whitespace-nowrap px-8"
            >
              {loading ? <RefreshCw className="animate-spin w-5 h-5" /> : "Cari"}
            </button>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {order ? (
            <motion.div 
              key="result"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              {/* Status Banner */}
              <div className={`glass rounded-[20px] p-6 border border-white/5 flex items-center justify-between`}>
                <div className="flex items-center gap-4">
                  <div className={`p-3 rounded-xl bg-white/5`}>
                    {order.payment_status === 'PAID' ? <CheckCircle2 className="text-green-500" /> : <Clock className="text-yellow-500" />}
                  </div>
                  <div>
                    <p className="text-xs text-muted uppercase tracking-wider font-bold">Status Pembayaran</p>
                    <h3 className={`text-lg font-bold ${getStatusColor(order.payment_status)}`}>
                      {order.payment_status === 'PAID' ? 'TELAH DIBAYAR' : 'MENUNGGU PEMBAYARAN'}
                    </h3>
                  </div>
                </div>
                {order.payment_status !== 'PAID' && (
                  <button 
                    onClick={() => checkStatus()}
                    disabled={checking}
                    className="flex items-center gap-2 text-xs font-bold bg-white/5 hover:bg-white/10 px-4 py-2 rounded-lg transition-all"
                  >
                    <RefreshCw size={14} className={checking ? "animate-spin" : ""} />
                    CEK STATUS
                  </button>
                )}
              </div>

              {/* Order Details */}
              <div className="glass rounded-[24px] overflow-hidden border border-white/5">
                <div className="bg-white/5 px-6 py-4 border-b border-white/5">
                  <h3 className="font-bold text-white">Rincian Pesanan</h3>
                </div>
                <div className="p-6 space-y-4">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted">No. Invoice</span>
                    <span className="text-white font-mono">{order.invoice_no}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted">Layanan</span>
                    <span className="text-white font-bold">{order.game_name}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted">Item</span>
                    <span className="text-primary font-bold">{order.product?.product_name || 'N/A'}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted">ID & Zone</span>
                    <span className="text-white">{order.user_input} {order.user_zone ? `(${order.user_zone})` : ''}</span>
                  </div>
                  {order.nickname && (
                    <div className="flex justify-between items-center text-sm">
                      <span className="text-muted">Nickname</span>
                      <span className="text-yellow-500 font-bold">{order.nickname}</span>
                    </div>
                  )}
                  <div className="flex justify-between items-center text-sm border-t border-white/5 pt-4">
                    <span className="text-muted">Metode Pembayaran</span>
                    <span className="text-white">{order.payment_method}</span>
                  </div>
                  <div className="flex justify-between items-center text-lg font-bold border-t border-white/5 pt-4">
                    <span className="text-white">Total Bayar</span>
                    <span className="text-primary">Rp {Number(order.price).toLocaleString('id-ID')}</span>
                  </div>
                </div>
              </div>

              {/* Fulfillment Status */}
              {order.payment_status === 'PAID' && (
                <div className="glass rounded-[24px] p-6 border border-white/5">
                  <div className="flex items-center gap-4 mb-4">
                    <div className="p-3 rounded-xl bg-white/5">
                      {getFulfillIcon(order.fulfill_status)}
                    </div>
                    <div>
                      <p className="text-xs text-muted uppercase tracking-wider font-bold">Status Pengiriman</p>
                      <h3 className={`text-lg font-bold uppercase ${
                        order.fulfill_status === 'success' ? 'text-green-500' : 
                        order.fulfill_status === 'processing' ? 'text-blue-500' : 
                        order.fulfill_status === 'failed' ? 'text-red-500' : 'text-yellow-500'
                      }`}>
                        {order.fulfill_status === 'success' ? 'Berhasil Dikirim' : 
                         order.fulfill_status === 'processing' ? 'Sedang Diproses' : 
                         order.fulfill_status === 'failed' ? 'Gagal Diproses' : 'Menunggu Proses'}
                      </h3>
                    </div>
                  </div>
                  
                  {order.sn && (
                    <div className="bg-black/40 rounded-xl p-4 border border-white/5 mb-4">
                      <p className="text-xs text-muted mb-1">Serial Number / Keterangan:</p>
                      <p className="text-sm text-yellow-500 font-mono break-all">{order.sn}</p>
                    </div>
                  )}

                  {order.fulfill_status === 'failed' && (
                    <div className="bg-red-500/5 border border-red-500/20 rounded-xl p-4 text-center">
                      <p className="text-xs text-red-400 font-medium">⚠️ Terjadi kendala saat memproses pesanan. Tim kami sudah mendapatkan notifikasi dan akan segera menyelesaikannya. Hubungi CS jika diperlukan.</p>
                    </div>
                  )}
                  
                  {order.fulfill_status === 'processing' && (
                    <div className="bg-blue-500/5 border border-blue-500/20 rounded-xl p-4 text-center">
                      <p className="text-xs text-blue-400 font-medium">⏳ Pesanan sedang diproses otomatis. Estimasi 1-5 menit.</p>
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          ) : error ? (
            <motion.div 
              key="error"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="glass rounded-[20px] p-12 text-center border border-white/5"
            >
              <AlertCircle size={48} className="mx-auto text-red-500/50 mb-4" />
              <h3 className="text-lg font-bold text-white">{error}</h3>
              <p className="text-muted text-sm mt-2">Coba periksa kembali nomor invoice Anda.</p>
            </motion.div>
          ) : (
            <motion.div 
              key="empty"
              className="glass rounded-[20px] p-12 text-center border border-white/5"
            >
              <FileText size={48} className="mx-auto text-white/10 mb-4" />
              <p className="text-muted text-sm">Hasil pencarian akan muncul di sini</p>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
      <Footer />
      <MobileNav />
    </>
  );
}

export default function InvoicePage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-dark flex items-center justify-center"><RefreshCw className="animate-spin text-primary" /></div>}>
      <InvoiceContent />
    </Suspense>
  );
}
