import type { Metadata } from "next";
import "./globals.css";
import { Inter } from "next/font/google";
import { cn } from "@/lib/utils";
import { Providers } from "./providers";
import { AntiDevTools } from "@/components/AntiDevTools";

import { APP_CONFIG } from "@/lib/branding";

const inter = Inter({ subsets: ["latin"], variable: "--font-sans" });

export const metadata: Metadata = {
  title: `${APP_CONFIG.name} — Top Up Game Cepat, Aman, Terpercaya`,
  description: "Platform top-up game terlengkap dan terpercaya di Indonesia. Mobile Legends, Free Fire, PUBG Mobile, Genshin Impact, dan 100+ game lainnya. Proses instan, harga murah, support 24/7.",
  keywords: `top up game, top up mobile legends, top up free fire, top up diamond, topup murah, ${APP_CONFIG.name.toLowerCase()}`,
  icons: {
    icon: "/favicon.svg",
  },
  openGraph: {
    title: `${APP_CONFIG.name} — Top Up Game Cepat, Aman, Terpercaya`,
    description: "Platform top-up game terlengkap dan terpercaya di Indonesia.",
    url: process.env.NEXT_PUBLIC_APP_URL as string,
    siteName: APP_CONFIG.name,
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" className={cn("font-sans", inter.variable)}>
      <body className="antialiased min-h-screen bg-dark">
        <AntiDevTools />
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}

