"use client";

import { useState } from "react";
import { BarChart3 } from "lucide-react";

export default function ReportsPage() {
  const [data] = useState([]); // Temporary empty data
  const [loading] = useState(false);
  const [page, setPage] = useState(1);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-heading text-lg font-bold text-white mb-1">Laporan</h1>
        <p className="text-xs text-muted">Menampilkan laporan total penjualan per hari.</p>
      </div>

      {/* Filters Container */}
      <div className="bg-dark-surface rounded-xl p-5 border border-dark-border shadow-sm">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-[10px] font-medium text-muted block mb-1.5">Produk</label>
            <select className="w-full bg-white/5 border border-dark-border focus:border-primary text-white text-xs rounded-lg px-3 py-2.5 outline-none transition-colors appearance-none">
              <option value="">-- Pilih Semua Produk --</option>
            </select>
          </div>
          <div>
            <label className="text-[10px] font-medium text-muted block mb-1.5">Tanggal Mulai</label>
            <input type="date" className="w-full bg-white/5 border border-dark-border focus:border-primary text-white text-xs rounded-lg px-3 py-2 outline-none transition-colors [color-scheme:dark]" defaultValue="2026-04-25" />
          </div>
          <div>
            <label className="text-[10px] font-medium text-muted block mb-1.5">Tanggal Akhir</label>
            <input type="date" className="w-full bg-white/5 border border-dark-border focus:border-primary text-white text-xs rounded-lg px-3 py-2 outline-none transition-colors [color-scheme:dark]" defaultValue="2026-04-26" />
          </div>
        </div>
      </div>

      {/* Export buttons */}
      <div className="flex items-center justify-end gap-2">
        <button className="px-4 py-2 rounded-full border border-dark-border text-xs font-medium text-muted hover:text-white transition-colors bg-dark-surface shadow-sm hover:border-primary/50">
          Unduh CSV
        </button>
        <button className="px-4 py-2 rounded-full border border-dark-border text-xs font-medium text-muted hover:text-white transition-colors bg-dark-surface shadow-sm hover:border-primary/50">
          Unduh XLSX
        </button>
        <select className="px-4 py-2 rounded-full border border-dark-border text-xs font-medium text-muted hover:text-white transition-colors bg-dark-surface shadow-sm outline-none appearance-none cursor-pointer">
          <option>10 Entri</option>
          <option>25 Entri</option>
          <option>50 Entri</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-dark-surface rounded-xl border border-dark-border overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm whitespace-nowrap">
            <thead className="bg-white/[0.02] text-xs text-muted font-medium border-b border-dark-border">
              <tr>
                <th className="px-6 py-4 font-medium">Tanggal</th>
                <th className="px-6 py-4 font-medium">Total Transaksi</th>
                <th className="px-6 py-4 font-medium">Total Jumlah</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-border">
              {loading ? (
                <tr>
                  <td colSpan={3} className="px-6 py-12 text-center text-muted">Memuat data...</td>
                </tr>
              ) : data.length > 0 ? (
                data.map((m, i) => (
                  <tr key={i} className="hover:bg-white/[0.02] transition-colors">
                    <td className="px-6 py-4 text-white text-xs">-</td>
                    <td className="px-6 py-4 text-white text-xs">-</td>
                    <td className="px-6 py-4 text-white text-xs">-</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={3} className="px-6 py-16 text-center">
                    <div className="flex flex-col items-center justify-center text-muted">
                      <BarChart3 size={40} className="mb-3 opacity-30" />
                      <p className="text-sm font-medium text-white mb-1">Data tidak ditemukan!</p>
                      <p className="text-xs">Tidak ada aktifitas data.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between text-xs text-muted">
        <span>Menampilkan {data.length} sampai {data.length} dari {data.length} hasil</span>
        <div className="flex items-center gap-2">
          <button disabled={page <= 1} onClick={() => setPage(p => p - 1)} className="px-4 py-2 rounded-full border border-dark-border bg-dark-surface hover:bg-white/5 hover:text-white disabled:opacity-50 transition-colors shadow-sm">
            Sebelumnya
          </button>
          <button disabled className="px-4 py-2 rounded-full border border-dark-border bg-dark-surface hover:bg-white/5 hover:text-white disabled:opacity-50 transition-colors shadow-sm">
            Selanjutnya
          </button>
        </div>
      </div>
    </div>
  );
}
