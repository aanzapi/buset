"use client";

import { useState, useEffect } from "react";
import { useAuth } from "@/lib/auth";
import ReCAPTCHA from "react-google-recaptcha";
import { Copy, Check, Save, Shield, MessageCircle, Loader2, Lock, Eye, EyeOff, ShieldCheck, ShieldOff, Unlink, Link2 } from "lucide-react";

const API = process.env.NEXT_PUBLIC_API_URL ;
const SITE_KEY = process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY || "";

export default function SettingsPage() {
  const { user, token, refreshProfile } = useAuth();
  const [username, setUsername] = useState(user?.username || "");
  const [phone, setPhone] = useState(user?.phone || "");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [copied, setCopied] = useState(false);

  // WA Linking
  const [waPhone, setWaPhone] = useState("");
  const [waOtp, setWaOtp] = useState("");
  const [waStep, setWaStep] = useState<"idle" | "otp">("idle");
  const [waLoading, setWaLoading] = useState(false);
  const [waMsg, setWaMsg] = useState({ text: "", type: "" });

  // 2FA
  const [twoFaEnabled, setTwoFaEnabled] = useState(false);
  const [twoFaType, setTwoFaType] = useState<"email" | "wa">("email");
  const [twoFaLoading, setTwoFaLoading] = useState(false);
  const [twoFaMsg, setTwoFaMsg] = useState({ text: "", type: "" });

  // Change Password
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [pwLoading, setPwLoading] = useState(false);
  const [pwMsg, setPwMsg] = useState({ text: "", type: "" });
  const [twoFaRecaptcha, setTwoFaRecaptcha] = useState<string | null>(null);
  const [pwRecaptcha, setPwRecaptcha] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      setUsername(user.username || "");
      setPhone(user.phone || "");
      setTwoFaEnabled(user.two_factor_enabled || false);
      setTwoFaType(user.two_factor_type || "email");
    }
  }, [user]);

  // ── Save Profile ──
  const handleSave = async () => {
    if (!token) return;
    setSaving(true);
    try {
      const res = await fetch(`${API}/api/user/profile`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ username, phone }),
      });
      const data = await res.json();
      if (data.success) {
        await refreshProfile();
        setSaved(true);
        setTimeout(() => setSaved(false), 2000);
      }
    } catch (e) { console.error(e); }
    finally { setSaving(false); }
  };

  const copyReferral = () => {
    navigator.clipboard.writeText(user?.referral_code || "");
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // ── Link WA: Send OTP ──
  const handleLinkWaSend = async () => {
    if (!waPhone) return;
    setWaLoading(true);
    setWaMsg({ text: "", type: "" });
    try {
      const res = await fetch(`${API}/api/user/link-wa`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ phone: waPhone }),
      });
      const data = await res.json();
      if (data.success) {
        setWaStep("otp");
        setWaMsg({ text: "Kode OTP telah dikirim ke WhatsApp!", type: "success" });
      } else {
        setWaMsg({ text: data.message, type: "error" });
      }
    } catch { setWaMsg({ text: "Gagal mengirim OTP", type: "error" }); }
    finally { setWaLoading(false); }
  };

  // ── Link WA: Verify OTP ──
  const handleLinkWaVerify = async () => {
    if (!waOtp || waOtp.length !== 6) return;
    setWaLoading(true);
    setWaMsg({ text: "", type: "" });
    try {
      const res = await fetch(`${API}/api/user/verify-wa`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ phone: waPhone, otp_code: waOtp }),
      });
      const data = await res.json();
      if (data.success) {
        setWaMsg({ text: "WhatsApp berhasil ditautkan! ✅", type: "success" });
        setWaStep("idle");
        setWaOtp("");
        await refreshProfile();
      } else {
        setWaMsg({ text: data.message, type: "error" });
      }
    } catch { setWaMsg({ text: "Gagal verifikasi", type: "error" }); }
    finally { setWaLoading(false); }
  };

  // ── Unlink WA ──
  const handleUnlinkWa = async () => {
    setWaLoading(true);
    try {
      const res = await fetch(`${API}/api/user/unlink-wa`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (data.success) {
        setWaMsg({ text: "WhatsApp berhasil dilepas", type: "success" });
        await refreshProfile();
      }
    } catch { setWaMsg({ text: "Gagal melepas WA", type: "error" }); }
    finally { setWaLoading(false); }
  };

  // ── Toggle 2FA ──
  const handleToggle2FA = async (enabled: boolean) => {
    if (!twoFaRecaptcha) { setTwoFaMsg({ text: "Validasi reCAPTCHA diperlukan.", type: "error" }); return; }
    setTwoFaLoading(true);
    setTwoFaMsg({ text: "", type: "" });
    try {
      const res = await fetch(`${API}/api/user/toggle-2fa`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ enabled, type: twoFaType, recaptchaToken: twoFaRecaptcha }),
      });
      const data = await res.json();
      if (data.success) {
        setTwoFaEnabled(data.two_factor_enabled);
        setTwoFaMsg({ text: data.message, type: "success" });
        await refreshProfile();
      } else {
        setTwoFaMsg({ text: data.message, type: "error" });
      }
    } catch { setTwoFaMsg({ text: "Gagal mengubah 2FA", type: "error" }); }
    finally { setTwoFaLoading(false); }
  };

  // ── Change Password ──
  const handleChangePassword = async () => {
    if (!newPw || newPw.length < 6) { setPwMsg({ text: "Password baru minimal 6 karakter", type: "error" }); return; }
    if (!pwRecaptcha) { setPwMsg({ text: "Validasi reCAPTCHA diperlukan.", type: "error" }); return; }
    setPwLoading(true);
    setPwMsg({ text: "", type: "" });
    try {
      const res = await fetch(`${API}/api/user/change-password`, {
        method: "PUT",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({ current_password: currentPw, new_password: newPw, recaptchaToken: pwRecaptcha }),
      });
      const data = await res.json();
      if (data.success) {
        setPwMsg({ text: "Password berhasil diubah! ✅", type: "success" });
        setCurrentPw(""); setNewPw("");
      } else {
        setPwMsg({ text: data.message, type: "error" });
      }
    } catch { setPwMsg({ text: "Gagal mengubah password", type: "error" }); }
    finally { setPwLoading(false); }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="font-heading text-lg font-bold text-white mb-1">Pengaturan</h1>
        <p className="text-xs text-muted">Kelola informasi profil, keamanan, dan akun Anda.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">

        {/* ── LEFT COLUMN (Profile + Password + WA Link) ── */}
        <div className="md:col-span-2 space-y-6">

          {/* Profile */}
          <div className="bg-dark-surface rounded-xl border border-dark-border p-6 shadow-sm">
            <h2 className="text-sm font-bold text-white mb-6 border-b border-dark-border pb-4">Profil Saya</h2>
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-full overflow-hidden bg-white/5 flex items-center justify-center text-xl font-bold text-white shrink-0 border border-dark-border">
                {user?.avatar ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={user.avatar} alt={user.username} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  user?.username?.charAt(0).toUpperCase()
                )}
              </div>
              <div>
                <p className="text-sm font-bold text-white">{user?.username}</p>
                <p className="text-[10px] text-muted">{user?.email}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-medium text-muted block mb-1.5">Username</label>
                <input type="text" value={username} onChange={e => setUsername(e.target.value)} className="w-full bg-white/5 border border-dark-border focus:border-primary text-white text-sm rounded-lg px-4 py-3 outline-none transition-colors" />
              </div>
              <div>
                <label className="text-[10px] font-medium text-muted block mb-1.5">Nomor Telepon</label>
                <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="w-full bg-white/5 border border-dark-border focus:border-primary text-white text-sm rounded-lg px-4 py-3 outline-none transition-colors" placeholder="08xxxxxxxxxx" />
              </div>
              <button onClick={handleSave} disabled={saving} className="w-full md:w-auto px-8 py-3 rounded-lg bg-primary hover:bg-primary-hover text-dark font-bold text-sm transition-colors flex items-center justify-center gap-2">
                {saving ? "Menyimpan..." : saved ? <><Check size={16} /> Tersimpan</> : <><Save size={16} /> Simpan Perubahan</>}
              </button>
            </div>
          </div>

          {/* Change Password */}
          <div className="bg-dark-surface rounded-xl border border-dark-border p-6 shadow-sm">
            <h2 className="text-sm font-bold text-white mb-4 flex items-center gap-2 border-b border-dark-border pb-4">
              <Lock size={16} className="text-primary" /> {user?.password ? "Ubah Password" : "Buat Password"}
            </h2>
            {!user?.password && (
              <p className="text-xs text-muted mb-4 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400">
                Akun Anda belum memiliki password (login via Google). Buat password untuk mengaktifkan fitur keamanan tambahan.
              </p>
            )}
            <div className="space-y-3">
              {user?.password && (
                <div>
                  <label className="text-[10px] font-medium text-muted block mb-1.5">Password Saat Ini</label>
                  <input type="password" value={currentPw} onChange={e => setCurrentPw(e.target.value)} className="w-full bg-white/5 border border-dark-border focus:border-primary text-white text-sm rounded-lg px-4 py-3 outline-none transition-colors" placeholder="••••••••" />
                </div>
              )}
              <div>
                <label className="text-[10px] font-medium text-muted block mb-1.5">Password Baru</label>
                <div className="relative">
                  <input type={showPw ? "text" : "password"} value={newPw} onChange={e => setNewPw(e.target.value)} className="w-full bg-white/5 border border-dark-border focus:border-primary text-white text-sm rounded-lg px-4 py-3 pr-10 outline-none transition-colors" placeholder="Minimal 6 karakter" />
                  <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-white">
                    {showPw ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
              </div>
              {pwMsg.text && (
                <div className={`p-2 rounded-lg text-xs text-center ${pwMsg.type === "error" ? "bg-red-500/10 border border-red-500/20 text-red-400" : "bg-green-500/10 border border-green-500/20 text-green-400"}`}>{pwMsg.text}</div>
              )}

              {/* reCAPTCHA v2 */}
              <div className="flex justify-start my-3 overflow-hidden rounded-xl border border-dark-border">
                {SITE_KEY ? (
                  <ReCAPTCHA
                    sitekey={SITE_KEY}
                    theme="dark"
                    onChange={(token) => setPwRecaptcha(token)}
                  />
                ) : (
                  <div className="p-3 text-xs text-red-400">Site key reCAPTCHA tidak ditemukan</div>
                )}
              </div>

              <button onClick={handleChangePassword} disabled={pwLoading || !newPw || !pwRecaptcha} className="px-6 py-2.5 rounded-lg bg-primary hover:bg-primary-hover text-dark font-bold text-xs transition-colors flex items-center gap-2">
                {pwLoading ? <Loader2 size={14} className="animate-spin" /> : <Lock size={14} />}
                {user?.password ? "Ubah Password" : "Buat Password"}
              </button>
            </div>
          </div>

          {/* Link WhatsApp */}
          <div className="bg-dark-surface rounded-xl border border-dark-border p-6 shadow-sm">
            <h2 className="text-sm font-bold text-white mb-4 flex items-center gap-2 border-b border-dark-border pb-4">
              <MessageCircle size={16} className="text-green-400" /> Tautkan WhatsApp
            </h2>

            {user?.wa_linked ? (
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-green-500/10 border border-green-500/20">
                  <ShieldCheck size={18} className="text-green-400 shrink-0" />
                  <div>
                    <p className="text-xs font-bold text-green-400">WhatsApp Terhubung</p>
                    <p className="text-[10px] text-muted">Nomor: {user.phone}</p>
                  </div>
                </div>
                <button onClick={handleUnlinkWa} disabled={waLoading} className="px-4 py-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs font-medium transition-colors flex items-center gap-2 border border-red-500/20">
                  {waLoading ? <Loader2 size={12} className="animate-spin" /> : <Unlink size={12} />} Lepaskan WhatsApp
                </button>
              </div>
            ) : waStep === "idle" ? (
              <div className="space-y-3">
                <p className="text-xs text-muted">Tautkan nomor WhatsApp untuk notifikasi pesanan dan verifikasi 2 langkah.</p>
                <div>
                  <label className="text-[10px] font-medium text-muted block mb-1.5">Nomor WhatsApp</label>
                  <input type="tel" value={waPhone} onChange={e => setWaPhone(e.target.value)} className="w-full bg-white/5 border border-dark-border focus:border-primary text-white text-sm rounded-lg px-4 py-3 outline-none transition-colors" placeholder="08xxxxxxxxxx" />
                </div>
                {waMsg.text && (
                  <div className={`p-2 rounded-lg text-xs text-center ${waMsg.type === "error" ? "bg-red-500/10 border border-red-500/20 text-red-400" : "bg-green-500/10 border border-green-500/20 text-green-400"}`}>{waMsg.text}</div>
                )}
                <button onClick={handleLinkWaSend} disabled={waLoading || !waPhone} className="px-6 py-2.5 rounded-lg bg-green-600 hover:bg-green-700 text-white font-bold text-xs transition-colors flex items-center gap-2 disabled:opacity-50">
                  {waLoading ? <Loader2 size={14} className="animate-spin" /> : <Link2 size={14} />} Kirim Kode OTP
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-xs text-muted">Masukkan 6 digit kode OTP yang dikirim ke WhatsApp Anda.</p>
                <input type="text" inputMode="numeric" maxLength={6} value={waOtp} onChange={e => setWaOtp(e.target.value.replace(/\D/g, ""))} className="w-full bg-white/5 border border-dark-border focus:border-primary text-white text-lg rounded-lg px-4 py-3 outline-none transition-colors text-center tracking-[8px] font-mono" placeholder="000000" autoFocus />
                {waMsg.text && (
                  <div className={`p-2 rounded-lg text-xs text-center ${waMsg.type === "error" ? "bg-red-500/10 border border-red-500/20 text-red-400" : "bg-green-500/10 border border-green-500/20 text-green-400"}`}>{waMsg.text}</div>
                )}
                <div className="flex gap-2">
                  <button onClick={handleLinkWaVerify} disabled={waLoading || waOtp.length !== 6} className="flex-1 px-6 py-2.5 rounded-lg bg-green-600 hover:bg-green-700 text-white font-bold text-xs transition-colors flex items-center justify-center gap-2 disabled:opacity-50">
                    {waLoading ? <Loader2 size={14} className="animate-spin" /> : <ShieldCheck size={14} />} Verifikasi
                  </button>
                  <button onClick={() => { setWaStep("idle"); setWaOtp(""); setWaMsg({ text: "", type: "" }); }} className="px-4 py-2.5 rounded-lg bg-white/5 hover:bg-white/10 text-muted text-xs transition-colors border border-dark-border">
                    Batal
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* ── RIGHT COLUMN (Account Info + 2FA) ── */}
        <div className="space-y-6">
          {/* Account Info */}
          <div className="bg-dark-surface rounded-xl border border-dark-border p-6 shadow-sm">
            <h2 className="text-sm font-bold text-white mb-6 border-b border-dark-border pb-4">Informasi Akun</h2>
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-medium text-muted block mb-1">Email</label>
                <p className="text-sm text-white font-medium">{user?.email}</p>
              </div>
              <div>
                <label className="text-[10px] font-medium text-muted block mb-1">Role</label>
                <span className="inline-block px-2.5 py-0.5 rounded-full bg-primary/10 text-primary text-[10px] font-medium border border-primary/20">
                  {user?.role === "admin" ? "Administrator" : "Member"}
                </span>
              </div>
              <div>
                <label className="text-[10px] font-medium text-muted block mb-1">Member Sejak</label>
                <p className="text-sm text-white">
                  {user?.created_at ? new Date(user.created_at).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" }) : "-"}
                </p>
              </div>
              <div>
                <label className="text-[10px] font-medium text-muted block mb-1">Kode Referral</label>
                <div className="flex items-center justify-between bg-white/5 p-3 rounded-lg border border-dark-border">
                  <code className="text-sm text-primary font-mono font-bold">{user?.referral_code || "-"}</code>
                  <button onClick={copyReferral} className="text-muted hover:text-white transition-colors" title="Salin">
                    {copied ? <Check size={16} className="text-green-400" /> : <Copy size={16} />}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* 2FA */}
          <div className="bg-dark-surface rounded-xl border border-dark-border p-6 shadow-sm">
            <h2 className="text-sm font-bold text-white mb-4 flex items-center gap-2 border-b border-dark-border pb-4">
              <Shield size={16} className="text-primary" /> Verifikasi 2 Langkah
            </h2>

            <div className="space-y-4">
              <div className={`flex items-center gap-3 p-3 rounded-lg border ${twoFaEnabled ? "bg-green-500/10 border-green-500/20" : "bg-white/5 border-dark-border"}`}>
                {twoFaEnabled ? <ShieldCheck size={18} className="text-green-400 shrink-0" /> : <ShieldOff size={18} className="text-muted shrink-0" />}
                <div>
                  <p className={`text-xs font-bold ${twoFaEnabled ? "text-green-400" : "text-muted"}`}>
                    {twoFaEnabled ? "2FA Aktif" : "2FA Nonaktif"}
                  </p>
                  <p className="text-[10px] text-muted">
                    {twoFaEnabled ? `OTP via ${twoFaType === "wa" ? "WhatsApp" : "Email"}` : "Tambahkan lapisan keamanan ekstra"}
                  </p>
                </div>
              </div>

              {/* 2FA Type selector */}
              {!twoFaEnabled && (
                <div>
                  <label className="text-[10px] font-medium text-muted block mb-2">Metode OTP</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button onClick={() => setTwoFaType("email")} className={`py-2 rounded-lg border text-[10px] font-medium transition-all ${twoFaType === "email" ? "border-primary bg-primary/10 text-primary" : "border-dark-border bg-white/5 text-muted"}`}>
                      Email
                    </button>
                    <button onClick={() => setTwoFaType("wa")} className={`py-2 rounded-lg border text-[10px] font-medium transition-all ${twoFaType === "wa" ? "border-green-500 bg-green-500/10 text-green-400" : "border-dark-border bg-white/5 text-muted"}`}>
                      WhatsApp
                    </button>
                  </div>
                </div>
              )}

              {twoFaMsg.text && (
                <div className={`p-2 rounded-lg text-xs text-center ${twoFaMsg.type === "error" ? "bg-red-500/10 border border-red-500/20 text-red-400" : "bg-green-500/10 border border-green-500/20 text-green-400"}`}>{twoFaMsg.text}</div>
              )}

              {/* reCAPTCHA v2 */}
              <div className="flex justify-start my-3 overflow-hidden rounded-xl border border-dark-border">
                {SITE_KEY ? (
                  <ReCAPTCHA
                    sitekey={SITE_KEY}
                    theme="dark"
                    onChange={(token) => setTwoFaRecaptcha(token)}
                  />
                ) : (
                  <div className="p-3 text-xs text-red-400">Site key reCAPTCHA tidak ditemukan</div>
                )}
              </div>

              <button
                onClick={() => handleToggle2FA(!twoFaEnabled)}
                disabled={twoFaLoading || !twoFaRecaptcha}
                className={`w-full py-2.5 rounded-lg font-bold text-xs transition-colors flex items-center justify-center gap-2 ${twoFaEnabled
                  ? "bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20"
                  : "bg-primary hover:bg-primary-hover text-dark"
                  }`}
              >
                {twoFaLoading ? <Loader2 size={14} className="animate-spin" /> : twoFaEnabled ? <ShieldOff size={14} /> : <ShieldCheck size={14} />}
                {twoFaEnabled ? "Nonaktifkan 2FA" : "Aktifkan 2FA"}
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
