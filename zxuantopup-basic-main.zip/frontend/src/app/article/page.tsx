export const dynamic = "force-dynamic";

import dynamic_import from "next/dynamic";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import MobileNav from "@/components/layout/MobileNav";

const ArticleSection = dynamic_import(() => import("@/components/home/ArticleSection"), { ssr: false });

export default function ArticlePage() {
  return (
    <>
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 pt-24 pb-24 lg:pb-12">
        <ArticleSection />
      </main>
      <Footer />
      <MobileNav />
    </>
  );
}
