"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import ReCAPTCHA from "react-google-recaptcha";
import Navbar from "@/components/layout/Navbar";
import MobileNav from "@/components/layout/MobileNav";
import { Mail, Lock, Eye, EyeOff, Shield, Loader2, KeyRound, ArrowLeft, MessageCircle } from "lucide-react";

const SITE_KEY = process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY || "";

type Step = "email" | "otp" | "newpass" | "done";

export default function ForgotPasswordPage() {
  const [step, setStep] = useState<Step>("email");
  const [email, setEmail] = useState("");
  const [method, setMethod] = useState<"email" | "wa">("email");
  const [otpCode, setOtpCode] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [recaptchaToken, setRecaptchaToken] = useState<string | null>(null);

  const API = process.env.NEXT_PUBLIC_API_URL ;

  const handleSendOtp = async () => {
    if (!email) return;
    if (!recaptchaToken) { setError("Validasi reCAPTCHA diperlukan."); return; }
    setError("");
    setLoading(true);
    try {
      const res = await fetch(`${API}/api/auth/forgot-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, method, recaptchaToken }),
      });
      const data = await res.json();
      if (data.success) {
        setStep("otp");
      } else {
        setError(data.message || "Gagal mengirim OTP");
      }
    } catch {
      setError("Terjadi kesalahan");
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async () => {
    if (!otpCode || !newPassword) return;
    if (newPassword.length < 6) { setError("Password baru minimal 6 karakter"); return; }
    if (!recaptchaToken) { setError("Validasi reCAPTCHA diperlukan."); return; }
    setError("");
    setLoading(true);
    try {
      const res = await fetch(`${API}/api/auth/reset-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, otp_code: otpCode, new_password: newPassword, recaptchaToken }),
      });
      const data = await res.json();
      if (data.success) {
        setStep("done");
      } else {
        setError(data.message || "Gagal mereset password");
      }
    } catch {
      setError("Terjadi kesalahan");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Navbar />
      <main className="min-h-screen flex items-center justify-center pt-16 pb-24 px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md rounded-2xl border border-dark-border bg-dark-surface shadow-2xl p-8 md:p-10"
        >
          {/* ─── Step: Enter Email ─── */}
          {step === "email" && (
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                  <KeyRound size={20} className="text-primary" />
                </div>
                <div>
                  <h1 className="font-heading text-xl font-bold text-white">Lupa Password</h1>
                  <p className="text-xs text-muted">Kami akan mengirimkan kode OTP untuk reset password</p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-muted mb-1.5 block">Email terdaftar</label>
                  <div className="relative group">
                    <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted group-focus-within:text-primary transition-colors" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@example.com"
                      className="input-field pl-10"
                    />
                  </div>
                </div>

                {/* Method Picker */}
                <div>
                  <label className="text-xs font-medium text-muted mb-2 block">Kirim kode OTP via</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setMethod("email")}
                      className={`flex items-center justify-center gap-2 py-2.5 rounded-xl border text-xs font-medium transition-all ${method === "email"
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-dark-border bg-dark-surface2 text-muted hover:border-primary/30"
                        }`}
                    >
                      <Mail size={14} /> Email
                    </button>
                    <button
                      type="button"
                      onClick={() => setMethod("wa")}
                      className={`flex items-center justify-center gap-2 py-2.5 rounded-xl border text-xs font-medium transition-all ${method === "wa"
                        ? "border-green-500 bg-green-500/10 text-green-400"
                        : "border-dark-border bg-dark-surface2 text-muted hover:border-green-500/30"
                        }`}
                    >
                      <MessageCircle size={14} /> WhatsApp
                    </button>
                  </div>
                  {method === "wa" && (
                    <p className="text-[10px] text-muted mt-1.5">⚠️ Hanya jika nomor WA sudah ditautkan ke akun</p>
                  )}
                </div>

                {error && (
                  <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs text-center">{error}</div>
                )}

                {/* reCAPTCHA v2 */}
                <div className="flex justify-center my-4 overflow-hidden rounded-xl border border-dark-border">
                  {SITE_KEY ? (
                    <ReCAPTCHA
                      sitekey={SITE_KEY}
                      theme="dark"
                      onChange={(token) => setRecaptchaToken(token)}
                    />
                  ) : (
                    <div className="p-3 text-xs text-red-400">Site key reCAPTCHA tidak ditemukan</div>
                  )}
                </div>

                <button
                  onClick={handleSendOtp}
                  disabled={loading || !email || !recaptchaToken}
                  className="w-full btn-primary flex items-center justify-center gap-2 text-sm py-3 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? <Loader2 size={14} className="animate-spin" /> : <Shield size={14} />}
                  {loading ? "Mengirim..." : "Kirim Kode OTP"}
                </button>

                <Link href="/login" className="flex items-center justify-center gap-1 text-xs text-muted hover:text-white transition-colors py-2">
                  <ArrowLeft size={12} /> Kembali ke login
                </Link>
              </div>
            </div>
          )}

          {/* ─── Step: Enter OTP + New Password ─── */}
          {step === "otp" && (
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Shield size={20} className="text-primary" />
                </div>
                <div>
                  <h2 className="font-heading text-lg font-bold text-white">Verifikasi & Reset</h2>
                  <p className="text-xs text-muted">Masukkan kode OTP dan password baru</p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-xs font-medium text-muted mb-1.5 block">Kode OTP (6 digit)</label>
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={6}
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ""))}
                    placeholder="000000"
                    className="input-field text-center text-lg tracking-[8px] font-mono"
                    autoFocus
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-muted mb-1.5 block">Password baru</label>
                  <div className="relative group">
                    <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted group-focus-within:text-primary transition-colors" />
                    <input
                      type={showPassword ? "text" : "password"}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Minimal 6 karakter"
                      className="input-field pl-10 pr-10"
                    />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted hover:text-white transition-colors">
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                {error && (
                  <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs text-center">{error}</div>
                )}

                {/* reCAPTCHA v2 */}
                <div className="flex justify-center my-4 overflow-hidden rounded-xl border border-dark-border">
                  {SITE_KEY ? (
                    <ReCAPTCHA
                      sitekey={SITE_KEY}
                      theme="dark"
                      onChange={(token) => setRecaptchaToken(token)}
                    />
                  ) : (
                    <div className="p-3 text-xs text-red-400">Site key reCAPTCHA tidak ditemukan</div>
                  )}
                </div>

                <button
                  onClick={handleResetPassword}
                  disabled={loading || otpCode.length !== 6 || !newPassword || !recaptchaToken}
                  className="w-full btn-primary flex items-center justify-center gap-2 text-sm py-3 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? <Loader2 size={14} className="animate-spin" /> : <Lock size={14} />}
                  {loading ? "Memproses..." : "Reset Password"}
                </button>

                <button onClick={() => { setStep("email"); setError(""); }} className="w-full text-xs text-muted hover:text-white py-2 transition-colors">
                  Kirim ulang kode
                </button>
              </div>
            </div>
          )}

          {/* ─── Step: Done ─── */}
          {step === "done" && (
            <div className="text-center py-6">
              <div className="w-16 h-16 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-4">
                <Shield size={28} className="text-green-400" />
              </div>
              <h2 className="font-heading text-xl font-bold text-white mb-2">Password Berhasil Direset!</h2>
              <p className="text-sm text-muted mb-6">Silakan masuk dengan password baru Anda.</p>
              <Link href="/login" className="btn-primary inline-flex items-center gap-2 px-8 py-3 text-sm">
                <ArrowLeft size={14} /> Masuk Sekarang
              </Link>
            </div>
          )}
        </motion.div>
      </main>
      <MobileNav />
    </>
  );
}
