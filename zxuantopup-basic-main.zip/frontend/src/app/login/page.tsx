"use client";

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { useRouter } from "next/navigation";
import ReCAPTCHA from "react-google-recaptcha";
import Navbar from "@/components/layout/Navbar";
import MobileNav from "@/components/layout/MobileNav";
import { Lock, Mail, Eye, EyeOff, Shield, Gift, Star, Loader2, KeyRound } from "lucide-react";
import { IconBrandGoogle } from "@tabler/icons-react";
import { useAuth } from "@/lib/auth";

const SITE_KEY = process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY || "";

const BENEFITS = [
  "Transaksi Aman",
  "Refund Mudah & Cepat",
  "Promo Eksklusif Member",
  "Biaya Admin Rendah",
  "Akses Seluruh Produk",
];

export default function LoginPage() {
  const { login } = useAuth();
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const [recaptchaToken, setRecaptchaToken] = useState<string | null>(null);
  const [loginError, setLoginError] = useState("");
  const [loginLoading, setLoginLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    if (!recaptchaToken) {
      setLoginError("Validasi reCAPTCHA diperlukan.");
      return;
    }
    setLoginError("");
    setLoginLoading(true);
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL }/api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password, recaptchaToken }),
      });
      const data = await res.json();
      if (data.success && data.require_2fa) {
        // 2FA required — redirect to verify page
        router.push(`/verify-2fa?token=${data.temp_token}&method=${data.method}`);
      } else if (data.success && data.token) {
        login(data.token);
        window.location.href = "/dashboard";
      } else {
        setLoginError(data.message || "Login gagal");
      }
    } catch {
      setLoginError("Terjadi kesalahan, coba lagi.");
    } finally {
      setLoginLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    window.location.href = `${process.env.NEXT_PUBLIC_API_URL }/api/auth/google`;
  };

  return (
    <>
      <Navbar />
      <main className="min-h-screen flex items-center justify-center pt-16 pb-24 px-4">
        <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-2 gap-0 rounded-2xl overflow-hidden border border-dark-border bg-dark-surface shadow-2xl">

          {/* LEFT — Login Form */}
          <div className="p-8 md:p-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* Header */}
              <div className="flex items-center gap-3 mb-2">
                <div className="w-10 h-10 rounded-xl overflow-hidden">
                  <img src="/images/logo.webp" alt={process.env.NEXT_PUBLIC_APP_NAME as string} className="w-full h-full object-cover" />
                </div>
                <div>
                  <h1 className="font-heading text-xl font-bold text-white">Masuk</h1>
                  <p className="text-xs text-muted">Masuk dengan akun yang telah Kamu daftarkan</p>
                </div>
              </div>

              <form className="mt-8 space-y-4" onSubmit={handleSubmit}>
                {/* Email */}
                <div>
                  <label className="text-xs font-medium text-muted mb-1.5 block">Email / Username</label>
                  <div className="relative group">
                    <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted group-focus-within:text-primary transition-colors" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="you@example.com"
                      className="input-field pl-10"
                    />
                  </div>
                </div>

                {/* Password */}
                <div>
                  <label className="text-xs font-medium text-muted mb-1.5 block">Kata sandi</label>
                  <div className="relative group">
                    <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted group-focus-within:text-primary transition-colors" />
                    <input
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="input-field pl-10 pr-10"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted hover:text-white transition-colors"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                {/* Remember + Forgot */}
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={remember}
                      onChange={(e) => setRemember(e.target.checked)}
                      className="w-3.5 h-3.5 rounded border-dark-border accent-primary"
                    />
                    <span className="text-xs text-muted">Ingat akun ku</span>
                  </label>
                  <Link href="/forgot-password" className="text-xs text-primary hover:text-primary-hover font-medium transition-colors">
                    Lupa kata sandi?
                  </Link>
                </div>

                {/* reCAPTCHA v3 badge notice */}
                {/* reCAPTCHA v2 */}
                <div className="flex justify-center mb-4 overflow-hidden rounded-xl border border-dark-border">
                  {SITE_KEY ? (
                    <ReCAPTCHA
                      sitekey={SITE_KEY}
                      theme="dark"
                      onChange={(token) => setRecaptchaToken(token)}
                    />
                  ) : (
                    <div className="p-3 text-xs text-red-400">Site key reCAPTCHA tidak ditemukan</div>
                  )}
                </div>

                {loginError && (
                  <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs text-center font-medium">
                    {loginError}
                  </div>
                )}

                {/* Submit */}
                <button
                  type="submit"
                  disabled={loginLoading || !email || !password || !recaptchaToken}
                  className="w-full btn-primary flex items-center justify-center gap-2 text-sm py-3 relative overflow-hidden group disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loginLoading ? (
                    <Loader2 size={14} className="animate-spin" />
                  ) : (
                    <Lock size={14} />
                  )}
                  {loginLoading ? "Memproses..." : "Masuk"}
                  <span className="absolute inset-x-0 -bottom-px h-px bg-gradient-to-r from-transparent via-secondary to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
              </form>

              {/* Divider */}
              <div className="flex items-center gap-3 my-6">
                <div className="flex-1 h-px bg-dark-border" />
                <span className="text-xs text-muted">Atau lanjutkan dengan</span>
                <div className="flex-1 h-px bg-dark-border" />
              </div>

              {/* Google Login */}
              <button
                onClick={handleGoogleLogin}
                className="w-full flex items-center justify-center gap-3 py-3 rounded-xl bg-dark-surface2 border border-dark-border text-white text-sm font-medium hover:border-primary/50 hover:bg-dark-surface2/80 transition-all relative overflow-hidden group"
              >
                <IconBrandGoogle size={18} />
                Google
                <span className="absolute inset-x-0 -bottom-px h-px bg-gradient-to-r from-transparent via-blue-500 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              </button>

              {/* Register link */}
              <p className="text-center text-xs text-muted mt-6">
                Belum punya akun?{" "}
                <Link href="/register" className="text-primary hover:text-primary-hover font-semibold transition-colors">
                  Daftar sekarang
                </Link>
              </p>
            </motion.div>
          </div>

          {/* RIGHT — Promo Banner */}
          <div className="hidden lg:flex flex-col items-center justify-center relative overflow-hidden p-10">
            {/* Banner image background */}
            <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: 'url(/images/banners/hero1.webp)' }} />
            <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-orange-600/70 to-yellow-500/60" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.1)_1px,transparent_0)] bg-[length:20px_20px]" />

            {/* Floating elements */}
            <motion.div
              animate={{ y: [-8, 8, -8], rotate: [0, 10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute top-16 left-10"
            >
              <div className="w-12 h-12 rounded-xl bg-white/15 backdrop-blur-sm flex items-center justify-center">
                <Shield className="text-white" size={24} />
              </div>
            </motion.div>

            <motion.div
              animate={{ y: [8, -8, 8] }}
              transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", delay: 1 }}
              className="absolute bottom-20 right-12"
            >
              <div className="w-10 h-10 rounded-lg bg-white/15 backdrop-blur-sm flex items-center justify-center">
                <Star className="text-yellow-200" size={20} />
              </div>
            </motion.div>

            <motion.div
              animate={{ y: [-5, 5, -5] }}
              transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
              className="absolute top-32 right-16"
            >
              <div className="w-8 h-8 rounded-lg bg-white/10 backdrop-blur-sm flex items-center justify-center">
                <Gift className="text-white" size={16} />
              </div>
            </motion.div>

            <div className="relative z-10 text-center">
              <div className="w-16 h-16 rounded-2xl overflow-hidden mx-auto mb-6 ring-2 ring-white/30 shadow-lg">
                <img src="/images/logo.webp" alt={process.env.NEXT_PUBLIC_APP_NAME as string} className="w-full h-full object-cover" />
              </div>

              <h2 className="font-heading text-2xl md:text-3xl font-black text-white leading-tight mb-2">
                JOIN MEMBER
                <br />
                <span className="text-yellow-200">{process.env.NEXT_PUBLIC_APP_NAME}</span>
              </h2>

              <p className="text-sm text-white/70 mb-6">
                Apa aja benefit jadi member?
              </p>

              <div className="flex flex-wrap justify-center gap-2 max-w-xs mx-auto">
                {BENEFITS.map((b, i) => (
                  <motion.span
                    key={b}
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.3 + i * 0.1 }}
                    className="px-3 py-1.5 rounded-lg bg-white/15 backdrop-blur-sm text-[11px] font-bold text-white border border-white/20"
                  >
                    {b}
                  </motion.span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
      <MobileNav />
    </>
  );
}
