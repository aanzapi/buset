"use client";

import { useState, useEffect, Suspense } from "react";
import { motion } from "framer-motion";
import { useSearchParams, useRouter } from "next/navigation";
import ReCAPTCHA from "react-google-recaptcha";
import Navbar from "@/components/layout/Navbar";
import MobileNav from "@/components/layout/MobileNav";
import { Shield, KeyRound, Loader2, ArrowLeft } from "lucide-react";
import { useAuth } from "@/lib/auth";

const SITE_KEY = process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY || "";

function Verify2FAContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { login } = useAuth();
  
  const token = searchParams.get("token");
  const method = searchParams.get("method");

  const [otpCode, setOtpCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [recaptchaToken, setRecaptchaToken] = useState<string | null>(null);

  useEffect(() => {
    if (!token) {
      router.push("/login");
    }
  }, [token, router]);

  const handleVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpCode || otpCode.length !== 6 || !token) return;
    if (!recaptchaToken) { setError("Validasi reCAPTCHA diperlukan."); return; }
    setError("");
    setLoading(true);
    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL }/api/auth/verify-2fa`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ temp_token: token, otp_code: otpCode, recaptchaToken }),
      });
      const data = await res.json();
      if (data.success && data.token) {
        login(data.token);
        window.location.href = "/dashboard";
      } else {
        setError(data.message || "Kode OTP salah");
      }
    } catch {
      setError("Terjadi kesalahan, coba lagi.");
    } finally {
      setLoading(false);
    }
  };

  if (!token) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full max-w-sm rounded-2xl border border-dark-border bg-dark-surface shadow-2xl p-8"
    >
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
          <KeyRound size={20} className="text-primary" />
        </div>
        <div>
          <h1 className="font-heading text-lg font-bold text-white">Verifikasi 2 Langkah</h1>
          <p className="text-xs text-muted">OTP dikirim via {method === "wa" ? "WhatsApp" : "Email"}</p>
        </div>
      </div>

      <form onSubmit={handleVerify} className="space-y-4">
        <div>
          <input
            type="text"
            inputMode="numeric"
            maxLength={6}
            value={otpCode}
            onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ""))}
            placeholder="000000"
            className="input-field text-center text-xl tracking-[12px] font-mono h-14"
            autoFocus
          />
        </div>

        {/* reCAPTCHA v2 */}
        <div className="flex justify-center my-4 overflow-hidden rounded-xl border border-dark-border">
          {SITE_KEY ? (
            <ReCAPTCHA
              sitekey={SITE_KEY}
              theme="dark"
              onChange={(token) => setRecaptchaToken(token)}
            />
          ) : (
            <div className="p-3 text-xs text-red-400">Site key reCAPTCHA tidak ditemukan</div>
          )}
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs text-center font-medium">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={loading || otpCode.length !== 6 || !recaptchaToken}
          className="w-full btn-primary flex items-center justify-center gap-2 text-sm py-3 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? <Loader2 size={14} className="animate-spin" /> : <Shield size={14} />}
          {loading ? "Memverifikasi..." : "Verifikasi"}
        </button>

        <div className="flex justify-center pt-2">
          <button
            type="button"
            onClick={() => router.push("/login")}
            className="flex items-center gap-2 text-xs text-muted hover:text-white transition-colors"
          >
            <ArrowLeft size={14} /> Kembali ke login
          </button>
        </div>
      </form>
    </motion.div>
  );
}

export default function Verify2FAPage() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen flex items-center justify-center pt-16 pb-24 px-4">
        <Suspense fallback={<div className="flex items-center gap-2 text-muted"><Loader2 className="animate-spin" /> Memuat...</div>}>
          <Verify2FAContent />
        </Suspense>
      </main>
      <MobileNav />
    </>
  );
}
