"use client";

import Link from "next/link";
import { Home, FileText, Newspaper, User } from "lucide-react";
import { usePathname } from "next/navigation";

const navItems = [
  { icon: Home, label: "Topup", href: "/" },
  { icon: FileText, label: "Transaksi", href: "/invoice" },
  { icon: Newspaper, label: "Artikel", href: "/article" },
  { icon: User, label: "Profil", href: "/login" },
];

export default function MobileNav() {
  const pathname = usePathname();

  return null;
}
