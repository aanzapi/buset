"use client";

import { APP_CONFIG } from "@/lib/branding";

const PAYMENT_METHODS = [
  "QRIS", "Dana", "OVO", "GoPay", "ShopeePay",
  "BRI", "BCA", "Mandiri", "BNI", "SeaBank", "LinkAja",
];

const POPULAR_GAMES = [
  { name: "Mobile Legends", icon: "https://vip-reseller.co.id/library/assets/images/product/ML_B-02.webp" },
  { name: "Free Fire", icon: "https://vip-reseller.co.id/library/assets/images/product/free-fire.webp" },
  { name: "Genshin Impact", icon: "https://vip-reseller.co.id/library/assets/images/product/genshin-impact.webp" },
  { name: "Valorant", icon: "https://vip-reseller.co.id/library/assets/images/game/valorant-new.jpg" },
  { name: "PUBG Mobile", icon: "https://vip-reseller.co.id/library/assets/images/game/pubgm-a-icon.jpg" },
];

export default function Footer() {
  return (
    <footer className="relative mt-20">
      {/* Wave SVG separator */}
      <div className="absolute top-0 left-0 right-0 -translate-y-[99%] overflow-hidden">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-auto" preserveAspectRatio="none">
          <path
            d="M0 60C240 20 480 100 720 60C960 20 1200 100 1440 60V120H0V60Z"
            fill="#1A1A1A"
          />
          <path
            d="M0 80C240 40 480 120 720 80C960 40 1200 120 1440 80V120H0V80Z"
            fill="#1A1A1A"
            fillOpacity="0.5"
          />
        </svg>
      </div>

      <div className="bg-dark-surface">
        {/* Main footer content */}
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Brand */}
            <div>
              <Link href="/" className="flex items-center gap-2 mb-4">
                <div className="w-9 h-9 rounded-xl overflow-hidden">
                  <img src="/images/logo.webp" alt={APP_CONFIG.name} className="w-full h-full object-cover" />
                </div>
                <div>
                  <span className="font-heading text-xl font-bold text-primary">{APP_CONFIG.brand}</span>
                  <span className="font-heading text-xl font-bold text-secondary">{APP_CONFIG.subBrand}</span>
                </div>
              </Link>
              <p className="text-muted text-sm leading-relaxed mb-5">
                No.#1 supplier top up game & voucher terlaris, murah, aman legal 100% buka 24 Jam dengan channel pembayaran terlengkap Indonesia.
              </p>

              {/* Social icons */}
              <div className="flex items-center gap-2 mb-4">
                <a href={`mailto:support@${APP_CONFIG.domain}`} className="w-9 h-9 rounded-lg bg-dark-surface2 border border-dark-border flex items-center justify-center text-muted hover:text-primary hover:border-primary/30 transition-all">
                  <Mail size={16} />
                </a>
                <a href="https://instagram.com/yilzi_dominan" target="_blank" rel="noopener" className="w-9 h-9 rounded-lg bg-dark-surface2 border border-dark-border flex items-center justify-center text-muted hover:text-pink-400 hover:border-pink-400/30 transition-all">
                  <AtSign size={16} />
                </a>
                <a href="https://t.me/Yilziii" target="_blank" rel="noopener" className="w-9 h-9 rounded-lg bg-dark-surface2 border border-dark-border flex items-center justify-center text-muted hover:text-blue-400 hover:border-blue-400/30 transition-all">
                  <Send size={16} />
                </a>
                <a href="https://wa.me/6281359123789" target="_blank" rel="noopener" className="w-9 h-9 rounded-lg bg-dark-surface2 border border-dark-border flex items-center justify-center text-muted hover:text-green-400 hover:border-green-400/30 transition-all">
                  <MessageCircle size={16} />
                </a>
              </div>
            </div>

            {/* Navigasi */}
            <div>
              <h4 className="font-heading text-sm font-bold text-primary mb-4 uppercase tracking-wider">Navigasi</h4>
              <ul className="space-y-2.5">
                {[
                  { label: "Beranda", href: "/" },
                  { label: "Cek Pesanan", href: "/invoice" },
                  { label: "Leaderboard", href: "/leaderboard" },
                  { label: "Testimoni", href: "#testimonials" },
                  { label: "Artikel", href: "/article" },
                  { label: "Kebijakan & Privasi", href: "/privacy" },
                ].map((item) => (
                  <li key={item.label}>
                    <Link href={item.href} className="text-sm text-muted hover:text-white transition-colors">
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Games Populer */}
            <div>
              <h4 className="font-heading text-sm font-bold text-primary mb-4 uppercase tracking-wider">Games Populer</h4>
              <div className="flex flex-wrap gap-2 mb-6">
                {POPULAR_GAMES.map((game) => (
                  <div key={game.name} className="w-11 h-11 rounded-xl overflow-hidden border border-dark-border hover:border-primary/50 hover:scale-110 transition-all cursor-pointer" title={game.name}>
                    <img src={game.icon} alt={game.name} className="w-full h-full object-cover" loading="lazy" />
                  </div>
                ))}
              </div>

              <h4 className="font-heading text-sm font-bold text-primary mb-3 uppercase tracking-wider">Metode Pembayaran</h4>
              <div className="flex flex-wrap gap-1.5">
                {PAYMENT_METHODS.map((pm) => (
                  <span
                    key={pm}
                    className="px-2.5 py-1.5 rounded-lg bg-dark-surface2 border border-dark-border text-[10px] font-bold text-muted"
                  >
                    {pm}
                  </span>
                ))}
              </div>
            </div>

            {/* Hubungi Kami */}
            <div>
              <h4 className="font-heading text-sm font-bold text-primary mb-4 uppercase tracking-wider">Support</h4>
              <ul className="space-y-3">
                <li className="flex items-center gap-2.5">
                  <MessageCircle size={14} className="text-green-400 shrink-0" />
                  <a href="https://wa.me/6281359123789" className="text-sm text-muted hover:text-white transition-colors">
                    WhatsApp
                  </a>
                </li>
                <li className="flex items-center gap-2.5">
                  <Send size={14} className="text-blue-400 shrink-0" />
                  <a href="https://t.me/Yilziii" target="_blank" rel="noopener" className="text-sm text-muted hover:text-white transition-colors">
                    Telegram
                  </a>
                </li>
                <li className="flex items-center gap-2.5">
                  <Mail size={14} className="text-primary shrink-0" />
                  <a href={`mailto:support@${APP_CONFIG.domain}`} className="text-sm text-muted hover:text-white transition-colors">
                    support@{APP_CONFIG.domain}
                  </a>
                </li>
                <li className="flex items-center gap-2.5">
                  <AtSign size={14} className="text-pink-400 shrink-0" />
                  <a href="https://instagram.com/yilzi_dominan" target="_blank" rel="noopener" className="text-sm text-muted hover:text-white transition-colors">
                    @yilzi_dominan
                  </a>
                </li>
                <li className="flex items-start gap-2.5">
                  <MapPin size={14} className="text-yellow-400 shrink-0 mt-0.5" />
                  <span className="text-sm text-muted">Indonesia</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="mt-10 pt-6 border-t border-dark-border flex flex-col md:flex-row items-center justify-between gap-3">
            <div className="flex flex-col md:flex-row items-center gap-1 md:gap-4">
              <p className="text-xs text-muted">© 2026 {APP_CONFIG.name}.com — All Rights Reserved</p>
              <div className="text-[10px] text-muted/30 select-none">
                {/* Distributed watermark to make it hard to change */}
                <span>{"Made ".split("").join("")}</span>
                <span>{"By ".split("").join("")}</span>
                <span className="hover:text-primary transition-colors cursor-default">{APP_CONFIG.domain}</span>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {[
                { label: "Beranda", href: "/" },
                { label: "Testimoni", href: "#testimonials" },
                { label: "Kebijakan", href: "/privacy" },
                { label: "Cek Pesanan", href: "/invoice" },
              ].map((item) => (
                <Link key={item.label} href={item.href} className="text-xs text-muted hover:text-primary transition-colors">
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
