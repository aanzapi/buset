"use client";

import { useEffect, useState } from "react";

export function AntiDevTools() {
  const [isDevToolsOpen, setIsDevToolsOpen] = useState(false);

  useEffect(() => {
    // 1. Block Keyboard Shortcuts
    const handleKeyDown = (e: KeyboardEvent) => {
      // F12
      if (e.key === "F12") {
        e.preventDefault();
        return false;
      }
      // Ctrl + Shift + I / J / C
      if (e.ctrlKey && e.shiftKey && (e.key === "I" || e.key === "i" || e.key === "J" || e.key === "j" || e.key === "C" || e.key === "c")) {
        e.preventDefault();
        return false;
      }
      // Ctrl + U (View Source)
      if (e.ctrlKey && (e.key === "U" || e.key === "u")) {
        e.preventDefault();
        return false;
      }
    };

    // 2. Block Right Click (Context Menu)
    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("contextmenu", handleContextMenu);

    // 3. DevTools Detection Loop (Blank Page Trigger)
    const devToolsCheck = setInterval(() => {
      // Pengecekan via ukuran layar (DevTools mengambil space layar)
      const widthThreshold = window.outerWidth - window.innerWidth > 160;
      const heightThreshold = window.outerHeight - window.innerHeight > 160;
      
      if (widthThreshold || heightThreshold) {
        setIsDevToolsOpen(true);
      } else {
        setIsDevToolsOpen(false);
      }
      
      // Pengecekan via Debugger Trap (sangat efektif)
      const start = new Date().getTime();
      // eslint-disable-next-line no-debugger
      debugger; 
      const end = new Date().getTime();
      
      // Jika DevTools terbuka, debugger akan menjeda eksekusi, sehingga durasinya > 100ms
      if (end - start > 100) {
        setIsDevToolsOpen(true);
      }
    }, 1000);

    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("contextmenu", handleContextMenu);
      clearInterval(devToolsCheck);
    };
  }, []);

  if (isDevToolsOpen) {
    return (
      <div className="fixed inset-0 z-[99999] bg-black flex flex-col items-center justify-center text-white p-6 text-center">
        <h1 className="text-5xl font-bold text-red-600 mb-6">Akses Ditolak!</h1>
        <p className="text-xl max-w-2xl">
          Tindakan inspeksi elemen, melihat source code, atau membuka Developer Tools 
          <b> TIDAK DIIZINKAN</b> di situs ini demi keamanan sistem.
        </p>
        <p className="text-md mt-8 text-gray-400">
          Silakan tutup Developer Tools Anda dan muat ulang (Refresh) halaman ini.
        </p>
      </div>
    );
  }

  return null;
}
