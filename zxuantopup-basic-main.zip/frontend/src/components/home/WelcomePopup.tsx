"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Gift, Zap, Star, Shield, ChevronRight, Sparkles } from "lucide-react";
import Link from "next/link";

export default function WelcomePopup() {
  const [show, setShow] = useState(false);
  const [dontShow, setDontShow] = useState(false);

  useEffect(() => {
    const dismissed = localStorage.getItem("zxuan_popup_dismissed");
    if (!dismissed) {
      const timer = setTimeout(() => setShow(true), 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = () => {
    setShow(false);
    if (dontShow) {
      localStorage.setItem("zxuan_popup_dismissed", "true");
    }
  };

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[999] flex items-center justify-center p-4"
          onClick={handleClose}
        >
          {/* Backdrop */}
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />

          {/* Modal */}
          <motion.div
            initial={{ scale: 0.85, opacity: 0, y: 30 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.85, opacity: 0, y: 30 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-md overflow-hidden rounded-2xl shadow-2xl"
          >
            {/* Close button */}
            <button
              onClick={handleClose}
              className="absolute top-3 right-3 z-20 p-1.5 rounded-full bg-black/50 backdrop-blur-sm text-white/70 hover:text-white hover:bg-black/70 transition-all"
            >
              <X size={18} />
            </button>

            {/* Header — with banner image */}
            <div className="relative h-52 overflow-hidden">
              <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: "url(/images/banners/hero1.webp)" }} />
              <div className="absolute inset-0 bg-gradient-to-b from-primary/60 via-orange-600/50 to-dark" />

              {/* Floating sparkles */}
              <motion.div
                animate={{ y: [-5, 5, -5], rotate: [0, 5, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                className="absolute top-6 left-6"
              >
                <div className="w-10 h-10 rounded-xl bg-white/15 backdrop-blur-sm flex items-center justify-center">
                  <Sparkles className="text-yellow-300" size={20} />
                </div>
              </motion.div>

              <motion.div
                animate={{ y: [5, -5, 5], rotate: [0, -5, 0] }}
                transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                className="absolute top-10 right-10"
              >
                <div className="w-8 h-8 rounded-lg bg-white/15 backdrop-blur-sm flex items-center justify-center">
                  <Star className="text-yellow-200" size={16} />
                </div>
              </motion.div>

              {/* Logo + text */}
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <div className="w-16 h-16 rounded-2xl overflow-hidden mb-3 ring-2 ring-white/30 shadow-lg">
                  <img src="/images/logo.webp" alt={process.env.NEXT_PUBLIC_APP_NAME as string} className="w-full h-full object-cover" />
                </div>
                <h2 className="font-heading text-2xl font-black text-white drop-shadow-lg">
                  SELAMAT DATANG!
                </h2>
                <p className="text-sm text-white/80 mt-1">di {process.env.NEXT_PUBLIC_APP_NAME}.com</p>
              </div>
            </div>

            {/* Content */}
            <div className="p-6 bg-dark-surface">
              <h3 className="font-heading text-base font-bold text-white text-center mb-4 flex items-center justify-center gap-2">
                <Gift size={18} className="text-primary" />
                Promo Spesial Member Baru!
              </h3>

              <div className="grid grid-cols-2 gap-2 mb-5">
                {[
                  { icon: Zap, text: "Proses Instan", color: "text-orange-400" },
                  { icon: Shield, text: "100% Aman", color: "text-blue-400" },
                  { icon: Gift, text: "Bonus Member", color: "text-green-400" },
                  { icon: Star, text: "Harga Termurah", color: "text-yellow-400" },
                ].map((item, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 + i * 0.1 }}
                    className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-dark-surface2 border border-dark-border"
                  >
                    <item.icon size={15} className={`${item.color} shrink-0`} />
                    <span className="text-xs font-medium text-white">{item.text}</span>
                  </motion.div>
                ))}
              </div>

              <Link
                href="/login"
                onClick={handleClose}
                className="flex items-center justify-center gap-2 w-full btn-primary text-sm py-3 mb-4 group"
              >
                Daftar Sekarang
                <ChevronRight size={16} className="group-hover:translate-x-1 transition-transform" />
              </Link>

              <label className="flex items-center gap-2 justify-center cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={dontShow}
                  onChange={(e) => setDontShow(e.target.checked)}
                  className="w-3.5 h-3.5 rounded border-dark-border bg-dark-surface2 text-primary focus:ring-primary/50 accent-primary"
                />
                <span className="text-xs text-muted">Jangan tampilkan lagi</span>
              </label>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
