"use client";

import { motion, useInView } from "framer-motion";
import { useRef, useState, useEffect } from "react";
import { Users, BadgeCheck, Gamepad2, Server } from "lucide-react";

const stats = [
  {
    label: "Pengguna Aktif",
    value: 15000,
    suffix: "+",
    icon: Users,
    gradient: "from-violet-500 to-indigo-500",
    bg: "bg-violet-500/10",
    ring: "ring-violet-500/20",
  },
  {
    label: "Transaksi Sukses",
    value: 85000,
    suffix: "+",
    icon: BadgeCheck,
    gradient: "from-primary to-orange-400",
    bg: "bg-primary/10",
    ring: "ring-primary/20",
  },
  {
    label: "Game & Layanan",
    value: 148,
    suffix: "+",
    icon: Gamepad2,
    gradient: "from-secondary to-amber-400",
    bg: "bg-secondary/10",
    ring: "ring-secondary/20",
  },
  {
    label: "Uptime Server",
    value: 99.9,
    suffix: "%",
    icon: Server,
    gradient: "from-emerald-500 to-green-400",
    bg: "bg-emerald-500/10",
    ring: "ring-emerald-500/20",
  },
];

function AnimatedCounter({ target, suffix }: { target: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (!isInView) return;
    const duration = 2000;
    const steps = 60;
    const increment = target / steps;
    let current = 0;
    const timer = setInterval(() => {
      current += increment;
      if (current >= target) { setCount(target); clearInterval(timer); }
      else { setCount(Math.floor(current)); }
    }, duration / steps);
    return () => clearInterval(timer);
  }, [isInView, target]);

  const display = target % 1 !== 0 ? count.toFixed(1) : count.toLocaleString("id-ID");
  return <span ref={ref}>{display}{suffix}</span>;
}

export default function StatsBar() {
  return (
    <section className="mt-14">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className="relative group bg-dark-surface rounded-2xl border border-dark-border p-5 md:p-6 hover:border-primary/20 transition-all duration-300 overflow-hidden"
            >
              {/* Subtle glow */}
              <div className="absolute -top-8 -right-8 w-24 h-24 rounded-full bg-gradient-to-br opacity-0 group-hover:opacity-20 transition-opacity duration-500" style={{ backgroundImage: `linear-gradient(to bottom right, var(--tw-gradient-stops))` }} />

              <div className={`w-11 h-11 rounded-xl ${stat.bg} ring-1 ${stat.ring} flex items-center justify-center mb-4`}>
                <Icon size={20} className="text-white" />
              </div>

              <p className="text-2xl md:text-3xl font-heading font-black text-white">
                <AnimatedCounter target={stat.value} suffix={stat.suffix} />
              </p>
              <p className="text-xs text-muted mt-1 font-medium">{stat.label}</p>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
