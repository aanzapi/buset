"use client";

import { motion } from "framer-motion";
import { Zap, Shield, Headphones, CreditCard, CheckCircle } from "lucide-react";

const features = [
  {
    icon: Zap,
    title: "Proses Instan",
    desc: "Top up otomatis 24/7 langsung masuk ke akun game kamu dalam hitungan detik.",
    gradient: "from-primary to-orange-500",
    points: ["Proses 3-5 detik", "Otomatis 24 jam", "Real-time tracking"],
  },
  {
    icon: Shield,
    title: "Aman & Terpercaya",
    desc: "Transaksi dijamin aman dengan enkripsi dan verifikasi pembayaran terpercaya.",
    gradient: "from-blue-500 to-cyan-500",
    points: ["Enkripsi SSL", "Verifikasi pembayaran", "Refund guarantee"],
  },
  {
    icon: CreditCard,
    title: "Pembayaran Lengkap",
    desc: "QRIS, Dana, GoPay, OVO, ShopeePay, Bank Transfer, dan metode lainnya.",
    gradient: "from-secondary to-amber-500",
    points: ["QRIS & E-Wallet", "Virtual Account", "Transfer Bank"],
  },
  {
    icon: Headphones,
    title: "Support 24/7",
    desc: "Tim customer service siap membantu via WhatsApp, Telegram, dan Email.",
    gradient: "from-green-500 to-emerald-500",
    points: ["WhatsApp", "Telegram", "Email Support"],
  },
];

export default function WhyChooseUs() {
  return (
    <section className="mt-16 mb-8">
      <div className="text-center mb-10">
        <h2 className="font-heading text-xl md:text-2xl font-bold text-white uppercase tracking-wide">
          Kenapa Pilih <span className="gradient-text">{process.env.NEXT_PUBLIC_APP_NAME}</span>?
        </h2>
        <p className="text-sm text-muted mt-2 max-w-md mx-auto">
          Ribuan pelanggan sudah mempercayakan kebutuhan top up mereka kepada kami
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {features.map((f, i) => {
          const Icon = f.icon;
          return (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className="group bg-dark-surface rounded-2xl border border-dark-border p-6 hover:border-primary/30 transition-all duration-300 hover:-translate-y-1"
            >
              {/* Icon */}
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${f.gradient} flex items-center justify-center mb-4 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                <Icon size={22} className="text-white" />
              </div>

              <h3 className="font-heading text-sm font-bold text-white mb-2 uppercase tracking-wider">{f.title}</h3>
              <p className="text-xs text-muted leading-relaxed mb-4">{f.desc}</p>

              {/* Feature Points */}
              <div className="space-y-2 pt-3 border-t border-dark-border/50">
                {f.points.map((point) => (
                  <div key={point} className="flex items-center gap-2">
                    <CheckCircle size={12} className="text-primary shrink-0" />
                    <span className="text-[11px] text-muted">{point}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}
