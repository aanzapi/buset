/**
 * Admin authentication middleware.
 * Checks if user's email matches ADMIN_EMAIL env variable.
 * Also auto-promotes matching users to admin role in DB.
 */
async function adminAuth(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ success: false, message: 'Tidak terautentikasi' });
  }

  const adminEmails = (process.env.ADMIN_EMAIL || '')
    .split(',')
    .map(e => e.trim().toLowerCase())
    .filter(Boolean);

  const isAdmin = req.user.role === 'admin' || adminEmails.includes(req.user.email?.toLowerCase());

  if (!isAdmin) {
    return res.status(403).json({ success: false, message: 'Akses ditolak. Admin only.' });
  }

  // Auto-promote to admin role if not already
  if (req.user.role !== 'admin') {
    await req.user.update({ role: 'admin' });
  }

  next();
}

module.exports = { adminAuth };
