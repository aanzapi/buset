const axios = require('axios');

async function verifyRecaptcha(req, res, next) {
  const token = req.body.recaptchaToken;
  
  if (!token) {
    return res.status(400).json({ success: false, message: 'Validasi reCAPTCHA diperlukan (token tidak ditemukan).' });
  }

  const secretKey = process.env.RECAPTCHA_SECRET_KEY;
  if (!secretKey) {
    console.error('[reCAPTCHA] RECAPTCHA_SECRET_KEY is not set in .env');
    // If we're missing the key in dev, we could bypass, but better to fail securely:
    return res.status(500).json({ success: false, message: 'Konfigurasi server bermasalah (reCAPTCHA).' });
  }

  try {
    const verifyUrl = `https://www.google.com/recaptcha/api/siteverify`;
    const response = await axios.post(verifyUrl, null, {
      params: {
        secret: secretKey,
        response: token,
        remoteip: req.ip,
      }
    });

    const data = response.data;
    if (data.success) {
      return next();
    } else {
      console.log(`[reCAPTCHA] Failed validation for IP ${req.ip}. Error codes: ${data['error-codes']}`);
      return res.status(403).json({ success: false, message: 'Verifikasi keamanan gagal (bot terdeteksi).' });
    }
  } catch (error) {
    console.error('[reCAPTCHA] Request to Google failed:', error.message);
    return res.status(500).json({ success: false, message: 'Gagal menghubungi server verifikasi (reCAPTCHA).' });
  }
}

module.exports = { verifyRecaptcha };
