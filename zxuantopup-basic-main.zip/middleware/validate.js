const Joi = require('joi');

function validate(schema) {
  return (req, res, next) => {
    const { error } = schema.validate(req.body, { abortEarly: false });
    if (error) {
      const messages = error.details.map(d => d.message);
      return res.status(400).json({ success: false, message: 'Validasi gagal', errors: messages });
    }
    next();
  };
}

// ─── Schemas ──────────────────────────────────────────

const orderSchema = Joi.object({
  product_id: Joi.alternatives().try(Joi.number().integer(), Joi.string()).required(),
  user_input: Joi.string().min(1).max(100).required(),
  user_zone: Joi.string().max(50).allow('', null),
  quantity: Joi.number().integer().min(1).max(99).default(1),
  payment_method: Joi.string().required(),
  email: Joi.string().email().required(),
  phone: Joi.string().max(20).allow('', null),
  promo_code: Joi.string().max(50).allow('', null),
  nickname: Joi.string().max(255).allow('', null),
});

const nicknameSchema = Joi.object({
  game: Joi.string().required(),
  user_id: Joi.string().required(),
  zone_id: Joi.string().allow('', null),
});

module.exports = { validate, orderSchema, nicknameSchema };
