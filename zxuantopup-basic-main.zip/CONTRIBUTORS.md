<div align="center">
  <h1>👥 Contributors</h1>
  <p>Terima kasih kepada semua pihak yang telah mendukung dan berkontribusi secara langsung maupun tidak langsung terhadap kesuksesan <b>ZxuanTopup Platform</b>.</p>
</div>

---

## 👨‍💻 Core Team

| Nama / Perusahaan | Peran / Posisi | Keterangan |
|-------------------|----------------|------------|
| **Yilzi** | Developer Utama (Lead Engineer) | Arsitektur utama, pengembangan backend & frontend, serta manajemen infrastruktur. |

---

## 🤝 Partners & Providers

Platform ini terintegrasi dan didukung oleh layanan kelas enterprise berikut:

| Logo / Partner | Layanan | Deskripsi |
|----------------|---------|-----------|
| **Vipayment** | Provider Penyedia (Digital Goods) | Suplier resmi penyedia layanan top-up game otomatis, pulsa, dan voucher. |
| **Tripay** | Payment Gateway | Gerbang pembayaran resmi untuk memproses transaksi otomatis via QRIS, E-Wallet, dan Bank Transfer. |

---

> *"Great things in business are never done by one person. They're done by a team of people."*
